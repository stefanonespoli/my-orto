-- phpMyAdmin SQL Dump
-- version 4.1.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 05, 2016 alle 11:32
-- Versione del server: 5.1.71-community-log
-- PHP Version: 5.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_project0101`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_administrators`
--

CREATE TABLE IF NOT EXISTS `avzp_administrators` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `pass` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `email` text CHARACTER SET utf8,
  `rights` int(11) DEFAULT NULL,
  `custom_data` text COLLATE utf8_unicode_ci,
  `valid` int(1) DEFAULT '1',
  `group` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quota` int(11) DEFAULT NULL,
  `loggedin` datetime DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prime_album` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other_credentials` text COLLATE utf8_unicode_ci,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `valid` (`valid`,`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dump dei dati per la tabella `avzp_administrators`
--

INSERT INTO `avzp_administrators` (`id`, `user`, `pass`, `name`, `email`, `rights`, `custom_data`, `valid`, `group`, `quota`, `loggedin`, `language`, `prime_album`, `other_credentials`, `date`) VALUES
(1, 'project0101', 'fabce9cc739b11bd25bf8c96bd94e614', '', 'stenespo@gmail.com', 1955052532, '', 1, '', NULL, '2015-11-19 19:58:43', NULL, NULL, NULL, '2011-07-25 11:29:03'),
(3, 'administrators', NULL, 'group', '', 1955052532, 'Utenti con tutti i privilegi', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03'),
(4, 'viewers', NULL, 'group', '', 3056, 'Utenti abilitati solamente a vedere gli album', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03'),
(5, 'bozos', NULL, 'group', '', 0, 'Utenti bannati', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03'),
(6, 'album managers', NULL, 'template', '', 67386356, 'Gestori di uno o più album.', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03'),
(7, 'default', NULL, 'template', '', 3060, 'Impostazioni utente predefinite.', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03'),
(8, 'newuser', NULL, 'template', '', 0, 'Utenti registrati e verificati di recente.', 0, '', NULL, NULL, NULL, NULL, NULL, '2011-07-25 11:29:03');

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_admin_to_object`
--

CREATE TABLE IF NOT EXISTS `avzp_admin_to_object` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `adminid` int(11) unsigned NOT NULL DEFAULT '0',
  `objectid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'album',
  `edit` int(11) DEFAULT '32767',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_albums`
--

CREATE TABLE IF NOT EXISTS `avzp_albums` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned DEFAULT NULL,
  `folder` varchar(255) NOT NULL DEFAULT '',
  `title` text,
  `desc` text,
  `date` datetime DEFAULT NULL,
  `location` text,
  `show` int(1) unsigned NOT NULL DEFAULT '1',
  `closecomments` int(1) unsigned NOT NULL DEFAULT '0',
  `commentson` int(1) unsigned NOT NULL DEFAULT '1',
  `thumb` varchar(255) DEFAULT NULL,
  `mtime` int(32) DEFAULT NULL,
  `sort_type` varchar(20) DEFAULT NULL,
  `subalbum_sort_type` varchar(20) DEFAULT NULL,
  `sort_order` int(11) unsigned DEFAULT NULL,
  `image_sortdirection` int(1) unsigned DEFAULT '0',
  `album_sortdirection` int(1) unsigned DEFAULT '0',
  `hitcounter` int(11) unsigned DEFAULT '0',
  `password` varchar(255) NOT NULL DEFAULT '',
  `password_hint` text,
  `total_value` int(11) unsigned DEFAULT '0',
  `total_votes` int(11) unsigned DEFAULT '0',
  `used_ips` longtext,
  `custom_data` text,
  `dynamic` int(1) unsigned DEFAULT '0',
  `search_params` text,
  `album_theme` varchar(127) DEFAULT NULL,
  `user` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '',
  `rating` float NOT NULL DEFAULT '0',
  `rating_status` int(1) unsigned DEFAULT '3',
  `watermark` varchar(255) DEFAULT NULL,
  `codeblock` text,
  `watermark_thumb` varchar(255) DEFAULT NULL,
  `owner` varchar(64) DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `folder` (`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dump dei dati per la tabella `avzp_albums`
--

INSERT INTO `avzp_albums` (`id`, `parentid`, `folder`, `title`, `desc`, `date`, `location`, `show`, `closecomments`, `commentson`, `thumb`, `mtime`, `sort_type`, `subalbum_sort_type`, `sort_order`, `image_sortdirection`, `album_sortdirection`, `hitcounter`, `password`, `password_hint`, `total_value`, `total_votes`, `used_ips`, `custom_data`, `dynamic`, `search_params`, `album_theme`, `user`, `rating`, `rating_status`, `watermark`, `codeblock`, `watermark_thumb`, `owner`, `updateddate`) VALUES
(1, NULL, 'esempio', 'Esempio', NULL, '2008-07-31 13:39:31', NULL, 1, 0, 1, NULL, NULL, '', 'ID', NULL, 0, 0, 5, '', NULL, 0, 0, NULL, NULL, 0, NULL, NULL, '', 0, 3, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_captcha`
--

CREATE TABLE IF NOT EXISTS `avzp_captcha` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ptime` int(32) unsigned NOT NULL DEFAULT '0',
  `hash` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

--
-- Dump dei dati per la tabella `avzp_captcha`
--

INSERT INTO `avzp_captcha` (`id`, `ptime`, `hash`) VALUES
(86, 1447959506, '71b6b4bb4b9c487ae89d1607f2f575dc4ae2fc68');

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_comments`
--

CREATE TABLE IF NOT EXISTS `avzp_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ownerid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `comment` text,
  `inmoderation` int(1) unsigned NOT NULL DEFAULT '0',
  `type` varchar(52) NOT NULL DEFAULT 'images',
  `IP` text,
  `private` int(1) unsigned DEFAULT '0',
  `anon` int(1) unsigned DEFAULT '0',
  `custom_data` text,
  PRIMARY KEY (`id`),
  KEY `ownerid` (`ownerid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_images`
--

CREATE TABLE IF NOT EXISTS `avzp_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `albumid` int(11) unsigned DEFAULT NULL,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `title` text,
  `desc` text,
  `location` text,
  `city` tinytext,
  `state` tinytext,
  `country` tinytext,
  `credit` text,
  `copyright` text,
  `commentson` int(1) NOT NULL DEFAULT '1',
  `show` int(1) NOT NULL DEFAULT '1',
  `date` datetime DEFAULT NULL,
  `sort_order` int(11) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `mtime` int(32) DEFAULT NULL,
  `hitcounter` int(11) unsigned DEFAULT '0',
  `total_value` int(11) unsigned DEFAULT '0',
  `total_votes` int(11) unsigned DEFAULT '0',
  `used_ips` longtext,
  `EXIFOrientation` varchar(52) DEFAULT NULL,
  `EXIFMake` varchar(52) DEFAULT NULL,
  `EXIFModel` varchar(52) DEFAULT NULL,
  `EXIFExposureTime` varchar(52) DEFAULT NULL,
  `EXIFFNumber` varchar(52) DEFAULT NULL,
  `EXIFFocalLength` varchar(52) DEFAULT NULL,
  `EXIFFocalLength35mm` varchar(52) DEFAULT NULL,
  `EXIFISOSpeedRatings` varchar(52) DEFAULT NULL,
  `EXIFDateTimeOriginal` varchar(52) DEFAULT NULL,
  `EXIFExposureBiasValue` varchar(52) DEFAULT NULL,
  `EXIFMeteringMode` varchar(52) DEFAULT NULL,
  `EXIFFlash` varchar(52) DEFAULT NULL,
  `EXIFImageWidth` varchar(52) DEFAULT NULL,
  `EXIFImageHeight` varchar(52) DEFAULT NULL,
  `EXIFContrast` varchar(52) DEFAULT NULL,
  `EXIFSharpness` varchar(52) DEFAULT NULL,
  `EXIFSaturation` varchar(52) DEFAULT NULL,
  `EXIFGPSLatitude` varchar(52) DEFAULT NULL,
  `EXIFGPSLatitudeRef` varchar(52) DEFAULT NULL,
  `EXIFGPSLongitude` varchar(52) DEFAULT NULL,
  `EXIFGPSLongitudeRef` varchar(52) DEFAULT NULL,
  `EXIFGPSAltitude` varchar(52) DEFAULT NULL,
  `EXIFGPSAltitudeRef` varchar(52) DEFAULT NULL,
  `custom_data` text,
  `EXIFWhiteBalance` varchar(52) DEFAULT NULL,
  `EXIFSubjectDistance` varchar(52) DEFAULT NULL,
  `thumbX` int(10) unsigned DEFAULT NULL,
  `thumbY` int(10) unsigned DEFAULT NULL,
  `thumbW` int(10) unsigned DEFAULT NULL,
  `thumbH` int(10) unsigned DEFAULT NULL,
  `rating` float NOT NULL DEFAULT '0',
  `rating_status` int(1) unsigned DEFAULT '3',
  `hasMetadata` int(1) DEFAULT '0',
  `EXIFDescription` varchar(52) DEFAULT NULL,
  `IPTCObjectName` mediumtext,
  `IPTCImageHeadline` mediumtext,
  `IPTCImageCaption` mediumtext,
  `IPTCImageCaptionWriter` varchar(32) DEFAULT NULL,
  `EXIFDateTime` varchar(52) DEFAULT NULL,
  `EXIFDateTimeDigitized` varchar(52) DEFAULT NULL,
  `IPTCDateCreated` varchar(8) DEFAULT NULL,
  `IPTCTimeCreated` varchar(11) DEFAULT NULL,
  `IPTCDigitizeDate` varchar(8) DEFAULT NULL,
  `IPTCDigitizeTime` varchar(11) DEFAULT NULL,
  `EXIFArtist` varchar(52) DEFAULT NULL,
  `IPTCImageCredit` varchar(32) DEFAULT NULL,
  `IPTCByLine` varchar(32) DEFAULT NULL,
  `IPTCByLineTitle` varchar(32) DEFAULT NULL,
  `IPTCSource` varchar(32) DEFAULT NULL,
  `IPTCContact` varchar(128) DEFAULT NULL,
  `EXIFCopyright` varchar(128) DEFAULT NULL,
  `IPTCCopyright` varchar(128) DEFAULT NULL,
  `EXIFFLensType` varchar(52) DEFAULT NULL,
  `EXIFLensInfo` varchar(52) DEFAULT NULL,
  `EXIFFocalLengthIn35mmFilm` varchar(52) DEFAULT NULL,
  `IPTCCity` varchar(32) DEFAULT NULL,
  `IPTCSubLocation` varchar(32) DEFAULT NULL,
  `IPTCState` varchar(32) DEFAULT NULL,
  `IPTCLocationCode` varchar(3) DEFAULT NULL,
  `IPTCLocationName` varchar(64) DEFAULT NULL,
  `IPTCOriginatingProgram` varchar(32) DEFAULT NULL,
  `IPTCProgramVersion` varchar(10) DEFAULT NULL,
  `EXIFLensType` varchar(52) DEFAULT NULL,
  `watermark` varchar(255) DEFAULT NULL,
  `watermark_use` int(1) DEFAULT '7',
  `owner` varchar(64) DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `codeblock` text,
  `user` varchar(64) DEFAULT '',
  `password` varchar(64) DEFAULT NULL,
  `password_hint` text,
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`,`albumid`),
  KEY `avzp_images_ibfk1` (`albumid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dump dei dati per la tabella `avzp_images`
--

INSERT INTO `avzp_images` (`id`, `albumid`, `filename`, `title`, `desc`, `location`, `city`, `state`, `country`, `credit`, `copyright`, `commentson`, `show`, `date`, `sort_order`, `height`, `width`, `mtime`, `hitcounter`, `total_value`, `total_votes`, `used_ips`, `EXIFOrientation`, `EXIFMake`, `EXIFModel`, `EXIFExposureTime`, `EXIFFNumber`, `EXIFFocalLength`, `EXIFFocalLength35mm`, `EXIFISOSpeedRatings`, `EXIFDateTimeOriginal`, `EXIFExposureBiasValue`, `EXIFMeteringMode`, `EXIFFlash`, `EXIFImageWidth`, `EXIFImageHeight`, `EXIFContrast`, `EXIFSharpness`, `EXIFSaturation`, `EXIFGPSLatitude`, `EXIFGPSLatitudeRef`, `EXIFGPSLongitude`, `EXIFGPSLongitudeRef`, `EXIFGPSAltitude`, `EXIFGPSAltitudeRef`, `custom_data`, `EXIFWhiteBalance`, `EXIFSubjectDistance`, `thumbX`, `thumbY`, `thumbW`, `thumbH`, `rating`, `rating_status`, `hasMetadata`, `EXIFDescription`, `IPTCObjectName`, `IPTCImageHeadline`, `IPTCImageCaption`, `IPTCImageCaptionWriter`, `EXIFDateTime`, `EXIFDateTimeDigitized`, `IPTCDateCreated`, `IPTCTimeCreated`, `IPTCDigitizeDate`, `IPTCDigitizeTime`, `EXIFArtist`, `IPTCImageCredit`, `IPTCByLine`, `IPTCByLineTitle`, `IPTCSource`, `IPTCContact`, `EXIFCopyright`, `IPTCCopyright`, `EXIFFLensType`, `EXIFLensInfo`, `EXIFFocalLengthIn35mmFilm`, `IPTCCity`, `IPTCSubLocation`, `IPTCState`, `IPTCLocationCode`, `IPTCLocationName`, `IPTCOriginatingProgram`, `IPTCProgramVersion`, `EXIFLensType`, `watermark`, `watermark_use`, `owner`, `filesize`, `codeblock`, `user`, `password`, `password_hint`) VALUES
(1, 1, 'torino-murazzi.jpg', 'I murazzi di Torino', '', '', '', '', '', 'cesare2008', NULL, 1, 1, '2008-07-31 14:16:42', NULL, 532, 800, 1447959465, 6, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '45,063336629974', 'N', '7,6975536299907', 'E', NULL, NULL, 'http://www.sxc.hu/photo/991969', NULL, NULL, NULL, NULL, NULL, NULL, 0, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_menu`
--

CREATE TABLE IF NOT EXISTS `avzp_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `title` text,
  `link` varchar(255) NOT NULL DEFAULT '',
  `include_li` int(1) unsigned DEFAULT '1',
  `type` varchar(16) NOT NULL DEFAULT '',
  `sort_order` varchar(48) NOT NULL DEFAULT '',
  `show` int(1) unsigned NOT NULL DEFAULT '1',
  `menuset` varchar(32) NOT NULL DEFAULT '',
  `span_id` varchar(43) DEFAULT NULL,
  `span_class` varchar(43) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_news`
--

CREATE TABLE IF NOT EXISTS `avzp_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` text,
  `content` text,
  `extracontent` text,
  `show` int(1) unsigned NOT NULL DEFAULT '1',
  `date` datetime DEFAULT NULL,
  `titlelink` varchar(255) NOT NULL DEFAULT '',
  `commentson` int(1) unsigned DEFAULT '0',
  `codeblock` text,
  `author` varchar(64) NOT NULL DEFAULT '',
  `lastchange` datetime DEFAULT NULL,
  `lastchangeauthor` varchar(64) NOT NULL DEFAULT '',
  `hitcounter` int(11) unsigned DEFAULT '0',
  `permalink` int(1) unsigned NOT NULL DEFAULT '0',
  `locked` int(1) unsigned NOT NULL DEFAULT '0',
  `expiredate` datetime DEFAULT NULL,
  `total_votes` int(11) unsigned DEFAULT '0',
  `total_value` int(11) unsigned DEFAULT '0',
  `rating` float NOT NULL DEFAULT '0',
  `used_ips` longtext,
  `rating_status` int(1) unsigned DEFAULT '3',
  `sticky` int(1) DEFAULT '0',
  `custom_data` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `titlelink` (`titlelink`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_news2cat`
--

CREATE TABLE IF NOT EXISTS `avzp_news2cat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) unsigned NOT NULL DEFAULT '0',
  `news_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_news_categories`
--

CREATE TABLE IF NOT EXISTS `avzp_news_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` text,
  `titlelink` varchar(255) NOT NULL,
  `permalink` int(1) unsigned NOT NULL DEFAULT '0',
  `hitcounter` int(11) unsigned DEFAULT '0',
  `user` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '',
  `password` varchar(64) DEFAULT NULL,
  `password_hint` text,
  `parentid` int(11) DEFAULT NULL,
  `sort_order` varchar(48) DEFAULT NULL,
  `desc` text,
  `custom_data` text,
  `show` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cat_link` (`titlelink`),
  UNIQUE KEY `titlelink` (`titlelink`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_obj_to_tag`
--

CREATE TABLE IF NOT EXISTS `avzp_obj_to_tag` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tagid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` tinytext CHARACTER SET utf8,
  `objectid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tagid` (`tagid`),
  KEY `objectid` (`objectid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_options`
--

CREATE TABLE IF NOT EXISTS `avzp_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ownerid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(191) DEFAULT NULL,
  `value` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `theme` varchar(127) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_option` (`name`,`ownerid`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=557 ;

--
-- Dump dei dati per la tabella `avzp_options`
--

INSERT INTO `avzp_options` (`id`, `ownerid`, `name`, `value`, `theme`, `creator`) VALUES
(1, 0, 'zenphoto_release', '8326', NULL, NULL),
(3, 0, 'website_title', '', NULL, NULL),
(4, 0, 'website_url', '', NULL, NULL),
(5, 0, 'time_offset', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(6, 0, 'mod_rewrite', '1', NULL, NULL),
(7, 0, 'mod_rewrite_image_suffix', '.html', NULL, 'zp-core/setup/setup-option-defaults.php'),
(8, 0, 'server_protocol', 'http', NULL, 'zp-core/setup/setup-option-defaults.php'),
(9, 0, 'charset', 'UTF-8', NULL, 'zp-core/setup/setup-option-defaults.php'),
(10, 0, 'image_quality', '85', NULL, 'zp-core/setup/setup-option-defaults.php'),
(11, 0, 'thumb_quality', '75', NULL, 'zp-core/setup/setup-option-defaults.php'),
(12, 0, 'image_size', '595', NULL, 'zp-core/setup/setup-option-defaults.php'),
(13, 0, 'image_use_longest_side', '1', NULL, NULL),
(14, 0, 'image_allow_upscale', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(15, 0, 'thumb_size', '100', NULL, 'zp-core/setup/setup-option-defaults.php'),
(16, 0, 'thumb_crop', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(17, 0, 'thumb_crop_width', '85', NULL, 'zp-core/setup/setup-option-defaults.php'),
(18, 0, 'thumb_crop_height', '85', NULL, 'zp-core/setup/setup-option-defaults.php'),
(19, 0, 'thumb_sharpen', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(20, 0, 'image_sharpen', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(21, 0, 'albums_per_page', '5', NULL, 'zp-core/setup/setup-option-defaults.php'),
(22, 0, 'images_per_page', '15', NULL, 'zp-core/setup/setup-option-defaults.php'),
(23, 0, 'gallery_password', '', NULL, NULL),
(24, 0, 'gallery_hint', '', NULL, NULL),
(25, 0, 'search_password', '', NULL, 'zp-core/setup/setup-option-defaults.php'),
(26, 0, 'search_hint', '', NULL, 'zp-core/setup/setup-option-defaults.php'),
(27, 0, 'gmaps_apikey', 'ABQIAAAAvLwvqGr6E-Lmva6_jvr2ghTzxbDFtZ3XiiUb6nqcH9hfKDkDzRTAZhcyrfoD7PRHywaIdb0umMidgg', NULL, NULL),
(28, 0, 'album_session', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(29, 0, 'perform_watermark', '0', NULL, NULL),
(30, 0, 'watermark_h_offset', '90', NULL, 'zp-core/setup/setup-option-defaults.php'),
(31, 0, 'watermark_w_offset', '90', NULL, 'zp-core/setup/setup-option-defaults.php'),
(32, 0, 'watermark_image', 'watermarks/watermark.png', NULL, NULL),
(33, 0, 'watermark_scale', '5', NULL, 'zp-core/setup/setup-option-defaults.php'),
(34, 0, 'watermark_allow_upscale', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(35, 0, 'perform_video_watermark', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(36, 0, 'video_watermark_image', 'watermarks/watermark-video.png', NULL, NULL),
(37, 0, 'spam_filter', 'none', NULL, 'zp-core/setup/setup-option-defaults.php'),
(38, 0, 'email_new_comments', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(39, 0, 'gallery_sorttype', 'id', NULL, NULL),
(40, 0, 'gallery_sortdirection', '0', NULL, NULL),
(41, 0, 'image_sorttype', 'Filename', NULL, 'zp-core/setup/setup-option-defaults.php'),
(42, 0, 'image_sortdirection', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(43, 0, 'hotlink_protection', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(44, 0, 'current_theme', 'm9', NULL, NULL),
(45, 0, 'feed_items', '10', NULL, 'zp-core/setup/setup-option-defaults.php'),
(46, 0, 'feed_imagesize', '240', NULL, 'zp-core/setup/setup-option-defaults.php'),
(47, 0, 'search_fields', '32767', NULL, 'zp-core/setup/setup-option-defaults.php'),
(48, 0, 'allowed_tags', 'a => (href => () title => ())\r\nabbr => (title => ())\r\nacronym => (title => ())\r\nb => ()\r\nblockquote => (cite => ())\r\ncode => ()\r\nem => ()\r\ni => () \r\nstrike => ()\r\nstrong => ()\r\nul => ()\r\nol => ()\r\nli => ()\r\n', NULL, 'zp-core/setup/setup-option-defaults.php'),
(49, 0, 'style_tags', 'abbr => (title => ())\nacronym => (title => ())\nb => ()\nem => ()\ni => () \nstrike => ()\nstrong => ()\n', NULL, 'zp-core/setup/setup-option-defaults.php'),
(50, 0, 'comment_name_required', 'required', NULL, 'zp-core/setup/setup-option-defaults.php'),
(51, 0, 'comment_email_required', 'required', NULL, 'zp-core/setup/setup-option-defaults.php'),
(52, 0, 'comment_web_required', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(53, 0, 'Use_Captcha', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(54, 0, 'full_image_quality', '75', NULL, 'zp-core/setup/setup-option-defaults.php'),
(55, 0, 'persistent_archive', '0', NULL, NULL),
(56, 0, 'protect_full_image', 'Unprotected', NULL, 'zp-core/setup/setup-option-defaults.php'),
(57, 0, 'date_format', '%c', NULL, 'zp-core/setup/setup-option-defaults.php'),
(58, 0, 'zp_plugin_google_maps', '1', NULL, NULL),
(59, 0, 'zp_plugin_rating', '2181', NULL, NULL),
(60, 0, 'zp_plugin_image_album_statistics', '129', NULL, NULL),
(61, 0, 'zp_plugin_flowplayer', '1', NULL, NULL),
(62, 0, 'zp_plugin_dynamic-locale', '0', NULL, NULL),
(63, 0, 'zp_plugin_flvplayer', '0', NULL, NULL),
(64, 0, 'zp_plugin_flv_playlist', '0', NULL, NULL),
(65, 0, 'zp_plugin_GoogleCheckout', '0', NULL, NULL),
(66, 0, 'zp_plugin_print_album_menu', '0', NULL, NULL),
(67, 0, 'zp_plugin_shutterfly', '0', NULL, NULL),
(68, 0, 'zp_plugin_slideshow', '0', NULL, NULL),
(69, 0, 'zp_plugin_tag_suggest', '0', NULL, NULL),
(70, 0, 'zp_plugin_user_logout', '0', NULL, NULL),
(71, 0, 'zp_plugin_zenPaypal', '0', NULL, NULL),
(72, 0, 'use_lock_image', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(73, 0, 'gallery_user', '', NULL, NULL),
(74, 0, 'search_user', '', NULL, 'zp-core/setup/setup-option-defaults.php'),
(75, 0, 'album_use_new_image_date', '0', NULL, NULL),
(76, 0, 'thumb_select_images', '1', NULL, NULL),
(78, 0, 'multi_lingual', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(79, 0, 'login_user_field', '1', NULL, NULL),
(80, 0, 'tagsort', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(81, 0, 'albumimagesort', 'date', NULL, 'zp-core/setup/setup-option-defaults.php'),
(82, 0, 'albumimagedirection', '', NULL, 'zp-core/setup/setup-option-defaults.php'),
(83, 0, 'Allow_comments', '1', NULL, NULL),
(84, 0, 'Allow_search', '1', NULL, NULL),
(85, 0, 'Theme_colors', 'light', NULL, NULL),
(86, 0, 'admin_reset_date', '1', NULL, NULL),
(87, 0, 'Action', 'moderate', NULL, NULL),
(88, 0, 'flow_player_width', '320', NULL, NULL),
(89, 0, 'flow_player_height', '240', NULL, NULL),
(90, 0, 'flow_player_controlbarbackgroundcolor', '0x567890', NULL, NULL),
(91, 0, 'flow_player_controlsareabordercolor', '0x567890', NULL, NULL),
(92, 0, 'flow_player_autoplay', '', NULL, NULL),
(93, 0, 'image_use_side', 'longest', NULL, 'zp-core/setup/setup-option-defaults.php'),
(94, 0, 'allowed_tags_default', 'a => (href =>() title =>() target=>() class=>() id=>())\nabbr =>(class=>() id=>() title =>())\nacronym =>(class=>() id=>() title =>())\nb => (class=>() id=>() )\nblockquote =>(class=>() id=>() cite =>())\nbr => (class=>() id=>() )\ncode => (class=>() id=>() )\nem => (class=>() id=>() )\ni => (class=>() id=>() ) \nstrike => (class=>() id=>() )\nstrong => (class=>() id=>() )\nul => (class=>() id=>())\nol => (class=>() id=>())\nli => (class=>() id=>())\np => (class=>() id=>() style=>())\nh1=>(class=>() id=>() style=>())\nh2=>(class=>() id=>() style=>())\nh3=>(class=>() id=>() style=>())\nh4=>(class=>() id=>() style=>())\nh5=>(class=>() id=>() style=>())\nh6=>(class=>() id=>() style=>())\npre=>(class=>() id=>() style=>())\naddress=>(class=>() id=>() style=>())\nspan=>(class=>() id=>() style=>())\ndiv=>(class=>() id=>() style=>())\nimg=>(class=>() id=>() style=>() src=>() title=>() alt=>() width=>() height=>())\n', NULL, NULL),
(95, 0, 'zp_plugin_admin_toolbox', '1', NULL, NULL),
(96, 0, 'zp_plugin_class-textobject', '0', NULL, NULL),
(97, 0, 'zp_plugin_contact_form', '0', NULL, NULL),
(98, 0, 'zp_plugin_paged_thumbs_nav', '0', NULL, NULL),
(99, 0, 'zp_plugin_register_user', '0', NULL, NULL),
(100, 0, 'zp_plugin_static_html_cache', '0', NULL, NULL),
(101, 0, 'zp_plugin_viewer_size_image', '0', NULL, NULL),
(102, 0, 'cache_full_image', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(103, 0, 'custom_index_page', '', NULL, 'zp-core/setup/setup-option-defaults.php'),
(104, 0, 'picture_of_the_day', 'a:3:{s:3:"day";N;s:6:"folder";N;s:8:"filename";N;}', NULL, 'zp-core/setup/setup-option-defaults.php'),
(105, 0, 'exact_tag_match', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(106, 0, 'EXIFMake', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(107, 0, 'EXIFModel', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(108, 0, 'EXIFExposureTime', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(109, 0, 'EXIFFNumber', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(110, 0, 'EXIFFocalLength', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(111, 0, 'EXIFFocalLength35mm', '1', NULL, NULL),
(112, 0, 'EXIFISOSpeedRatings', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(113, 0, 'EXIFDateTimeOriginal', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(114, 0, 'EXIFExposureBiasValue', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(115, 0, 'EXIFMeteringMode', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(116, 0, 'EXIFFlash', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(117, 0, 'EXIFOrientation', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(118, 0, 'EXIFImageWidth', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(119, 0, 'EXIFImageHeight', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(120, 0, 'EXIFContrast', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(121, 0, 'EXIFSharpness', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(122, 0, 'EXIFSaturation', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(123, 0, 'EXIFWhiteBalance', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(124, 0, 'EXIFSubjectDistance', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(125, 0, 'EXIFGPSLatitude', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(126, 0, 'EXIFGPSLatitudeRef', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(127, 0, 'EXIFGPSLongitude', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(128, 0, 'EXIFGPSLongitudeRef', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(129, 0, 'EXIFGPSAltitude', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(130, 0, 'EXIFGPSAltitudeRef', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(131, 0, 'user_registration_page', '', NULL, NULL),
(132, 0, 'user_registration_text', 'Registrazione', NULL, NULL),
(133, 0, 'user_registration_tip', 'Fare clic qui per registrarsi al sito.', NULL, NULL),
(134, 0, 'auto_rotate', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(135, 0, 'flow_player_backgroundcolor', '', NULL, NULL),
(136, 0, 'gmaps_show_all_album_points', '0', NULL, NULL),
(137, 0, 'gmaps_width', '595', NULL, NULL),
(138, 0, 'gmaps_height', '300', NULL, NULL),
(139, 0, 'Use_flv_playlist', '', NULL, NULL),
(140, 0, 'flv_playlist_option', '', NULL, NULL),
(141, 0, 'zenphoto_captcha_lenght', '5', NULL, NULL),
(142, 0, 'zenphoto_captcha_key', '827f12b4fcff6cf44f33d07ab917ef67', NULL, 'zp-core/zp-extensions/captcha/zenphoto.php'),
(143, 0, 'zenphoto_captcha_string', 'abcdefghijkmnpqrstuvwxyz23456789ABCDEFGHJKLMNPQRSTUVWXYZ', NULL, 'zp-core/zp-extensions/captcha/zenphoto.php'),
(144, 0, 'feed_sortorder', 'latest', NULL, 'zp-core/setup/setup-option-defaults.php'),
(145, 0, 'feed_enclosure', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(146, 0, 'feed_mediarss', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(147, 0, 'zp_plugin_class-video', '4105', NULL, 'zp-core/setup/setup-option-defaults.php'),
(417, 0, 'default_copyright', 'Copyright 2011: prvmaster2.altervista.org', NULL, 'zp-core/setup/setup-option-defaults.php'),
(149, 0, 'IPTC_encoding', 'ISO-8859-1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(150, 0, 'UTF8_image_URI', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(151, 0, 'captcha', 'zenphoto', NULL, 'zp-core/setup/setup-option-defaults.php'),
(152, 0, 'sharpen_amount', '40', NULL, 'zp-core/setup/setup-option-defaults.php'),
(153, 0, 'sharpen_radius', '0,5', NULL, 'zp-core/setup/setup-option-defaults.php'),
(154, 0, 'sharpen_threshold', '3', NULL, 'zp-core/setup/setup-option-defaults.php'),
(155, 0, 'gmaps_maptype_P', '0', NULL, NULL),
(156, 0, 'gmaps_maptype_3D', '0', NULL, NULL),
(157, 0, 'gmaps_maptype_map', '1', NULL, NULL),
(158, 0, 'gmaps_maptype_hyb', '1', NULL, NULL),
(159, 0, 'gmaps_maptype_sat', '1', NULL, NULL),
(160, 0, 'gmaps_control_maptype', '1', NULL, NULL),
(161, 0, 'gmaps_control', 'None', NULL, NULL),
(162, 0, 'gmaps_background', '', NULL, NULL),
(163, 0, 'gmaps_starting_map', 'G_SATELLITE_MAP', NULL, NULL),
(164, 0, 'locale', 'it_IT', NULL, 'zp-core/setup/setup-option-defaults.php'),
(165, 0, 'zenphoto_captcha_length', '5', NULL, 'zp-core/zp-extensions/captcha/zenphoto.php'),
(166, 0, 'feed_items_albums', '10', NULL, 'zp-core/setup/setup-option-defaults.php'),
(167, 0, 'feed_imagesize_albums', '240', NULL, 'zp-core/setup/setup-option-defaults.php'),
(168, 0, 'feed_sortorder_albums', 'latest', NULL, 'zp-core/setup/setup-option-defaults.php'),
(169, 0, 'libauth_version', '3', NULL, NULL),
(170, 0, 'feed_cache', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(171, 0, 'feed_cache_expire', '86400', NULL, 'zp-core/setup/setup-option-defaults.php'),
(172, 0, 'EXIFDescription', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(173, 0, 'IPTCObjectName', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(174, 0, 'IPTCImageHeadline', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(175, 0, 'IPTCImageCaption', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(176, 0, 'IPTCImageCaptionWriter', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(177, 0, 'EXIFDateTime', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(178, 0, 'EXIFDateTimeDigitized', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(179, 0, 'IPTCDateCreated', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(180, 0, 'IPTCTimeCreated', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(181, 0, 'IPTCDigitizeDate', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(182, 0, 'IPTCDigitizeTime', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(183, 0, 'EXIFArtist', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(184, 0, 'IPTCImageCredit', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(185, 0, 'IPTCByLine', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(186, 0, 'IPTCByLineTitle', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(187, 0, 'IPTCSource', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(188, 0, 'IPTCContact', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(189, 0, 'EXIFCopyright', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(190, 0, 'IPTCCopyright', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(191, 0, 'EXIFFLensType', '0', NULL, NULL),
(192, 0, 'EXIFLensInfo', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(193, 0, 'EXIFFocalLengthIn35mmFilm', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(194, 0, 'IPTCCity', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(195, 0, 'IPTCSubLocation', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(196, 0, 'IPTCState', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(197, 0, 'IPTCLocationCode', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(198, 0, 'IPTCLocationName', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(199, 0, 'IPTCOriginatingProgram', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(200, 0, 'IPTCProgramVersion', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(201, 0, 'thumb_gray', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(202, 0, 'image_gray', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(204, 0, 'search_no_albums', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(205, 0, 'defined_groups', 'a:6:{i:0;s:14:"administrators";i:1;s:7:"viewers";i:2;s:5:"bozos";i:3;s:14:"album managers";i:4;s:7:"default";i:5;s:7:"newuser";}', NULL, NULL),
(206, 0, 'zp_plugin_comment_form', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(207, 0, 'comment_form_albums', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(208, 0, 'comment_form_images', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(209, 0, 'comment_body_requiired', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(210, 0, 'zp_plugin_zenphoto_sendmail', '4101', NULL, 'zp-core/setup/setup-option-defaults.php'),
(211, 0, 'gallery_page_unprotected_register', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(212, 0, 'gallery_page_unprotected_contact', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(213, 0, 'RSS_album_image', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(214, 0, 'RSS_comments', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(215, 0, 'RSS_articles', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(216, 0, 'RSS_article_comments', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(217, 0, 'tinyMCEPresent', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(218, 0, 'zp_plugin_class-video_mov_w', '520', NULL, 'zp-core/zp-extensions/class-video.php'),
(219, 0, 'zp_plugin_class-video_mov_h', '390', NULL, 'zp-core/zp-extensions/class-video.php'),
(220, 0, 'zp_plugin_class-video_3gp_w', '520', NULL, 'zp-core/zp-extensions/class-video.php'),
(221, 0, 'zp_plugin_class-video_3gp_h', '390', NULL, 'zp-core/zp-extensions/class-video.php'),
(222, 0, 'zenphoto_seo_lowercase', '1', NULL, NULL),
(223, 0, 'comment_form_addresses', '0', NULL, 'zp-core/zp-extensions/comment_form.php'),
(224, 0, 'comment_form_require_addresses', '0', NULL, 'zp-core/zp-extensions/comment_form.php'),
(225, 0, 'comment_form_members_only', '0', NULL, 'zp-core/zp-extensions/comment_form.php'),
(226, 0, 'comment_form_articles', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(227, 0, 'comment_form_pages', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(228, 0, 'comment_form_rss', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(229, 0, 'Allow_search', '1', 'default', NULL),
(230, 0, 'Theme_colors', 'light', 'default', NULL),
(231, 0, 'rating_recast', '1', NULL, 'zp-core/zp-extensions/rating.php'),
(232, 0, 'rating_split_stars', '1', NULL, 'zp-core/zp-extensions/rating.php'),
(233, 0, 'rating_status', '3', NULL, 'zp-core/zp-extensions/rating.php'),
(234, 0, 'rating_image_individual_control', '0', NULL, 'zp-core/zp-extensions/rating.php'),
(235, 0, 'extra_auth_hash_text', '', NULL, 'zp-core/lib-auth.php'),
(236, 0, 'min_password_lenght', '6', NULL, 'zp-core/lib-auth.php'),
(237, 0, 'password_pattern', 'A-Za-z0-9   |   ~!@#$%&*_+`-(),.\\^''"/[]{}=:;?\\|', NULL, 'zp-core/lib-auth.php'),
(238, 0, 'EXIFLensType', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(239, 0, 'AlbumThumbSelectField', 'ID', NULL, 'zp-core/setup/setup-option-defaults.php'),
(240, 0, 'AlbumThumbSelectDirection', 'DESC', NULL, 'zp-core/setup/setup-option-defaults.php'),
(241, 0, 'AlbumThumbSelecorText', 'più recente', NULL, 'zp-core/setup/setup-option-defaults.php'),
(243, 0, 'Page-Hitcounter-index', '10', NULL, NULL),
(244, 0, 'site_email', 'zenphoto@project0101.altervista.org', NULL, 'zp-core/setup/setup-option-defaults.php'),
(245, 0, 'comment_form_private', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(246, 0, 'comment_form_anon', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(247, 0, 'zenpage_news_page', 'news', NULL, NULL),
(248, 0, 'zenpage_pages_page', 'pages', NULL, NULL),
(249, 0, 'Zenphoto_theme_list', 'a:1:{i:0;s:7:"default";}', NULL, NULL),
(250, 0, 'zp_plugin_deprecated-functions', '4105', NULL, NULL),
(251, 0, 'zp_plugin_zenphoto_news', '0', NULL, 'zp-core/setup/setup-option-defaults.php'),
(252, 0, 'zp_plugin_PHPMailer', '0', NULL, NULL),
(253, 0, 'gallery_page_unprotected_archive', '0', NULL, NULL),
(254, 0, 'gallery_page_unprotected_password_form', '0', NULL, NULL),
(255, 0, 'gallery_page_unprotected_index', '0', NULL, NULL),
(256, 0, 'zenphoto_captcha_font', '', NULL, NULL),
(257, 0, 'zenphoto_captcha_image', '', NULL, NULL),
(258, 0, 'zp_plugin_hitcounter', '129', NULL, 'zp-core/setup/setup-option-defaults.php'),
(259, 0, 'zp_plugin_security-logger', '4105', NULL, 'zp-core/setup/setup-option-defaults.php'),
(260, 0, 'logger_log_guests', '1', NULL, 'zp-core/zp-extensions/security-logger.php'),
(261, 0, 'logger_log_admin', '1', NULL, 'zp-core/zp-extensions/security-logger.php'),
(262, 0, 'logger_log_type', 'all', NULL, 'zp-core/zp-extensions/security-logger.php'),
(265, 0, 'tinymce_zenphoto', 'zenphoto-default.js.php', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(264, 0, 'zp_plugin_tiny_mce', '2053', NULL, 'zp-core/setup/setup-option-defaults.php'),
(266, 0, 'tinymce_zenpage', 'zenpage-default-full.js.php', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(268, 0, 'hitcounter_ignoreIPList_enable', '0', NULL, 'zp-core/zp-extensions/hitcounter.php'),
(269, 0, 'hitcounter_ignoreSearchCrawlers_enable', '0', NULL, 'zp-core/zp-extensions/hitcounter.php'),
(270, 0, 'hitcounter_ignoreIPList', '', NULL, 'zp-core/zp-extensions/hitcounter.php'),
(271, 0, 'hitcounter_searchCrawlerList', 'Teoma,alexa, froogle, Gigabot,inktomi, looksmart, URL_Spider_SQL,Firefly, NationalDirectory, Ask Jeeves,TECNOSEEK, InfoSeek, WebFindBot, girafabot, crawler,www.galaxy.com, Googlebot, Scooter, Slurp, msnbot, appie, FAST, WebBug, Spade, ZyBorg, rabaz ,Baiduspider, Feedfetcher-Google, TechnoratiSnoop, Rankivabot, Mediapartners-Google, Sogou web spider, WebAlta Crawler', NULL, 'zp-core/zp-extensions/hitcounter.php'),
(272, 0, 'time_zone', '', NULL, NULL),
(273, 0, 'edit_in_place', '0', NULL, NULL),
(335, 0, 'zenphoto_install', '{5c40b7f6-677a-2863-2b0b-ef0b008a6a4e}', NULL, NULL),
(336, 0, 'feed_hitcounter', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(338, 0, 'album_publish', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(339, 0, 'image_publish', '1', NULL, 'zp-core/setup/setup-option-defaults.php'),
(340, 0, 'deprecated_getZenpageHitcounter', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(341, 0, 'deprecated_printImageRating', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(342, 0, 'deprecated_printAlbumRating', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(343, 0, 'deprecated_printImageEXIFData', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(344, 0, 'deprecated_printCustomSizedImageMaxHeight', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(345, 0, 'deprecated_getCommentDate', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(346, 0, 'deprecated_getCommentTime', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(347, 0, 'deprecated_hitcounter', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(348, 0, 'deprecated_my_truncate_string', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(349, 0, 'deprecated_getImageEXIFData', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(350, 0, 'deprecated_getAlbumPlace', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(351, 0, 'deprecated_printAlbumPlace', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(352, 0, 'deprecated_zenpageHitcounter', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(353, 0, 'deprecated_rewrite_path_zenpage', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(354, 0, 'deprecated_getNewsImageTags', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(355, 0, 'deprecated_printNewsImageTags', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(356, 0, 'deprecated_getNumSubalbums', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(357, 0, 'deprecated_getAllSubalbums', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(358, 0, 'deprecated_addPluginScript', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(359, 0, 'deprecated_zenJavascript', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(360, 0, 'deprecated_normalizeColumns', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(361, 0, 'deprecated_printParentPagesBreadcrumb', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(362, 0, 'deprecated_isMyAlbum', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(363, 0, 'deprecated_getSubCategories', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(364, 0, 'deprecated_inProtectedNewsCategory', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(365, 0, 'deprecated_isProtectedNewsCategory', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(366, 0, 'deprecated_getParentNewsCategories', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(367, 0, 'deprecated_getCategoryTitle', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(368, 0, 'deprecated_getCategoryID', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(369, 0, 'deprecated_getCategoryParentID', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(370, 0, 'deprecated_getCategorySortOrder', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(371, 0, 'deprecated_getParentPages', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(372, 0, 'deprecated_isProtectedPage', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(373, 0, 'deprecated_isMyPage', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(374, 0, 'deprecated_checkPagePassword', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(375, 0, 'deprecated_isMyNews', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(376, 0, 'deprecated_checkNewsAccess', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(377, 0, 'deprecated_checkNewsCategoryPassword', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(378, 0, 'deprecated_getCurrentNewsCategory', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(379, 0, 'deprecated_getCurrentNewsCategoryID', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(380, 0, 'deprecated_getCurrentNewsCategoryParentID', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(381, 0, 'deprecated_inNewsCategory', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(382, 0, 'deprecated_inSubNewsCategoryOf', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(383, 0, 'deprecated_isSubNewsCategoryOf', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(384, 0, 'deprecated_printNewsReadMoreLink', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(385, 0, 'deprecated_getNewsContentShorten', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(386, 0, 'deprecated_checkForPassword', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(387, 0, 'deprecated_printAlbumMap', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(388, 0, 'deprecated_printImageMap', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(389, 0, 'deprecated_setupAllowedMaps', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(390, 0, 'deprecated_printPreloadScript', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(391, 0, 'deprecated_processExpired', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(392, 0, 'deprecated_getParentItems', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(393, 0, 'deprecated_getPages', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(394, 0, 'deprecated_getNewsArticles', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(395, 0, 'deprecated_countArticles', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(396, 0, 'deprecated_getLimitAndOffset', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(397, 0, 'deprecated_getTotalArticles', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(398, 0, 'deprecated_getAllArticleDates', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(399, 0, 'deprecated_getCurrentNewsPage', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(400, 0, 'deprecated_getCurrentAdminNewsPage', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(401, 0, 'deprecated_getCombiNews', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(402, 0, 'deprecated_countCombiNews', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(403, 0, 'deprecated_getCategoryLink', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(404, 0, 'deprecated_getCategory', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(405, 0, 'deprecated_getAllCategories', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(406, 0, 'deprecated_isProtectedAlbum', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(407, 0, 'deprecated_getSearchURL', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(408, 0, 'deprecated_printPasswordForm', '1', NULL, 'zp-core/zp-extensions/deprecated-functions.php'),
(409, 0, 'tinymce_tinyzenpage_customimagesize', '400', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(410, 0, 'tinymce_tinyzenpage_customthumb_size', '120', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(411, 0, 'tinymce_tinyzenpage_customthumb_cropwidth', '120', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(412, 0, 'tinymce_tinyzenpage_customthumb_cropheight', '120', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(413, 0, 'tinymce_tinyzenpage_flowplayer_width', '320', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(414, 0, 'tinymce_tinyzenpage_flowplayer_height', '240', NULL, 'zp-core/zp-extensions/tiny_mce.php'),
(415, 0, 'comment_form_showURL', '1', NULL, 'zp-core/zp-extensions/comment_form.php'),
(416, 0, 'zp_plugin_zenphoto_seo', '2053', NULL, NULL),
(418, 0, 'fullsizeimage_watermark', NULL, NULL, 'zp-core/setup/setup-option-defaults.php'),
(419, 0, 'gallery_data', 'a:17:{s:21:"gallery_sortdirection";i:0;s:16:"gallery_sorttype";s:2:"id";s:13:"gallery_title";s:23:"Galleria di project0101";s:19:"Gallery_description";s:107:"Puoi inserire la descrizione della tua Gallery nel tab opzioni del pannello di amministrazione di ZenPhoto.";s:16:"gallery_password";s:0:"";s:12:"gallery_user";s:0:"";s:12:"gallery_hint";s:0:"";s:10:"hitcounter";s:1:"7";s:13:"current_theme";s:2:"m9";s:13:"website_title";s:0:"";s:11:"website_url";s:0:"";s:16:"gallery_security";s:6:"public";s:16:"login_user_field";s:1:"1";s:24:"album_use_new_image_date";s:1:"0";s:19:"thumb_select_images";s:1:"1";s:18:"persistent_archive";s:1:"0";s:17:"unprotected_pages";s:43:"a:2:{i:0;s:8:"register";i:1;s:7:"contact";}";}', NULL, 'zp-core/setup/setup-option-defaults.php'),
(420, 0, 'strong_hash', '0', NULL, 'zp-core/lib-auth.php'),
(421, 0, 'zp_plugin_federated_logon', '0', NULL, NULL),
(422, 0, 'zp_plugin_flowplayer3_playlist', '0', NULL, NULL),
(423, 0, 'gmap_width', '595', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(424, 0, 'gmap_height', '300', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(425, 0, 'gmap_map', '1', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(426, 0, 'gmap_hybrid', '1', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(427, 0, 'gmap_satellite', '1', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(428, 0, 'gmap_terrain', '1', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(429, 0, 'gmap_control_size', 'small', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(430, 0, 'gmap_control', 'horizontal', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(431, 0, 'gmap_starting_map', 'hybrid', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(432, 0, 'gmap_zoom', '16', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(433, 0, 'gmap_display', 'show', NULL, 'zp-core/zp-extensions/GoogleMap.php'),
(434, 0, 'zp_plugin_GoogleMap', '129', NULL, NULL),
(435, 0, 'zp_plugin_admin-approval', '0', NULL, NULL),
(436, 0, 'zp_plugin_auto_backup', '0', NULL, NULL),
(437, 0, 'zp_plugin_class-AnyFile', '0', NULL, NULL),
(438, 0, 'zp_plugin_class-WEBdocs', '0', NULL, NULL),
(439, 0, 'zp_plugin_colorbox', '129', NULL, 'themes/default/themeoptions.php'),
(440, 0, 'zp_plugin_crop_image', '0', NULL, NULL),
(441, 0, 'zp_plugin_downloadList', '0', NULL, NULL),
(442, 0, 'zp_plugin_email-newuser', '0', NULL, NULL),
(443, 0, 'zp_plugin_failed_access_blocker', '0', NULL, NULL),
(444, 0, 'zp_plugin_flag_thumbnail', '0', NULL, NULL),
(445, 0, 'zp_plugin_flowplayer3', '0', NULL, NULL),
(446, 0, 'zp_plugin_html_meta_tags', '0', NULL, NULL),
(447, 0, 'zp_plugin_image_effects', '0', NULL, NULL),
(448, 0, 'zp_plugin_image_upload_limiter', '0', NULL, NULL),
(449, 0, 'zp_plugin_jcarousel_thumb_nav', '0', NULL, NULL),
(450, 0, 'zp_plugin_menu_manager', '0', NULL, NULL),
(451, 0, 'zp_plugin_multiple_layouts', '0', NULL, NULL),
(452, 0, 'zp_plugin_quota_manager', '0', NULL, NULL),
(453, 0, 'zp_plugin_search_statistics', '0', NULL, NULL),
(454, 0, 'zp_plugin_seo_locale', '0', NULL, NULL),
(455, 0, 'zp_plugin_show_not_logged-in', '0', NULL, NULL),
(456, 0, 'zp_plugin_sitemap-extended', '0', NULL, NULL),
(457, 0, 'zp_plugin_tag_extras', '0', NULL, NULL),
(458, 0, 'zp_plugin_tweet_news', '0', NULL, NULL),
(459, 0, 'zp_plugin_user-expiry', '0', NULL, NULL),
(460, 0, 'zp_plugin_user_groups', '0', NULL, NULL),
(461, 0, 'zp_plugin_user_login-out', '0', NULL, NULL),
(462, 0, 'zp_plugin_xmpMetadata', '0', NULL, NULL),
(463, 0, 'zp_plugin_zenpage', '0', NULL, NULL),
(464, 0, 'hitcounter', '7', NULL, NULL),
(465, 0, 'gallery_security', 'public', NULL, NULL),
(466, 0, 'unprotected_pages', 'a:2:{i:0;s:8:"register";i:1;s:7:"contact";}', NULL, NULL),
(467, 0, 'albums_per_row', '1', NULL, NULL),
(468, 0, 'images_per_row', '7', NULL, NULL),
(469, 0, 'albums_per_row', '2', 'default', 'themes/default'),
(470, 0, 'images_per_row', '5', 'default', 'themes/default'),
(471, 0, 'thumb_transition', '1', 'default', 'themes/default'),
(472, 0, 'colorbox_default_album', '1', NULL, 'themes/default/themeoptions.php'),
(473, 0, 'colorbox_default_image', '1', NULL, 'themes/default/themeoptions.php'),
(474, 0, 'colorbox_effervescence_plus_search', '1', NULL, 'themes/default/themeoptions.php'),
(477, 0, 'albums_per_row', '1', 'iphone', 'themes/iphone'),
(475, 0, 'gallery_title', 'Galleria di project0101', NULL, NULL),
(476, 0, 'Gallery_description', 'Puoi inserire la descrizione della tua Gallery nel tab opzioni del pannello di amministrazione di ZenPhoto.', NULL, NULL),
(478, 0, 'images_per_row', '4', 'iphone', 'themes/iphone'),
(479, 0, 'thumb_transition', '1', 'iphone', 'themes/iphone'),
(480, 0, 'tagline', 'Welcome to zpGalleriffic - Change this in Theme Options', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(481, 0, 'zenpage_homepage', 'none', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(482, 0, 'show_archive', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(483, 0, 'show_credit', '', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(484, 0, 'color_style', 'default-orange', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(485, 0, 'contrast', 'dark', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(486, 0, 'use_image_logo', '', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(487, 0, 'use_image_logo_filename', 'logo.gif', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(488, 0, 'zp_latestnews', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(489, 0, 'zp_latestnews_trunc', '400', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(490, 0, 'show_meta', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(491, 0, 'final_link', 'colorbox', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(492, 0, 'nogal', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(493, 0, 'image_statistic', 'none', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(494, 0, 'show_cats', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(495, 0, 'download_link', '1', NULL, 'themes/zpgalleriffic/themeoptions.php'),
(496, 0, 'Allow_search', '1', 'stopdesign_red', 'themes/stopdesign_red'),
(497, 0, 'Mini_slide_selector', 'Recent images', 'stopdesign_red', 'themes/stopdesign_red'),
(498, 0, 'albums_per_row', '3', 'stopdesign_red', 'themes/stopdesign_red'),
(499, 0, 'images_per_row', '6', 'stopdesign_red', 'themes/stopdesign_red'),
(500, 0, 'thumb_transition', '1', 'stopdesign_red', 'themes/stopdesign_red'),
(501, 0, 'colorbox_stopdesign_red_album', '1', NULL, 'themes/stopdesign_red/themeoptions.php'),
(502, 0, 'colorbox_stopdesign_red_image', '1', NULL, 'themes/stopdesign_red/themeoptions.php'),
(503, 0, 'Allow_search', '1', 'stopdesign_blue', 'themes/stopdesign_blue'),
(504, 0, 'Mini_slide_selector', 'Recent images', 'stopdesign_blue', 'themes/stopdesign_blue'),
(505, 0, 'albums_per_row', '3', 'stopdesign_blue', 'themes/stopdesign_blue'),
(506, 0, 'images_per_row', '6', 'stopdesign_blue', 'themes/stopdesign_blue'),
(507, 0, 'thumb_transition', '1', 'stopdesign_blue', 'themes/stopdesign_blue'),
(508, 0, 'colorbox_stopdesign_blue_album', '1', NULL, 'themes/stopdesign_blue/themeoptions.php'),
(509, 0, 'colorbox_stopdesign_blue_image', '1', NULL, 'themes/stopdesign_blue/themeoptions.php'),
(510, 0, 'Allow_search', '1', 'stopdesign_black', 'themes/stopdesign_black'),
(511, 0, 'Mini_slide_selector', 'Recent images', 'stopdesign_black', 'themes/stopdesign_black'),
(512, 0, 'albums_per_row', '3', 'stopdesign_black', 'themes/stopdesign_black'),
(513, 0, 'images_per_row', '6', 'stopdesign_black', 'themes/stopdesign_black'),
(514, 0, 'thumb_transition', '1', 'stopdesign_black', 'themes/stopdesign_black'),
(515, 0, 'colorbox_stopdesign_black_album', '1', NULL, 'themes/stopdesign_black/themeoptions.php'),
(516, 0, 'colorbox_stopdesign_black_image', '1', NULL, 'themes/stopdesign_black/themeoptions.php'),
(533, 0, 'albums_per_row', '2', 'samuel2', 'themes/samuel2'),
(517, 0, 'Theme_logo', '', 'effervescence_plus', 'themes/effervescence_plus'),
(518, 0, 'Allow_search', '1', 'effervescence_plus', 'themes/effervescence_plus'),
(519, 0, 'enable_album_zipfile', '', 'effervescence_plus', 'themes/effervescence_plus'),
(520, 0, 'Slideshow', '1', 'effervescence_plus', 'themes/effervescence_plus'),
(521, 0, 'Graphic_logo', '', 'effervescence_plus', 'themes/effervescence_plus'),
(522, 0, 'Watermark_head_image', '1', 'effervescence_plus', 'themes/effervescence_plus'),
(523, 0, 'Theme_personality', 'Image page', 'effervescence_plus', 'themes/effervescence_plus'),
(524, 0, 'Theme_colors', 'kish-my father', 'effervescence_plus', 'themes/effervescence_plus'),
(525, 0, 'effervescence_menu', '', 'effervescence_plus', 'themes/effervescence_plus'),
(526, 0, 'albums_per_row', '3', 'effervescence_plus', 'themes/effervescence_plus'),
(527, 0, 'images_per_row', '4', 'effervescence_plus', 'themes/effervescence_plus'),
(528, 0, 'thumb_transition', '1', 'effervescence_plus', 'themes/effervescence_plus'),
(529, 0, 'effervescence_daily_album_image', '1', 'effervescence_plus', 'themes/effervescence_plus'),
(530, 0, 'effervescence_daily_album_image_effect', '', 'effervescence_plus', 'themes/effervescence_plus'),
(531, 0, 'colorbox_effervescence_plus_album', '1', NULL, 'themes/effervescence_plus/themeoptions.php'),
(532, 0, 'colorbox_effervescence_plus_image', '1', NULL, 'themes/effervescence_plus/themeoptions.php'),
(534, 0, 'images_per_row', '6', 'samuel2', 'themes/samuel2'),
(535, 0, 'thumb_transition', '1', 'samuel2', 'themes/samuel2'),
(539, 0, 'albums_per_row', '1', 'binary', 'themes/binary'),
(536, 0, 'albums_per_row', '2', 'simple_plus', 'themes/simple_plus'),
(537, 0, 'images_per_row', '5', 'simple_plus', 'themes/simple_plus'),
(538, 0, 'thumb_transition', '1', 'simple_plus', 'themes/simple_plus'),
(540, 0, 'images_per_row', '6', 'binary', 'themes/binary'),
(541, 0, 'thumb_transition', '1', 'binary', 'themes/binary'),
(542, 0, 'albums_per_row', '1', 'example', 'themes/example'),
(543, 0, 'images_per_row', '7', 'example', 'themes/example'),
(544, 0, 'thumb_transition', '1', 'example', 'themes/example'),
(545, 0, 'Allow_search', '1', 'stopdesign', 'themes/stopdesign'),
(546, 0, 'Mini_slide_selector', 'Recent images', 'stopdesign', 'themes/stopdesign'),
(547, 0, 'albums_per_row', '3', 'stopdesign', 'themes/stopdesign'),
(548, 0, 'images_per_row', '6', 'stopdesign', 'themes/stopdesign'),
(549, 0, 'thumb_transition', '1', 'stopdesign', 'themes/stopdesign'),
(550, 0, 'colorbox_stopdesign_album', '1', NULL, 'themes/stopdesign/themeoptions.php'),
(551, 0, 'colorbox_stopdesign_image', '1', NULL, 'themes/stopdesign/themeoptions.php'),
(556, 0, 'album_tab_default_thumbs_', '0', NULL, NULL),
(555, 0, 'last_garbage_collect', '1313491263', NULL, NULL),
(554, 0, 'colorbox_default_search', '1', NULL, 'themes/default/themeoptions.php'),
(553, 0, 'AlbumThumbSelectorText', 'a:2:{s:5:"en_US";s:11:"most recent";s:5:"it_IT";s:12:"più recente";}', NULL, 'zp-core/setup/setup-option-defaults.php');

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_pages`
--

CREATE TABLE IF NOT EXISTS `avzp_pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned DEFAULT NULL,
  `title` text,
  `content` text,
  `extracontent` text,
  `sort_order` varchar(48) NOT NULL DEFAULT '',
  `show` int(1) unsigned NOT NULL DEFAULT '1',
  `titlelink` varchar(255) NOT NULL DEFAULT '',
  `commentson` int(1) unsigned DEFAULT '0',
  `codeblock` text,
  `author` varchar(64) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `lastchange` datetime DEFAULT NULL,
  `lastchangeauthor` varchar(64) NOT NULL DEFAULT '',
  `hitcounter` int(11) unsigned DEFAULT '0',
  `permalink` int(1) unsigned NOT NULL DEFAULT '0',
  `locked` int(1) unsigned NOT NULL DEFAULT '0',
  `expiredate` datetime DEFAULT NULL,
  `total_votes` int(11) unsigned DEFAULT '0',
  `total_value` int(11) unsigned DEFAULT '0',
  `rating` float NOT NULL DEFAULT '0',
  `used_ips` longtext,
  `rating_status` int(1) unsigned DEFAULT '3',
  `user` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '',
  `password` varchar(64) DEFAULT NULL,
  `password_hint` text,
  `custom_data` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `titlelink` (`titlelink`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_plugin_storage`
--

CREATE TABLE IF NOT EXISTS `avzp_plugin_storage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `aux` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `aux` (`aux`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `avzp_tags`
--

CREATE TABLE IF NOT EXISTS `avzp_tags` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `info_piante`
--

CREATE TABLE IF NOT EXISTS `info_piante` (
  `ID_info_piante` int(11) NOT NULL AUTO_INCREMENT,
  `ID_tipo` int(11) NOT NULL,
  `ID_pianta` int(11) NOT NULL,
  PRIMARY KEY (`ID_info_piante`),
  KEY `ID_tipo` (`ID_tipo`),
  KEY `ID_pianta` (`ID_pianta`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `orto`
--

CREATE TABLE IF NOT EXISTS `orto` (
  `ID_orto` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) NOT NULL,
  `ID_utente` int(11) NOT NULL,
  `ID_tipo` int(11) NOT NULL,
  PRIMARY KEY (`ID_orto`),
  KEY `ID_utente` (`ID_utente`),
  KEY `ID_tipo` (`ID_tipo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dump dei dati per la tabella `orto`
--

INSERT INTO `orto` (`ID_orto`, `nome`, `ID_utente`, `ID_tipo`) VALUES
(1, 'orto1', 3, 1),
(7, 'ortoNespo1', 1, 1),
(4, 'orto 2', 3, 2),
(8, 'ortoTollo1', 2, 1),
(9, 'ortoTocca2', 2, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `parassiti`
--

CREATE TABLE IF NOT EXISTS `parassiti` (
  `ID_Parassita` int(4) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(40) DEFAULT NULL,
  `Caratteristiche` varchar(300) DEFAULT NULL,
  `Piante_colpite` varchar(160) DEFAULT NULL,
  `Danni` varchar(160) DEFAULT NULL,
  `Soluzioni` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`ID_Parassita`),
  KEY `Piante_colpite` (`Piante_colpite`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dump dei dati per la tabella `parassiti`
--

INSERT INTO `parassiti` (`ID_Parassita`, `Nome`, `Caratteristiche`, `Piante_colpite`, `Danni`, `Soluzioni`) VALUES
(1, 'Afidi', 'Attaccano le piante pungendo foglie e germogli, ne succhiano la linfa e le deformano.', 'Lattuga,Prezzemolo,Pomodoro', 'Stato di generale deperimento per le piante.', 'Utilizzare macerati a base di assenzio oppure di ortica.'),
(2, 'Agrotidi', 'Bruchi attivi soprattutto durante le ore notturne.', 'Cavolo,Pomodoro,Lattuga,Fagiolo', 'Attaccano la zona di passaggio fra il fusto e la radice delle piante e scavano all’interno del fusto che può finire per spezzarsi.', 'Utilizzare esche avvelenate e ricorrere a trattamenti a base di assenzio.'),
(3, 'Altiche', 'Sono piccoli coleotteri.', 'Cavolo,Rucola,Spinacio', 'Parassiti che rodono le foglie esternamente e scavano delle piccole fosse sulla loro superficie.', 'Spolverare, durante le ore mattutine, farina di alghe e bentonite sulle foglie.'),
(4, 'Cavolaie', 'Sono farfalle molto comuni che depongono le loro uova sulla parte pagina inferiore delle foglie da queste uova da cui fuoriescono caratteristici bruchi molto voraci che si cibano delle foglie risparmiandone soltanto la nervatura.', 'Cavolo', 'Possono far marcire la pianta specialmente nelle stagioni più calde.', 'Rimuovere manualmente le uova per poi spolverare le foglie con della farina di alghe calcaree.'),
(5, 'Lumache', 'Danneggiano i prodotti dell’orto rosicchiando e divorando i germogli; La presenza di questi animaletti è maggiore quando  il clima è piuttosto umido.', 'Barbabietola,Cavolo,Cardo,Lattuga,Finocchio,Spinacio', 'Il danno procurato dalle lumache è  anche indiretto perché le piante che vengono da loro attaccate sono più suscettibili agli attacchi batterici.', 'Oltre alla rimozione naturale, si possono cospargere i confini delle coltivazioni con della cenere.'),
(6, 'Mosche della cipolla', 'Sono insetti dannosi che depongono le loro uova sul colletto delle piante, uova dalle quali escono larve che divorano i blulbi.', 'Cipolla,Aglio', 'Questi parassiti possono provocarne la morte della pianta.Inoltre le piante attaccate sono maggiormente suscettibili agli attacchi batterici.', 'Utilizzare letame molto maturo.'),
(7, 'Tortrici', 'Sono farfalle di piccole dimensioni; i bruchi delle tortrici attaccano le piante divorando gli apici e rosicchiando  foglie e petali.', 'Fagiolo,Pisello', 'Quando le larve nascono divorano i semi svuotandoli.', 'Per difendersi dalle tortrici si può ricorrere, oltre alla rimozione manuale, al trattamento con prodotti a base di alghe calcaree.\n');

-- --------------------------------------------------------

--
-- Struttura della tabella `parassiti_verificati`
--

CREATE TABLE IF NOT EXISTS `parassiti_verificati` (
  `ID_parassiti_verificati` int(11) NOT NULL AUTO_INCREMENT,
  `ID_parassita` int(11) NOT NULL,
  `ID_pianta_piantata` int(11) NOT NULL,
  PRIMARY KEY (`ID_parassiti_verificati`),
  KEY `ID_parassita` (`ID_parassita`),
  KEY `ID_pianta_piantata` (`ID_pianta_piantata`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `piante_piantate`
--

CREATE TABLE IF NOT EXISTS `piante_piantate` (
  `ID_pianta_piantata` int(11) NOT NULL AUTO_INCREMENT,
  `ID_orto` int(11) NOT NULL,
  `ID_pianta` int(11) NOT NULL,
  PRIMARY KEY (`ID_pianta_piantata`),
  KEY `ID_orto` (`ID_orto`),
  KEY `ID_pianta` (`ID_pianta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dump dei dati per la tabella `piante_piantate`
--

INSERT INTO `piante_piantate` (`ID_pianta_piantata`, `ID_orto`, `ID_pianta`) VALUES
(6, 1, 5),
(7, 1, 10),
(8, 4, 1),
(9, 4, 2),
(17, 1, 13),
(11, 4, 6),
(12, 4, 36),
(15, 7, 9),
(18, 8, 24),
(19, 9, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `tabfiori`
--

CREATE TABLE IF NOT EXISTS `tabfiori` (
  `ID_fiori` int(4) NOT NULL AUTO_INCREMENT,
  `nome` varchar(16) NOT NULL,
  `colore` varchar(16) NOT NULL,
  PRIMARY KEY (`ID_fiori`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `tabpiante`
--

CREATE TABLE IF NOT EXISTS `tabpiante` (
  `ID_piante` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) NOT NULL,
  `frutto` varchar(30) NOT NULL,
  `fiori` varchar(50) DEFAULT NULL,
  `foglie` varchar(50) DEFAULT NULL,
  `dimensione` varchar(300) DEFAULT NULL,
  `esposizioni` varchar(300) DEFAULT NULL,
  `terreno` varchar(100) DEFAULT NULL,
  `irrigazione` varchar(100) DEFAULT NULL,
  `temperatura` varchar(100) DEFAULT NULL,
  `concimazione` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID_piante`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dump dei dati per la tabella `tabpiante`
--

INSERT INTO `tabpiante` (`ID_piante`, `nome`, `frutto`, `fiori`, `foglie`, `dimensione`, `esposizioni`, `terreno`, `irrigazione`, `temperatura`, `concimazione`) VALUES
(1, 'Allium cepa', 'Cipolla', 'Bianchi/Rosa/Viola', 'Grigie allungate', '100', 'Pieno sole', 'Ricco e fresco', 'Moderata', 'Clima temperato', 'Con letame maturo'),
(2, 'Allium porro', 'Porro', 'Bianchi/Rosa', 'Lineari/piatte', '80', 'Pieno Sole', 'Fertile,profondo', 'Solo in caso di siccita''', 'Non teme il freddo', 'Con concime organico'),
(3, 'Allium sativum', 'Aglio', 'Bianchi', 'Lunghe,vuote', '70', 'Pieno Sole', 'Sabbioso,non umido', 'Solo in assenza di pioggia', '15-25 gradi', 'Generosa in fase di preparazione del terreno '),
(4, 'Apium graveolens', 'Sedano', 'Bianco verdastri', 'Dentate', '120', 'Pieno Sole', 'Fertile,ben drenato', 'Leggera e frequente', '15-22 gradi', 'Con concime organico'),
(5, 'Beta vulgaris', 'Barbabietola', 'Piccole pannocchie', 'Allungate', '125', 'Pieno Sole', 'Fertile,ben irrigato', 'Moderata o abbondante', '18-20 gradi', 'Con solfato di ferro'),
(6, 'Brassica olerace', 'Cavolo', 'Viola', 'Grandi grumoli', '25', 'Pieno Sole', 'Fertile,ben drenato', 'Frequente e abbondante', '15-20 gradi', 'Con letame maturo'),
(7, 'Capsicum', 'Peperone', 'Piccoli,bianchi', 'Ovali,picciolate', '125', 'Pieno Sole', 'Sciolto,fertile', 'Frequente,per scorrimento nei solchi', '>15 gradi', 'Con concime organico'),
(8, 'Cichorium', 'Cicoria', 'Azzurri', 'Grandi,pelose', '150', 'Pieno Sole', 'Fertile,profondo', 'Moderata', '15-20 gradi', 'Con letame maturo'),
(9, 'Cucumis sativus', 'Cetriolo', 'Maschi/Femmine', 'Alterne,dentate', '400', 'Pieno Sole', 'Soffice,fertile', 'Frequente', 'Caldo umido', 'Con letame maturo'),
(10, 'Cucurbita maxima', 'Zucca', 'Grandi,gialli', 'Pelose', '300', 'Pieno Sole', 'Sciolto,fertile', 'Frequente', '15-25 gradi', 'Con concime orga'),
(11, 'Cucurbita pepo', 'Zucchino', 'Gialli', 'Voluminose con peli duri', '150', 'Pieno Sole', 'Fertile,ben drenato', 'Abbondante', 'Clima non freddo', 'Con letame stagionato'),
(12, 'Cynara carduncul', 'Cardo', 'Riuniti in capolini', 'Grigio-verdi,grandi', '200', 'Pieno Sole', 'Fertile Profondo', 'Frequente', '10-15 gradi', 'Con concime organico'),
(13, 'Eruca sativa', 'Rucola', 'Piccoli,gialli', 'Lirate disposte a rosetta', '50', 'Pieno Sole', 'Fertile,ben dren', 'Moderata', 'Resiste al freddo', 'Non necessaria'),
(14, 'Foeniculum vulga', 'Finocchio', 'Gialli', 'Parte commestibile', '70', 'Pieno Sole', 'Fertle,profondo', 'Leggera,frequente', 'Teme il freddo', 'Non necessaria'),
(15, 'Lactuca', 'Lattuga', 'Ligulati', 'Grandi,ovali', '150', 'Ben soleggiato,leggera ombra', 'Fertile,umido', 'Per scorrimento,non bagnando le foglie', '15-20 gradi', 'Fertlizzante organico'),
(16, 'Lycopersicon esc', 'Pomodoro', 'Gialli', 'Verdi,pelose', '200', 'Pieno Sole', 'Fertile,ben drenato', 'Frequente', '20-25 gradi', 'Con concime organico'),
(17, 'Petroselinum hor', 'Prezzemolo', 'Gialli/verdi', 'Verdi,molto profumate', '70', 'Pieno Sole', 'Fertile,sciolto', 'Leggera ma frequente', '16-22 gradi', 'Non necessaria'),
(18, 'Phaseolus', 'Fagiolo', 'Bianchi/rosa/lilla', 'Pelose,ovali', '400', 'Pieno Sole', 'Ben drenato', 'Abbondante,per scorrimento', 'Teme il gelo', 'Con concime ricco di fosforo'),
(19, 'Pisum sativum', 'Pisello', 'Ascellari,bianchi', 'Pennate e pruinose', '50', 'Pieno Sole', 'Fertile,ben drenato e concimato', 'Frequente in caso di scarsa pioggia', 'Resistente al freddo patisce il troppo caldo', 'Con concime organico'),
(20, 'Solanum melongen', 'Melanzana', 'Blu,ascellari e solitari', 'Tomentose, grandi e alterne', '120', 'Pieno sole', 'Sciolto,ben drenato,profondo e fertile', 'Abbondante', 'Non sotto i 10 gradi', 'Con concime organico'),
(21, 'Spinacia olerace', 'Spinacio', 'Maschili e femminili', 'Color verde scuro e tondeggianti', '80', 'Pieno sole', 'Sciolto e fertile', 'Frequente in caso di mancanza di pioggia', 'Molto resistente al freddo', 'Con azoto,fosforo'),
(22, 'Levisticum Offic', 'Sedano di monte', 'Gialli', 'Pennatosette divise in segmenti romboidali dentati', '200', 'Pieno Sole', 'Fertile,Profondo', 'Abbondante', 'Clima temperato, resiste anche ad inverni rigidi', 'Con letame maturo'),
(23, 'Stevia Reubadian', 'Stevia', 'Ermafroditi molto piccoli di colore biancastro', 'Ovate', '100', 'Pieno Sole', 'Sciolto', 'Abbondante', 'da 1°C a 23°C', 'Con concime organico'),
(24, 'Hordeum ', 'Orzo', 'Ermafroditi', 'Sono disposte in modo alterno sul culmo,', '120', 'Sole Pieno', 'Cresce anche in terreni poveri', 'Puo essere anche irregolare', 'Qualunque tipo di clima', 'Con stallico maturo'),
(25, 'Crocus sativus', 'Zafferano', 'Perigomi, Violetti', 'Molto strette e allungate', 'Bulbo: 5cm', 'Sole Pieno', 'Miscela di torba e sabbia', 'Regolare', 'supporta temperature fino a -12°C', 'Con concime organico e minerale'),
(26, 'Cynara Scolymus', 'Carciofo', 'on corolla tubulosa e azzurro-violacea e calice tr', 'Grandi, oblungo-lanceolate', '150', 'Pieno Sole', 'Leggero e drenato', 'Scrupolosa', 'Clima mite e abbastanza umido', 'Con letame maturo'),
(27, 'Vicia Fava', 'Fava', 'ascellari, bianchi/neri o viola/neri', 'stipolate, glauche, pennato-composte', '140', 'Pieno Sole', 'Drenato anche non particolarmente fertile', 'In caso di siccità', 'Non supporta clima rigidi', 'Con concime con fosforo abbondante'),
(28, 'Origanum', 'Origano', 'Porporini sessili, odorosi, violacei', 'Opposte,verdi e dentate', '80', 'Pieno sole', 'asciutto,quasi secco', 'Soprattutto nei periodi di fioritura', 'clima mite', 'Non necessaria'),
(29, 'Sinapis arvensis', 'Senape', 'racemi, con sepali gialli o verdi', 'picciolate, di forma ovale o ellittica', '100', 'Pieno Sole', 'Argilloso', 'In caso di siccità', 'Clima mediterraneo', 'Con concime organico'),
(30, 'Thymus Vulgaris', 'Timo maggiore', 'Ermafroditi, bianchi-violacei', 'Opposte, verdi tendenti al grigio', '40', 'Pieno Sole', 'leggero, drenante, calcareo', 'Regolare, soprattutto in casi di siccità', 'Clima temperato', 'Con letame maturo'),
(31, 'Zingiber ', 'Zenzero', 'Gialli con macchie violacee', 'sempreverdi, di forma allungata e lanceolata ', '150', 'Pieno Sole', 'Sciolto,drenante e particolarmente profondo', 'Frequente', 'non al disotto dei 15°C', 'Con letame maturo'),
(32, 'chamaecyparissus', 'Santolina', 'Gialli', 'Di piccole dimensioni, grigie tendenti al verde', '60', 'Pieno sole', 'Sabbioso, drenante', 'Basta l'' acqua piovana', 'Sia climi aridi che freddi', 'Non necessaria'),
(33, 'Satureja hortens', 'Santoreggia', 'Rosa e bianchi', 'Verdi, lanceolate', '40', 'Pieno Sole e anche in mezz'' ombra', 'Sciolto, fertile e di natura calcarea', 'Regolare e abbondante', 'Clima temperato', 'Con Concime di natura ternaria'),
(34, 'Satureja montana', 'Santoreggia montana', 'Piccoli,ermafroditi di color bianco', 'Lanceolate, verdi lucide', '50', 'Pieno Sole', 'Sciolto, drenante e di natura calcarea', 'regolare', 'Clima temperato', 'Con letame maturo prima della semina'),
(35, 'Myrrhis Odorata', 'Finocchiella', 'Bianchi, maschili', 'Con margini frastagliati, verdi', '150', 'Zone parzialmente ombreggiate', 'Sciolto, fertile, pieno di sostanza organica', 'Regolare, soprattutto nei mesi caldi', 'Clima temperato freddo', 'Con fertilizzante a lenta cessione'),
(36, 'Cannabis Sativa ', 'Canapa', 'maschili e femminili', 'Verdi, lanceolate e seghettate', '400', 'Pieno Sole', 'argilloso, fertile e profondo', 'soprattutto nel periodo prima della semina e in caso di siccita', 'Clima sub tropicale e temperato', 'azotata'),
(37, 'Lupinus', 'Lupino', 'bianchi, gialli e rossi', 'alterne, di consistenza molle e picciolate', '70, dopo la fioritura 120', 'Pieno Sole', 'ricco,sciolto e drenato', 'non più di due volte a settimana', 'qualunque condizione va bene', 'Con fertilizzante specifico per piante da fiore'),
(38, 'Secale Cereale', 'Segale', 'non ne ha', 'verdi, dalla lamina corta e stretta', '200', 'Pieno Sole', 'sabbioso e acido', 'abbondanti se il clima e secco', 'Resiste anche ai climi rigidi, predilige un clima temperato', 'Non necessaria'),
(39, 'Allium schoenoprasum ', 'Erba cipollina', 'Ermafroditi, rosa', 'Di forma cilindrica', '25', 'Ombra parziale', 'Fresco, leggero, sciolto e drenante', 'abbondante, soprattutto d'' estate', 'Clima temperato', 'Con fertilizzante organico'),
(40, 'Allium ascalonicum', 'Scalogno', 'non ne ha', 'Di tipo onmbrellifero', '30', 'Pieno Sole', 'sciolto, sabbioso e drenante', 'Solo in caso di siccita', 'Clima temperato', 'Con concimi minerali'),
(41, 'Solanum tuberosum', 'Patata', 'Pentameri,  gialli o argento', 'Pennato-composte', '50', 'Pieno Sole', 'Sciolto e drenante', 'Regolare', 'Si adatta a diversi climi', 'Con letame maturo'),
(42, 'Physalis alkekengi', 'alchechengio', 'Bianchi,piccoli e ascellari', 'Verdi, chiare e ovali', '100', 'Mezz'' ombra', 'Secco, drenante', 'Frequente in caso di aridità', 'Evitare le gelate', 'Con stallico');

-- --------------------------------------------------------

--
-- Struttura della tabella `tipo`
--

CREATE TABLE IF NOT EXISTS `tipo` (
  `ID_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(15) NOT NULL,
  PRIMARY KEY (`ID_tipo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dump dei dati per la tabella `tipo`
--

INSERT INTO `tipo` (`ID_tipo`, `Tipo`) VALUES
(1, 'aperto'),
(2, 'serra');

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID_utente` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `password` varchar(40) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `avatar` blob NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `cognome` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID_utente`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`ID_utente`, `username`, `password`, `email`, `avatar`, `nome`, `cognome`) VALUES
(1, 'admin', '6279886fde090b3038f267098bcca771a6efa946', 'stenespo@gmail.com', 0xffd8ffe000104a46494600010100000100010000ffdb0084000906071211100f1010100f0f100f0f0f0f0e100f0d0f0f150f0f1511161615121615181d2820181a261b151621312125292b2e2e2f171f3338332c37282d2e2b010a0a0a0d0d0d0f0d0f172b1915192b372b2b2d37372d2b2b2b2b2d2b2d2b2b2b2b2b2b2d2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2bffc000110800cc00cc03012200021101031101ffc4001b00010002030101000000000000000000000002030105060407ffc40046100002010202070308080207090000000000010203041112050621314151611371911422527281a1b1c116233242536282d1f0f107152492a3b2c2333543637383a2e1e2ffc4001501010100000000000000000000000000000001ffc400161101010100000000000000000000000000001101ffda000c03010002110311003f00fb88000000000000000028bdbb85184aa54928c63bdbf82e6ce26fb4e5c5ecdd2b68ca9d2dcda7836b9ca5c17440751a4f586de862a75334d7dc879d2ee7cbda73d5f5e27279685be3cb3c9cdbfd31fdcbb466a952860eb3ed65cbecc57b37b3a1b7a3182c2118c1728c547e041ca7f5e69296d8d16b1ff90d7f987f5f69186d950724b7fd44bfd27608c81ca5b6bcb4f2d7a183e2e1269afd12fdce8f46e9ca171b29d459bd0979b2f07bfd84ae6d61516152119afcd14ff91cde93d5084bceb793a725b545b6e2df47be207660e1b46eb1d7b59aa379194a2b629bdb28ae78fdf5ef3b5b7af1a918ce12528c96319278a68a2c00000000000000000000000000002ab9b88d384aa4da8c609ca4df245a711ae57f2ad5a1674b6a528e7c38d47b93e896dfe4078aad4aba4abf1850a6f62e115f39b3acb2b5851828538a8c578b7cdbe2ca74759c68538d3870defd2971933d5120b625b145712d881348ce533124ca29922b916c8aa4078b495853af070a8bd56b7c5f34ce5f475e54d1d5dd2a98ca84de38f0c3d38f5e68ec246bf4d68f8dc52707b24b6d397a32fd9906fe9cd492945a71924e2d6d4d3da9a2471fa8da4da73b3a9b254f33a78f0c1f9d0f63dbe27605000000000000000000000000145fdcaa54aa557ba9c253efc16e386d52a0ea4eadccf6c9c9a4ff0033db27ef5e26ff005eabe5b4715ff12708fb31c5fc0f1eaf52c96b4f9c939bef93c48368996c4a22cb62c0ba2cb62ca22cb1302f4cce629523398a252657261c88499046443133265726072dac3176f754ae61f79a94b0e328ec92f6a3bea5514a3192daa49493e69ac51c86b752cd6d9b8d39c24bdbe6bf8fb8dd6a957cf6741bdae31ecffbaf05ee480dc000a00000000000000000000392fe915fd4d1ff00aaff00c8cf458eca34bd487c08ff004814b1b684bd0ab1f7a68af44d4cd6f49fe48f8ad841ee8b2c8b288b271605e99629142649480bd48662acc3301639106c8b911720332657261b2126078f4f6db5adea7ccbf50dff0064ff00bb53e478b592a65b5a9f9b2c57b648d96a4d2cb674dfa729cbff002c3e406f8005000000000000000000001aed62b4edad6b412c6591ca0b9ca3b52f761ed394d51b9cd4a54def849b5eacbff78f89de1f3cd2349d8df66c1f6357ce5ea49f9cbbd3f9134740493312da9496d4d638ae2b9914c82e5224a452a46548a2fcc3315661980b3318722bcc61c8093911c48b6253508ca727828a6dbe480d0eb7576fb2a31dadcb360b8bfb315ef6771a36dbb2a34a97e1d3845f5696d7e2713ab56eeeef257135f5749e658f3fb91f0dbecea77e30000500000000000000000008d4a8a29ca4d46314dc9b782496f6c0cc9e0707adda629dc38dbd183ad38cf6548ee4f7351e7f02cd29a56b5f5476f6b8c68eea93dd99736f847a71369a3f43d3b58e1159a6fed4def7fb220d0e80d26e9bf26af8c5a7841cb6657e83f91d0ce26a74e68a55bce5b2a25b1f092e4ff73c1a3b4dce8becae149a5b14b7ca2bfd480e88c98a35615166a72524f8a7fc6049c190631188c0600310654190b9b8a74966a92515d77bee5c40b231e2f71ca6b26985531a54dfd5c5f9d25f7e4be44efb4ad5ba9765422e307bf8392fccf82e86e344687a70838ce2a6e6b09b92c535c972451b3d50a947c9e11a12c70db571d92ed1efccbe06fcf9ddf68aad633f28b69374d7da5bf2af464b8c7a9d7e80d350baa78c7cda914bb4a78ed8be6b9aea51b500000000000000000000388d37a42a5f56f24b77f5517f5b3e12c1ed6ff2af79b1d73d2ce118db526fb5afb1e5df1837861def77897e82d191b5a2960bb49eda8faf2ee407a747d953b6a6a9d35d652e327cd9394313289a20f1d4a06befb46c2a2c271c793dcd77337b94c3a299470d5741d6a4f3509beecd95fecc474d5d52d9569e6eb2838bf18ec3b676a45d9f4241c8c75ad7dea4f1e935f34625ad7e8d178f59fec8eade8c8bdf08bfd28cc746c56e8c5774501c74b4b5dd5d94a9e44f8c61fea96c336fabf52a3cd5e6db7bd29667e2cecd5a1356c20d4d9e8f8d359611515f1ef7c4f753a27ad524860518a7861965b53d9b76ece4723a6f45cecaaabab5c553c7ce5bd431fbaff23f7781d6b32b092709a528c934d3e29f020685d290b9a4aa4763dd38f184b8a3de7cf9e6d19769ac5dbd5f6e34f1ddeb47f8de77f4aa29454a2d38c92945adcd3dcca2400000000000042bd5508ca727846117293e492c59339dd7abcc96b913db5a4a1fa56d7f0f781aad5aa6eeae6ade545b232c29a7c1e1b3c16074939e2f1f03cba26d7b1b6a74f7371c65eb3dacf42209a268ad128b02c44d104490162248826493289a0c8e23100c8332d916c08b22c9320c822c8324c8303cfa66c15cd09436675e7537ca696cf1dded35fa89a49b8ced678a9d2c5c13f431c1c7d8fe26ea8cf07dfb0e534c7f64d214ebad90a8f34f0eaf0a9fb81de809828000000001c6eb8bed2eeca8f0fb4d73cd349fba0cec8e374e7fbd6d7d4861e3303a0b97b52e48ad19b8fb5ec451715d42329bdc978be0881715f06a11fb52dfd11eaa6b04972355a2e2e4dd496f6f136a98134c9a6569924c0b13329904cce2513c462431188126c8b63122d806c8b0d916c830c8296249b3c4eae59b8bdcf6af681e966a35dedd4eda3538d39a7fa65e6b5e38781b6c4f3e9c8e6b2aeb941bf6a7881eed5cb9ed2d6849efecd45f7c7cdf91b239dd449e36897a352a2f7e2744500000000186ce335b5e4bdb3adc3645fe99edf74cebeac8e535ca967a38adf4a599776e7fc74037975bd3e68d1696ad9ea4692dd1c253ef7b9787c4d868bbd55ed61531f3a11c27df15b4d4e8a8ba93751ef949cbbba106eed2196291e84cad124c0b1324995a665302c4cce2431338813c46243118812c4c3647130d8196c8b61b22d806cd5e9b795427ca595fb76af87bcd93678b4bd3cd46a2e4b32ef5b408d8dd665816e9c961655f1e30697b5e0737a36e1e6515bdb491b2d76bb51a14e8a7e7549293f563ff00d61e0c0d8ea32c2d23d6a547ef3a234fabf4bb3b7a30dcd4166f59ed7ef66dd1464000000079ae19cfe937bd3dcf633a1b8468348c00e7b42df792d69d297fb2ab824f827b93f91d4d3b454f6c7eccb6ae9d0e4efedb32c1efe0f91ecd07ac2e8fd4dce2e1ba33df82e4f9a20e95324992a718d459a9c94a2f760f141d19720309924cc647c98caf93f0025899c48e57c9f819caf9303388c4c657c9f80caf93f0033898c4657c998c8f9300d916cce47c98ece5c98106c85458a6b9a6bc4f446ddbdf82f79e7bed2142d963526b3708ac1c9f72e0068f47da2a11957ad8472a782f457eecd451ab2bab9ed26bcc835845f08afb31ef29bebda9773f469a6dc63c23d5f366e345db28a497f36074f632d86d206b2c63b0d9c0a2400000002ba913577b43136ed14d5a7881c8dd5a9aeaf669ec6b13b1af6989e29d801c842caad379a8d4941f24dc7f99eca7a72fa1bf09fad04fde8dff0090741e41d00d2ad6eb95be843fbb517cccfd32aff814fc2a1b9f20e83c83a01a6fa655ff00029f8541f4cabfe053ff0010dcf90741e41d0834df4cabfe053f0a83e9957fc0a7e150dcf90741e41d00d37d32aff814ff00c41f4cabfe053f0a86e7c83a0f20e8069be9957fc0a7e1508cb5b2e5fd9a505d724dfc4ddf90741e41d0a39aafa46f6aec739417e5c29fbd6d3cf4b453c719b726f6bc31dbdef89d6f9074331b003496f6986092c174373656c7aa9591efa36f8013b6a781ea44631260000000000c34640107020e9170028ec47625e00a3b11d8978028ec4c7627a001e7ec4cf625e00a3b11d8978028ec47625e00a3b11d897802a54c9a89200000000007ffd9, 'Stefano', 'Nespoli'),
(2, 'ivantollardo', '5f628e6a2f4ea06c494916689fb64176b51b53d3', 'ivantollardo@yahoo.it', 0xffd8ffe000104a46494600010100000100010000ffdb0043000a07070807060a0808080b0a0a0b0e18100e0d0d0e1d15161118231f2524221f2221262b372f26293429212230413134393b3e3e3e252e4449433c48373d3e3bffdb0043010a0b0b0e0d0e1c10101c3b2822283b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3bffc000110800ee00f203012200021101031101ffc4001b00010003010101010000000000000000000004050603010207ffc4004810000103020205060a0706060203000000010002030411052112314151b106133561717214223234738191c1d1f015548292a1c2e11623333646622526425253f144632493b2ffc4001b01000105010100000000000000000000000001020304050607ffc400351100010302040306050305010100000000010002030411051221314151710613336181c114323491a12252b1357282d1e123f0ffda000c03010002110311003f00fce2c31aa3be42ae116ef0ebbedbfe3daa8de1cd716bae08d608d4a45155be8aa9b3349c8d9c2f6b8da15d62586c75d10aca5cdc45c81fea1d5d7f3af5c19bba758ec76f25b062f8d84c8df11bb8e639acd221041453ac74444421111108444442111110844444211111084444421111108444442111110844444217a89d4ac30fc326ae782016c77b171190f8948e7068b952c30be6786305c951a969a6ab939b85a5c7f00a7d4cadc3d8ea481cd7484112c833bf50dc37a955d530e1709a4a31690f96f36b81f1e1da567c92733ad46d25fa9db82bb306d28eeda6efe2780f20bc44452acd5e819abfe4fd692e146fb906e59dbb47bd502e91c8e8de1ec24169b8236151c8c0f69055ca2aa752ccd91bc37f30af319c289bd54398d6f68e23dfed59fbe79ad9d0d536ba91b2e57d4e1b8edf9eb54d8d617cc9351036d19f29a3fd27e0ab412907bb7ee16de298735ecf8ba6d5a7523dd522222bab98444442111758609279047134b9ced402f822c6c5174b636bd97ca2eed8247c0e9834e830804eebeae0b8ebb244a5a45ae375e222254d445de18249daf31b49d06e93adb00dbf8ae28ba52d200278af111109111491473ba6e6446ee733f148b1c85f82e05a5a6c424b84e2d7017217ca22254d44444217b96e4009d4bac10be790471b4b9c7500b498660cca42d9a6b3e51986ec69f79f9eb51492b63172b468b0f9ab1d660d389e0143c370373c89aac68b6f9467227b770fc54dc4abd987402285a048e1e2868b068debbe215cca183489bc8726b77f5f62c9cd33e791d248e25ced64aad1874ceccfdb805b7592c18645dc53fce773c42f87bcbc9738924ebbaf8445797284df5288888488888842b4c22bbc0ea6cf279b92cd76bcb71f9eb5a82039a5a4020e441dab0ab518256f84d3189c469c435db3237fbbd8a855c7a676faaeb7b3f5c35a59363b7b85598b617e06ee76204c4e3ec3b9548d6b73246c9a331c8dd26bb220ed54b37275c6526295a1a49b037bf66a4b0d4b4b6cf3aa662781c8d933d38b83c392a0b6f52296926ab903216dceddc06f2ada1e4ec82506499bcd8373a37bfaae15cd3d3c34d108a260681aced277929f2d535a3f4ea557a2c0a795d79c6568fb954f514edc1f0e2d043a79816e96e1b6dd5f1baa6a7a77d4ced8982ee79b052b16aa3575eeb66d678adb6e0adf04c3bc1e1f0891bfbc905c750fd52e7314799db94d6d30aeac10c22cc6e9e8373eaa6c34514345e0b6d2691e35c6b2759595afa4928ea0c4f196b69de3615b250316a0f0da6bb00e7599b72ccf57c3f55529e721ff00a8e856fe2d85b24a70621ab0683c96486c5f6c63a4786b412e71b05f24106d6cd68f03c3844d155283a67c81aac37fad6849208db98ae3e8689f57308dbea792998761eca2a5d17343a478fde1398ecfc567713a3f03ac7479e81cda4eef9c96b941c5e87c3290e8b499199b6db77859f0541125ddc576189e14c75206c43566de7cd6454dc3a3e72ba166836405e349aebd8b75906c41b5af7b11daa1104120ec57bc9da5bcafa9702740581b6d3af3ece2b464765612b8da1a733d4363f3d7a715d47f349eefe55f38e61a5d7ab85a3fbc0e2beaff00e6923fb7f2aba22f91541f2ba37348e4bada6a18eaa9e589dfb8d8f2583b22b9c670be65eea8859fba27303fd2553ad063c3db70b8faaa6929a531c8351f95e29943874d5f268c62cd1e538ea0bb61342caea8735ee3a2d6df2d67a969e38d90c6191b435a3500abcf5023d06eb5f0ac1cd5ff00e8f366fe4ae3474105147a31b6ee23c671d67f45f757531d2533a690e43202f624ee0bee695b042e95e406b45ce6b278857495d51a6ef21b935bb82a9146e99d99db2e8710ad8b0d84451001c761cbccaf8abab92b66324875ea1d5b94545e6b5aa0002c1700f7b9ee2e71b928888953111110844444217aa4d1553e8ea192b761cc28db53675a42011629ec7b98e0e69b10b7514ad9a16cb19bb5c010725f4a9b9392bdd04d138ddac2081baf7bf0570b0e6664796af51c3ea7e2699b2db5e3d42e6eaaa6638b5d3c4083620bc02179e194bf588bff00b07c565b13bfd233dbfde78a896277dd5e6d234806eb989fb43335ee6641a1214fc26364d8a31ae1a4db9363b6c0d96ad65703e948fed705aa50d6139c0f25a3d9b03e1dceb6a4ae351594f4a1bcfc9a01d7b644dedaf505f34f5d4b56f2d8260f205c8d1232f5aaae537934df6bdcabf0aa8f06af8de4f884d8fc7d5afd49eca66ba2cc3750d4e332c35ddc103282079eaa554c4c6f28c30306897b4db58cc0278ad1acf557f3337bcce0168547524d9bd159c1000e9c8fdc5574f8bb21c4594e6da17b3dc3613f0562b1d89f494fdf3c568305ad1554a2277f122001eb1b0fbbfed3a6803581cdf550e1b8aba5aa7c129dc9b7a705518dd2b60aefdd8b3641a400d9b0f057d8653782d046c23c62349dda7f4b0f52aac78696234e3fb7de55fa267931341e28c329636d7cee02d6361eaa947f349eefe5574a987f343bba3ffcab5a8798e9a491a6ce630907ac04c98667340e415bc35e238e679d839c57dbda1ed2d700e6b85883a8acbe2b863a9253231879971c8ee3b8abcc3b1165745fed95bada0ebeb1d4a5c91b258dd148016b8588288dee85f94a4aca68313a6ef1875dc1f62b3dc9bf3997bbef0b44e706b4b9c6c00b93b82cff002772ab987f6fbc2bca9f349bb8ee052d48bcd6e8a3c149661e4f2bacd62b891ad974580b636f9236f6955a87595e2d463435b60b859e67cf217bcdc944444e50222221088888422222108888842d0726bc8a8ed6fbd5eace6095d4f46c9f9f79697005a2c4ded7f8ab0fa7e8bfbfee8f8acba889ee9090177783d7d34346d648f00eba7aa9f2534123cb9f0b1c4e6496824af19494ec7693608c11982180105794b551d643cec77b5ec41d6bb2af99e0e524adaeea0923ef18d06fadec165b04e976fdae056a565b04e976fdae056a54f59f38e8b2fb39f4cefee3ecab31aa09ab638b99009613704d8e76d57ec54d51855452d3f3d368b6eed1b5ee75137cbb16b1557287a39be907029d4f3bae23e0a0c630c8724953739bf0aa609df558c4533c005ce170356597b96a963f0ce9087bc16c515a2ce0024ecd92e8a427727d9646bdcd6e2931782e02437b1b139ef571829a1717783b5ed9747c6d337cafa811ead8aa2bd8f9715998c05ce7484003695a1c3a819430ea0657794e1c3b14d3b9a22009d4859d854523eb9cf001009b9236e8ab31f2457c1dd1c4abf59bc66a639f118c44ed20cb34b86a26fb3dab49b1569c111b015b585bdafaba8734dc5c2a6fea83ddfcaaceb3cca7f46ee05567f541eefe556759e673fa37702893e76740928fe9aa3ab966b04e968bb1dc0ad5aca607d2f17dae056ad3eafc40a0ecf7d1c9d4ff000b3bc9df3c97ba78abda9f349bb8ee05517277cf25ee9e2af6a7cd26ee3b814ca8f1beca6c23fa6bbfc961dde51ed4477947b516b2e00ee8888848888884222221088888422222108888842d4f27fa3bed1f72b30ab393dd1df68fb959858b378a7aaf4ec3bfa7b3a2cbe09d2cdfb5c0ad4acb609d2edfb5c0ad4a96b3e71d152ece7d2bbfb8fb2aec5b10930f6c458d6bb4ef7bf55be2a9ab31796b6010c8c6b73bdc5efb7e2a7729bc8a6fb5ee54f4903aa6aa3885eee701ea56a9d8c118791aac2c5aa6a5d56f81ae394d85bad948a6a79297178629468bdaf1717bdb51d8b56b3f55fcce3bcce0168155ab372d3e4b67b3f188db2b393aca34387b20ac96a4d9d2486e2e350bfce6a4bc0735cd75c07020e89b151ebeb59434c64362f3935a4eb3fa2f9c2e57cf87452c86ee75ee7d6542e0f2def0f45a513e9e398d2b06a4127feacfe2145e035ed6696935d6734edb5f6f5ad5aa0c7fcfa0ee8e255fa96a1c5cc692a86111361a99d8cd811eea97faa4f77f2ab9700e696900822c6fb9537f549eefe55746c01248006d29b51bb7a05670a00b65bed9ca8f0e1f4b04a248e2d170bd8dc9b7e3dbed5236ae6ca885eed16cac27702095d1444b8b86657d8c85b1b844001e4b3bc9df3c97ba78abda9f349bb8ee05517277cf25ee9e2af6a7cd26ee3b8153d478df658f847f4d77f92c3bbca3da88ef28f6a2d65c01dd111109111110844444211111085ea017c93a958e15406b6a2eeb88db9b8fcef4d73835a4953410ba69046c17254ac33051511196a490c3e4b5b6bf6953bf67e887fc9f7bf4560f921a78b49ef6c6c68b0beaec554fe51c21c43217386c24dbf059b9e69092dd976bf0b865131ac9ec5de7bab2a5a58e92231c6496937cf7e4bb2a4fda567d59df7ff45e7ed2b0ff00e29fbffa269a798bae42b2dc5b0e8e3c8c758742a160bd2edcbfddc0ad4ac7d0d58a5ac139669017f16f6d615afed2b2de6aefbffa29aa217bdc0b47059982e234b4d03992bac6e4ec55c491452d8491b1e01b8d200dbdabe59494f1b8399031ae0322d162aa7f69a3fab3beff00e88794ccfaabbeff00e8a0104c0596a3b14c31cece48279dbfe2e355fccedef33805a159497106c98a78618ac2e3c40edc00d7ea561fb4acfaabbeff00e8a79a07bc36c360b370cc4a9a074a5eeb6671234e0abb19a87cd5f235daa37688037057d83744c1ebe2566ab6715154f99ac2dd3372d26f62b4381d44725036107c78af769dc49371ed4fa869108006caae0f3b5d893dce37b836f3d541c7cfff003a9c5bfd3ef5a05438eb9b1e214ef7334dad68245ed717d575f5fb4ccb79abbeff00e8a2744e9236e50b420aea7a5ac9fbe75ae45b45f40ff9a5c3fb7f2ab6aaca9653fd8ee0566fe946fd2c6bb99c88b68e9755b5a972f2899240f678391a4d22fa5bc5b7274903cb9a40d8050d1e274d1c5335ceb171246878eca160849c5e3ebd2e056a963e82ac5255b66d0d20dbe57b6b1656bfb4acb5fc19df7ff44b510bdef05a14383e214f4f4cf648eb1249fc2e3c9ef3c97bbef57ee6891a5ae17041046f056570daf6d04ee90b34b485ac0dad9ab1fda567d59df7ff0044d9e17b9f99a14f84e23490d2f772bac6e74b292ec0689ce26cf00926c0e43b2e10603439e521cb7fe8a38e52c64e74eefbff00a2b4a5ac86ad85d0bef6b5c11623b544eefd82e4957606e1350ecb1804f4593ada37d154ba27836d60ef1b0a8ba96bb14a0f0ea6263039d6660eab8dcb26f6b9af2d703a43222da95f8651236fc57278a503a8e6b0f94ea0fb2f844453aca44444211111085da185f3cad8e369739c6c02d219a9b05a410dc3e5b5dc01bdddbcee0aae0ae8a868c7835fc2241e3bc8f245f50e3f3956bdce7bc97925c75939950b9864363b0fcad682a5b46ccd1d8bc8df801fed5dc30498db1d2c95619a2e2d110693a235df60cf56b27237b657e8de4dc40f8d50e23a9b6f795e726bf8751da381576a8cd2bd8f2d69b05d2e1d8753d55309e71771bdc92562eb236c1572c6cbe8b1e5a2faec0d958d1609e174ac9dd3e807dec00bdac6d9e7d4a06237fa42a2ff00f23b895a5c1ba260ec3c4ab73c8e6461c0eab0b0aa48aa6b1d1c82e003a7aa8126011414f2bdd33de5ac25b66d86409cf5a898760fe1d0ba43373603ac006def95f7f585a1ab36a39cff00eb7702a0727b3c3dde90f00abb677f745d7d56bcb86528af8e10dfd241245cae71f27226bfc7a8739bb406807db9aaac3e805754be2e7340345ef6bed03deb4b5f58ca2a7323b371c9adde7e0a9793ced2ae95dffafde13e392431b9e4f455eb68e8d95714118b5cea2e5771c9a6875fc28fdcfd5566274cda4ad7c2c2486806e75e6015af594c74ff008b4bd8de012534cf7bc871e0971cc3e9a969da626d893ccf255f7deac22a5aba5a78abe1d44df2d633b67d45570eb5aec21a0e11107004106e08d799566793234158f84d20aa98b2e4102e08e04595462f57056c14f347e2cb9b5cdbe62d6b712aa35056f8be16695e668813138fddeaec55174e8b2e5197650620d98541ef859dfcf9af17a8acb0bc34d74ba4fbb6269f18efea1d69ce7068b9d9568217cf208d82e4af28f099ab299f334e8e88f1411e51dc140734b5da2e041191badcb5ad630318d0d6816006c54d8d6161ec3550b6ce1e580358dff154e2aaccf20ec765d257e0461a712466e40d7cd6777a714b2b0c3285d5d521b63a0dcdc40d415c738345cae6a189d3482360d4af0e1b2fd1a2b33b177936d9aafedc946827929e51244e2d70dcb69a0d31f37a0342d6b5b2b5ad6593c4a8cd155ba3ccb3ca613b42ad0ce2525a7ff82dcc4f0b750b592c6795cf22adf0fc719316c753663f569ec3dbbb82e58e61d73e1910001b6981c567c6a565418b4b4839b78e7213ad8ef9fc138c391d9e3fb28db890a88bb8abd4703c4155b628a4d59a774ee34c1da1ac070d5d5ad461d7a95806e2eb11cdcae22f75e222254d44444211111085a2e4d7f0a7ed1c0abb549c9afe14fda381576b1aabc52bd2f04fa067aff2b1b88f48547a47712b49829070984037b5ef9eaccaa0a9824a9c5a68a204b9d21cbd6b4b434a28e9590820917248da7e72f52b554e1dd86f15818142ff008c7c96fd3a8bfaafaacf339fd1bb8155f80bdb1e1923dc6c1af249dc2ca4e2b571d3523daecdf234b5ad1af316baa0a59669e9db87c2dfe249a44df5e4323d595ffe93218cba220e82eade235821c41ae66ae008b799d94f81efc6b136caf07998ad6045c0b6a1ab695cb93e2d884c3746788577494aca3a66c2cb9b66491993b4aa4e4fe588cc3fb0f109c1e1cc781b01a2aefa5743514ee90ddee3727eda7a2d12c9e3bd2d2f637805ac593c77a5a5ec6f00a3a2f9cf457bb4df4cdeaabb62d7e0dd110761e2564362d7e0dd110761e2558adf0c7558bd9bfab3d0fb2ef5801a29ee2ffbb7702b1456dab3cca7f44ee05624a6d17ca7aa9bb4de3b3a7ba9145109aae289c480e70b91af5ad8c30c74f136289a5ad0369bac8e19d230f7c2d8a656b8dc0e0adf66626163e4b6b7b5d7cbe46462ef70683b49b2f239a294911c8c711ac0702abb94248c39b6ff0090702a9b089cc388c5b9c747db928a3a7cd1e6075576af1734f5829dcd1636b9eabeb14a66b7147c30b6c2e2c075806cb4386d1368a90332d339bcf5eef57ceb55e07f9a2e3fdbf955d259e539037caea3c268a3f88967b6a1c40f20b8cd52d86a2185d7bcd70d3d62d97e2b862943e1d4a40039c666d3ab3ddebf8283ca3259e0ae06c4175bf053f0cad15b46d738fef1b93c75eff5fc52642c63656a98d4b2a67968a5f4fb2c839a5ae2d3ac2f9537121fe253fa42a19d4b55a6e015c04acc8f2de4485e2222551a2222108888842222210b45c9afe14fda381576a93935fc29fb4702aed635578a57a6607f40cf5fe5718a962824924637c7909249d7d9d8bcacab651d3999f73b1a06d3b97659ac71f3babdcd949d068fdd81aadf3afad2c2cef5ff00a8a66255030fa6bc4ddcdbc813c4a8559572564ee9a439ec1b00dc15df27618c52be6d11a65e5b7eab02b36b4fc9ee8f77a4f7057aa7f4c560b94c14996bc39fa9d4faab459ec03a4a6ee1e2168567b00e929bb878854a0f0deba6c57eae9ba9f65a2593c77a5a5ec6f00b58b278ef4b4bd8de013e8be73d141da6fa66f555db16bf06e8883b0f12b21b16bf06e8883b0f12ac56f863aac5ecdfd59e87d948acf329fd13b815892b6d59e653fa27702b125368be53d54dda6f1d9d3dd4bc37a420ef85b1d8b1d86f4841df0b63b1455bf305a1d98f05fd5576370c9350b5b1b1cf22404d85f2b154aca4e668679a78ded78735b1defaee6ff80b2d5aace507468ef8e05253cc45a3b27e2d86b4e7abbea06ca253cc27e50b24691e34609b6fd1170afb6acae043fc5233d4ee0b549b5600781e4a6ecfc86481ef3b9713fc2a4e520bb69da0664bbdca66134468a93f79e2c8f3a4ebec1b01fc7daa63e18e592391edd2747e4dce409b676df92e1893267d13c402eeddb6db6dd693bdccc6c634e69c68bbaa896b1c2e6da01d1663107892ba6734dc699b1df9a884eb5ebaf737d6bc5acd16002f3f91c5ef2e3c4af11112a8d11110844444211111085a2e4d7f0a7ed1c0abb549c9afe14fda381576b1aabc52bd3303d2819ebfca2acc728bc22944ac1e3c59f591b7d9afdaa450d509a6a980df4a291d6b9d97f77bc296407021c01045883a8a68bc325d4b208f11a52071fc10b0646765a7e4ef47bfd21e01536254868eadf1eb6bb369de3e7f1573c9de8f7fa43c02d0a97074570b8fc16374588e470b1170ad167b00e929bb87885a159ec03a4a6ee1e215383c37ae8f15faca6ea7d968964f1de9697b1bc02d62ca63bd2d2f637804fa2f9cf450769be99bd556ad7e0dd1107af895406883708156ed205d268816c88b1cfdbc15fe0dd110761e254f56418fd564f67e3732b35e2dbff0a455f99cfe8ddc0ac51dab6b59e673fa27702b1b1b0c920634125c40006d25251fc853fb4a09a8601c977c33a420ef85b1598f066d263d1c31925a1cd209d79807deb4ea1ac37702392d1ecdb0b2391a770543c52b5f434825635ae25e078c091a8f5f52af7e252d760d57a5e268e8e90612038170b039e62e01b6f0372efca1e8e6fa41c0acc03b14d4d1b5cc0eb6ab3719ad963aa7460dda45add42b2c0ba519d8782d52cc60d1ba3c5a36b9a41d126c72c8b6e3f05a673835a5c4d8345c93a8050566b20b725abd9d39691d7e04ff000170adab651c3a6eb124d9a2f9dd77594c4abdd5d57a449d069b301d816b132587bb636fb956a8310f8b9e50df945adf958ec4fa4a7ef9e2a26c0a5e27d233f7cf151372d667ca3a2f3ea9f19fd4af1111394088888422222108bd45da081d513b62636e49b00826da94e6b4b886b772af3936d77333bac6c48b1f6fc42ba5c6969d94b4ec898059a3336f28ef5d561ccf0f9090bd3f0e80d352b6376e1663c28d1e392cb736e7087006d704e6b500820104107510b1d880be21527748ee256970a7ba4c2e1738926c45cf51207e015bab60c81cb0701a922a2480ec6e47dd71c728fc22979d68f1e2cfac8dbecd7ed5f1c9de8f7fa43c029f59e673fa37702a0727ba3dde90f00a20e269c83c0abb244c662ec7b78837568b3d807494ddc3c42d0acf601d253770f10883c37a7e29f574dd4fb2d0aadadc15b5b52e98cc584db2d0bea006f564bd55e391cc376ad5aaa586a9a1928b81aaa7c6a16c18445137535e3d791cd4ac1ba220f5f12b8728ba39be90702bbe0d961500ea3c4ab2f24d38279ac4a763598bb9ad1601bfe94b999cec2f8ef60f691d971655f4782454952263299346f605b6f79566bc55db2bda0b46c56ccf454f3482578b91b2cfd57f3337bcce016855054b4bb94ed162736dec2f9582bf5354ecde8b3705d1f3ff007150f14a492b2979a8c0b8769666d7c8e5f8aa16e075fa40f3432fee1f15aa4491d43d8db052d560d4f552f78f241f25471334394a180dc35800bf5355bd4f9a4ddc7702aabfaa0f77f2ab5aaf349bb87814e975737a050d0b43609da3839cb16d1792c4ed5b9584b12fb5ae569f0486aa384be773846e17631dc7abdeacd5b416837d961f67a731cce8c349cdc7959516279e253f7ca8b6bab7c7a90c551e103c9909d5b0febad546d56637073010b12ba274552f6b86b72be511148a9a2222108888842f7ad69702a030c5e15237c778f101d837fafe75aaac2a84d6d586d8f36dcdf6ddbbd6b4f3cf1524064790d6372b0fc000a954c87c36ee574f81d1b6e6aa5d1addafcf9a54d4c74b4ee9647580190ff71d81661f8b573a52f6cce6dcdf45a72f62f8c46be4af9cbdd93064d6ee0a10f6a7c34e18dd752556c4f1692a64b464868dac77f35d1f23a591cf909739c6e4ef2a4b311ab8a0103662d637500076ebd6a114564b41d0858ad95ec24b4904a9a713ac313e3350f2d78b38137b85f54b89d4d1e8886401a1c1f673038122dac1041196a391da140d7ad2e932b76b277c44b983b31b8f3535b8ad6b5d7150fed39f15ce9ab27a590c90c9a0e70b136072f5a8d7be688ca392533ca487171b8db5d94bfa52b7eb127de29f4a56fd624fbc544c9324646f2097e267fde7eea5cb5f53342229652e603700db5f6af5988d54713636cee6b1b7b341b5be2a19ea4d5ad195b6b59277f2e6cd98df9dd4bfa52b7eb127de2be862b5cdd550fd77b5f23ea5091191bc825f8a9ff79fba93e193f84784f38ee76f7d25f6714ad26fe1127de50ee97c9195a77091b3cadbd9c45f5dd4bfa52b7eb127de29f4a568ff00c87fb4a889923237904bf133fef3f752c623542733897c770b1758663b3d4bd18a56027f7ef3716372a1a232b4f0482a261b38fdd4aa2aa14d5225731af1b4380397af6ad6c13c753089223769f9b1eb58853b0fc424a29ae093192349b7d7f3bd57a883bc171b85ad84627f08fcaff94efe4b51554ecaaa67c2fb59c3236d476158e9e0929e674523745cd36216ce09e3aa884b11bb4fcdbb55663d43cec42a636f8ccc9f61ac6c3eaf9d4ab534858ec8ee2b731ba36d4c22a62d481c3885994445a6b8644444217a75e6bedad2f706b412e27505cd5f60944df3c9ec18c1e2e96a3bcf60e2a391c18db956a929dd512860f53c871565454f1e1741790806da523b5e7bb80ffb59fc4f117574d768d160c837de7ad74c5314756cc58c3685a720369de556fa9450c441ceedcad3c46bdae68a68346374ebe6be51115958488888422222108888842222210888884222221088888422222108888842222210ac70dc49f432d8dcc6e3e337de3ad6a23923a9803da5af8de3dbd4b0eac30dc49f4325892e8c9f19bef1d6aad453e7fd4ddd7418562a69cf752eac3f85f389d1f8155ba317e6dd9b09ddf39283b16baba9e3c52803e221ce00ba337dbb467f3a964dcd2d71046613e0933b75dc6eaa6294629e6bb3563b507d97c22229d652974146faca96c6db817bb9d6bd829789620c900a5a5b369e3c811969759f9bae22bdd1511a5898185c6f23c1cdff000500a8f2e675cf0d95e3308a2eee3dcee7dba2f111148a8a222210888884222221088888422222108888842222210888884222221088888422222108888842b5c2f147513b41f7744e398da0ef0bbe3748c3a35d4e74a394f8c46fdfebe2a92ead708aad271a29469c336446d69de140f6657671eab569ea3be8fe165e3b1e47feaa9b22bd7f26256bdc39e6647afe08a4ef1aabfc0cfcbf217fffd9, 'ivan', 'tollardo');
INSERT INTO `users` (`ID_utente`, `username`, `password`, `email`, `avatar`, `nome`, `cognome`) VALUES
(3, 'ogambo', '1e4e888ac66f8dd41e00c5a7ac36a32a9950d271', 'andres.ocampoch@hotmail.com', 0xffd8ffe000104a46494600010200000100010000ffed003650686f746f73686f7020332e30003842494d04040000000000191c02670014355556315941454c2d57634367396e5f326c553600ffe2021c4943435f50524f46494c450001010000020c6c636d73021000006d6e74725247422058595a2007dc00010019000300290039616373704150504c0000000000000000000000000000000000000000000000000000f6d6000100000000d32d6c636d7300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a64657363000000fc0000005e637072740000015c0000000b777470740000016800000014626b70740000017c000000147258595a00000190000000146758595a000001a4000000146258595a000001b80000001472545243000001cc0000004067545243000001cc0000004062545243000001cc0000004064657363000000000000000363320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000074657874000000004642000058595a20000000000000f6d6000100000000d32d58595a20000000000000031600000333000002a458595a200000000000006fa2000038f50000039058595a2000000000000062990000b785000018da58595a2000000000000024a000000f840000b6cf63757276000000000000001a000000cb01c903630592086b0bf6103f15511b3421f1299032183b92460551775ded6b707a0589b19a7cac69bf7dd3c3e930ffffffdb004300080606070605080707070909080a0c150e0c0b0b0c1912130f151e1b201f1e1b1d1d2125302921232d241d1d2a392a2d313336363620283b3f3a343e30353633ffdb0043010909090c0b0c180e0e1833221d223333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333ffc200110802d002d003002200011101021101ffc4001b00000203010101000000000000000000000102000304050607ffc400190101010101010100000000000000000000000102030405ffc400190101010101010100000000000000000000000102030405ffda000c03000001110211000001f6441edb92421049242492492458419249092124909242432043010c2104924492424909240430124046800602182c6000c01080180321804c2490924043000802b0a50c050ca283295582aab01030a5565b54328aacb41594ef146c8c92a1062490924492458419249032424908440c9224909242431249092424909248920b4c91203010808909240480824892401902548d2420209200030504500400328b08a50caaa19450cb4aacb68560206022b8aeb43334bd722d8861e03619254920649242206090609464819244921248422218155e290c9120925921a92424912490904249080c0432006800d0526124809202480901041504045200241411685602aba881d6d40c295580a196baa1d3160034710c90c312cad8b0a9c8956b2490124960228c84314a3452182064044602349561073202164928c04924880ca10c41088924243010c0420924209082020208202022803050c050c050c2d50c050c048cb4aac2d40ca28653acb68e76917ad544ad18aba8c2b165a6991a2cca63636365d672d925b15b36130108b23281e2186809034a58d092449573bcb675ea33f8fa72fa46df96fa4b3d71aadd481a40848b1a0b0c0420904a82008002200c041042020808042280245570283050cb6812015940ac2d48c941581d235ce7ab2564218a562d154cb85940b8594cb8556d253b54d16957c8b06cd91e42c8b4f2b965a6a3164568921a19367363c76119b9d7a449ced38a27a3fa07c8be8d77dc827418241805345038503051460084184920210086288402182c3058c280244578561d4ae582dad6d2532e52a9645a8b4372bc2a5b862d65e64a59ac42d3401a6558b655034033cbc556cf16b96192389044090836884d2926492489c3ee79c97cb741fa1cbb79ee5fa1a72e351e828d73e2fb3f2dd9d72fa0c83ad808a924a90804320431042458d1563c448c55634858d290982c60286140150a851940a20052aab634a855915a50221d4656510c04324924b619249241619cd24848602192c9248b0c9a04cb21928c12c30124909e73d1f95ceb16e3cce3d9abe5eec6ed6e75bacc1b70f5e1f479277c430c08d0532124604322412c30458562305034483c55578a07082c7950ab16b1a8e8250005914ad8159765475b90550bd6854f40ca7cfe9840c9a2c868a32789070b21e21870b29a28871585b020d47359a735c8b4d00d1338ad233aa6a998d5fe7badcdcee713bdcff2f7f3fdbcfd497cc8ea94355fafb73f4a48f4702cb21ca34305963cae164ad4b8546c60204434210492120818a0220a01968022c0aeb4a196c0aeb4aac2915d6cad6c4d6512c5d63b9157e67b9c54352d5a67496049a8ed53459164ad1423cac558680683949a450e3c462184918cab18891cc21791e67cc7a9c79264bb071eda6b35f3e9604a75cf4fa8f3fd7ef8f4278fd4efc2c9594680d490c49206432c920648420924800c01240420108a00ca008450c2955858a1940acb4aae344475b944b1758db24f37a963caae590496410b9858d114c6030039ad22e39c59a4e426b38a1b66386d989a5d2b9c5cdf293a97ad554be579bd4e379f5d4c3aa99a6ab29e776644d371dbb382fd5dff004bf29f5bd397aa90ef46484324426449080c2b249124849212480860b0822b0a00cb02b002b0a50c115585286148aea22d8b55abaeb1bc633cbae999db58b8544b5aa92da8a450f37942c610b422b496032c11a2ac6221682c63091d0939fc9cefa5c4c33931274f0f35fab9f5add86dae62c682c9766b65b7d4f1b99bbf47d9e07b3d1e98f2fa9a4606484196430924590c0430064043010820300182004003055162881c08ae2c40eb622d8a2075a44b56a1068904254c34064241249090c018410c0431443006424320420a785b3cbe3ae9e7a55893564e8672d901b6ccef128ae0ce6cac8470cb5dde2f46a6f3e9c17b3d1edf96d175f477e1f73a23024920603124848602495248492408412494032803016100060a190922e750257a5ab54d4b62d7cf44aced8628d04ac1ca1872851e291a0904896982412a6a490301cd84153cfd7e425cb8b462cc54b29ce2ce9f3ed5c9bf0ed5a594a6796166a76211d7a2eb2caec9315b534cd8f4db5d4f7df33f4377ebe567a5b22c18a1468b068a4689068b068b256092c6880b0205b02296ad629c2a51482c640b4ca252889a915d0b65639db0d32cba506cbcd062e6ce4bdb3c341a0adc6985c682978a62dc6825b2a85a2ba0c1c3dfcce3d528393389535931af2f439ed68dfc9b4dd85168d8aacd95c11d79cd9746a6a339d78edce963d4d17eee6bdd7b2f41f3af73e89b4a9a8410c0492421102200c10920a920202000ad4502c200a8a29ab96a3a8521b115abd66245b3a9394de2f5748f34a74673cd6f3809b664634ccd2b49cc4d12885e739344ce4ba5312d3545b397a3ca66d98f3d5ca5948132191667a9968bda6674b56188a159240e23a38d9efc91686a24b5abb0665156fa3f2d669f543e7bbddb4f2b5b6e1554686c4d66d394cba66574bc550b455556918456d18cd9a529a1abe9a2adb5be1b23564af3e9a5f05bace9a6bc4d744f3da5d18ce4de7b450e30ed5b48ed5b4aef515b9a839d5c6932da6925d2a25b2a2586b8b64488d8abe273de9e5ccfc8a8a33ce29448b75724e8e3d4d68c77d1742abaa665953a38580b108290f2350d24252c09965a92eb0cfee7c7777b3d1aacefab2dcec5b444b1c4951529b8d2d96c2d5866e285b4389095da2a85be9d656445545b6caeb35ea2a32692a3580435d735b630ed5b66bb5665b4d44b4d465b4d6d0e522db2b61ca1ce9848372eff0031c77321a78e2c082192440add8414fb1f07bdbecc77e28aadad112c444b50c90acab0d7203db44a9d0c5ebfa4e0f1fdef93d4c0cb67191c3177578b6ef5ed9bcbf63d6e82679d26a38f54d0b9721b6b474aaf0c962019d9a997508100239509965b464ad42367df3d870b4ba128d56ab53972dd4d36edbcc379920a3329cd7646958a91d91a524194b21878b5cb3929c7e3bd181a9e59b52a923846904dbe9b7793eb4cedae27077f3b94437e4c5b2b6440af4b26430ac8e92cada6b7f35eb976fa9f2fe93d79d19deeeb7c1afaff0023e2cd9666399a8e76b776ee2dfabeb4737a7ecb5d869e98db5d2d9d3c4346cae346559d9e80c0f668956335d59de5beece73b3cdd99ee6a7bd2580d38d4ad84af4c58c92ca98f4464f4732411d91a1cab6696428c434d060653172cbaf9b571b968e329cb2ca826580ef2f3bd8e8b7ae9499bd0254f1094b70c6dcb2a96a7ae30d5b24121886ab035988ee9d26b2fa0e675bb5d57569e85a09cebcaf2bdd78df373a083cf0ed5b17fa7f2bbbaebd3579b47ad5ba374c5a6bbb3d206a25a98358f4ad2905a9735c20d19daa9bb8998d562da668d0eb222bae7512c92e3aaea5cfd03237a30ee86572852c2861ca3439e7d3cbb75e7271f3d5dc5ad73cde552648acc8cdbfd6eb5ccf4026ba34594d1653e4d1964f0fd8e77439b99a31e9932d772cc501d5980c19594624aead9c9d777bf9bab4e9d768dea5b52a8f83a1a337e793bfc0f271863485ea075bbfe334f6be95b1f47d749926a69c5ba5e555b3274e41e455ada202c92aa92b6d8b573e8d45a2544699aa8f5816c4cdccb650c7a0657ef89212329a728d0ef51ceacc59b278bd52b9386f952fcddfc423bdcd7d1e8f7baea3a1eb5a42a590cac24265d38e3ccdf57aae53c3e8dfcdc494ece7a16aef99cf60b2aa6922967ad2db29b6dea6ee5eed74ebc41ebc3a416687031d1797d3ad8f1a9ebbcdf9b194a9e525d4b575bd0797ef73f76f985bb6eda8cf778d55a6b082ca451221ab44969b1973baebb572b69aed9a0184d575d99b324a8a223d69de3537a736b5724b4a3ca590ace77453cfdf3e175f2f563a69cdcf47a2dfe8f3e2b2be4f7e7b68455e91e31b8f41679b79af456798b97be79562f4b00ab2e37430bf3cd5475b939d4c77d53096a32564442a245b53209af2694d56dd8ef5f476d1a7d9816abaad6f351433267b5db3799e57dfd1c1e15fd17138e7a9d3b0f83eb6aae9d1eae6b5e8cff004fc302cd64d1708cf7390259463694d8b72b538824b4d406bceab46ad2a46ad9b2ab688f50d71e5db3cd0779c836ce98c47673eaee6ea4e5bc7af32cd5966529d4c54a6f1754d2cb2ab2a2a64b35cd9d1b3b842d3bd16a1cf6e6c95aac9c9e8f8d764cea934973b52a90e560d04088892ea758d837e15f63b59bd9a0d1d52977b98cd33baac82c55ba1968d71338d78fe4fd2ac595e7773d777b38506e6f778697293482cac4adebb9ad585c5765d5e375baae76ad5c92b0110d3a738b5d864f5510f3eee533ef1b3372b19d0c68f721a04b42bac28549103654e36669729752d7369ad9a302a4756265dd9b2cd4edd9cad7868cf9a54c60258b22bab95c70801882fa5d7a381f535ed04b3bf5ae5ab553d8d552dec671a5528af43ea50da33c1a1e4d65a3a54f2eb8f706d40a076e55c774a069aa5c82caf5988f5e4880ad6f5dd2502c4957368a90232206accbd05cb354a56f83006c8e8e58aa54db5bac0c88ce8060023156a48c52068a0116582a88f04ad951e7f9fa50bb933318d15499dad566916a8acd06aad409b2d5a46a0bb3d6f87f71d350a36f44300d6ec50f635565941198a65c2ca45d5ca54b140b96b3d765772f59a56fccd4595a5d4dc2d5a925a94bc4aa5ab98322678c2455db42e2656997b69b563d715ca905aac4605448c924b0458d600c070b025616a48aaa5b598b6569ab3f432f9bbe5aa3ccd553a2238645aecae42cb690101742b73d4ed6ef51e5bd374d30036b62381d4964890c2350568892d52ab20b56abf3a2407533d1d24b311be8b2b5b16ca96c42557d32d49a2b4a49ae2caacae55aee10ee8f75c824e711a302310392b16c50306210d440240d1163a1093600d0009159892b78bab9fd5a7cfd71d376591208c80622b0e96a73a6fe6c591266da15c6b2b2bb7d2f95f55d36ed5cdd2c217415a5f5a824cf6ea5aca335db3cad12a316e702cb6a434efcd7b3486a435e54de356509acdf48aa5b0288552912ea2b5d6702cbb2bcb22a8f3004bd08610c840e2a166801e500d1190c5586203058d0c1eccef34209632bc97566d593874c35eaa265524450c89a760b7b41cbea529cd7adf852cacb2daec5d7d5e4753a6acb6b7ed93af33cd5ecb965b9459a95bebb24a4ded9b8db643161edd5672a6b4de318daba645dc1311baadca92d5b9a92d52b5b125ad1e556aeb2a232e6223ae6cac8cad3067a58ae4aa59056111d6352c300c608d0dc8758ad04042622335571e58ad244ba80bbe9b079bb65e65f530b1eb40f5f4d1e6a4f42a865cf3b3f5b95e7d3c072ba97bd57b3e77b1b6d3adbb5cd36d8654eab467bd8e4648190cb2029248406528752baaf16e3a37a6b3829e8e6dcc52faf59a16d95985d54223a4a95dd5c95aba42065cdd22bb26cdb5b12c5218b64aa2d6b2b5d10a5ac0a85d9282ed64576945565cb866e54cabad8c43625944d97cd62e7ece6f10362c67464993d4cbabb67a5567bb7b39ef2cd1cfe953cef2acaede515ea65ddb397eb35a5bac1d29b32d8aed55757b66ba2e941ad0d4bc96b607364a4a58a9957466b0aa94b85894161c22cd38752d66b34d4202cd515e8a45aeda59ab0f473c99d7a34a643a0ee67364cc121212299ab6b1c290956a1244109a92147d39b4e3765f9173bdc95556db752d1a0d492e5aba5978eb2e26c979a95dec5f34dbdd8edd36b4ad689baaeaf5c78ea7d0f9ce3cb4d545e8fe8385d2bbeeb516f5e8cf5297b56c598f525453688a2d830565d5259404306b4a4e84e76d4a2d39d58537a22a32be76a2aeae8a9374a719b930ba5b4df5c535d9993b02e3a73d3a0b73806ead730d4a944bd933cd04a069359cdf62e59a15282e2c42ed08cf7cd50ba354d606d8d1cdbb565cdd3e6f6d5c6e31763b81e8797e9ba5c366baf7a06096fa48b5c59245f31eab0e27946d6b8e55efc6ebdde9f9ff45d374bb26b57e7b1445e7edb34bd2d16ccf993a3573dacdcd9ee6ac7c574ad8acdb6645be98bf35b882d429b2a9a16aaa1ac2762a515de91cdb7444a8914831b49dd9cb4aea8c175691431725778a60896550b6b315acac8cac4a9c3001b8a6c106d1904686ad16ecba795cd9eb4cb9c526d7b8e8f7f14e9d75b50f74565820662a0f4a3e9c22327074d7c79d7ab2db73d0f47c1edefaa8d59f76d728a63a85ab62812c497d715f9dbac4e4ddb71253a2b07430ea75cf8fa1599aad58535574c5beb5cc9b715fb178ed66b678ba9761cb6d39c346cc859773049d47e7596ee6ccf575945858d5434ccd6974a996c94ac6d9cf86e5cd6d5c5e80b2d8324b8cf1cca6bcdc3e4bf129721d0c3b6bbf22f4ead6a85d050258f9eb9742e77ad0556391c5edf2f973a9ab2ceaf47e67d16b7aca5bd3605900a5e007b114352599f4adbcbdb6bc8ea0982dd59aaea46336dd8698df91692e54b46415ae77d74564a36a4cd16e67426a55ad2e0982012308d235f8dab468c2cbd35e7da6d9945ba9f3bcaf4a9b0917255aacbd51afa6e9eeab297265cb275ece25c6ee0f7fcf73ca292c0ec727d1b5b0515f5e9b139c9274ce10bd0b39f6dba14e53a17e3ba13cb7a3e0f3ce4804e5a7bfe7fb577d9d3953a6ee4aee508ac5ad4a173e67269c5626bae825aaf5ad06e65cce2d33b9c26ca731348a2935574aa699929b2dce97a521e99133c2844aa2836599506c4a65525a92d29b6cb0ac9b16a6b6ab96b2b96edbb9cebd65c14d7431e631aeaac408223b2b1daf3de9f91cf7c9ac2de4fd8e36c5da73b6f5b2ccd65bb12bcd2ad4e8cdfd1e1d95dea496e9e5f6799ce7306dcf39a763976dbe9420e9d6f4a6c41666bd0d94655d9b325aad8af433dd648b9a86546b2922e6365b9caa2d573a50d70546acaa54c898b3f4f1cc4b71ad9dac78ec5b732242db8de4d47345b95590130b2cce635ad16356bd70d032ad979a601ab0cdd2a60b544b41451d2e7688e8f01a8cc56365c8d4ba6eea6b6db73a6ca8a5d740068a57304473bb4e56b7abcc6bb3ae766d14e717eae494f616f0fbbd3b28a2ba76adcb3369ba54956b2994dd55eecc25d133e64df4e7712b8946f4ae3555950b85450d21902aa0b15e40d4df6e2a5abce62808a61b240a686a6e695e29614b2123c03aa969a54d632dc4575b23244b543294772be8f3fab2d1cbd19724ba9763769aeed75536028cbb2b4c73525cd32e65ca2e4608216cdbcfd2b6e2d78b9dcbab3eb935efe4eabd3b79aa9d6d97f3ba2b4db641129747a19016d79d3a39abce5e94192e48916d94a568a68acd531918d35b26bad9977ab53534e4d4d73736fe73321b24a424b1c860d959560a11eea5e57922bdb9ac0ab02b16c44b29b890c531458ed5b2cdd93a5cf75f3eec39af6681ac1d5c66de76559c26dbb964e9e7cccad105cde287090e030cbd4cfddc7c3d1c7cbd4cbac35f5a69b1b0ddd73bd9b0b5be8a217d98e46ba6854b6a6ac799a2697c90d59d524b621b415125404b1ed5b1a392d103a3c9b9535d5a4c5cde863b964748a219730ac476acc3bd6cad654c5d5c0af656ca196491eb61d1ec5ac95a30322aeab8c3df4bf1db9b9b65106b7b6e7963d1bef3e66cf4ef2f93dbe809c1b3b0ebc86e88979b4f5b6d9e74fa043cd0f4b51cdb31f339ebd566c1d7e7d39d72d7d328d71ebcf0d52f615e2ab2a225ea80628a1b16d3387294bd90ae395a56e51b35f813ad82da575e56a8343aa6cbf25ed54816a50d5328765c7347589c93d8b238767a036f06def15e0e8eb49798fd22655d8ab9eeb8c54e5965b5b0cb5d81ba9d79d63c9a31e6d34b736f31d4e6efde3a3762d2e9a5e8b5ab4890f0cd01862b2e820921715be7e642eae9de7c3ea899deb197a1cfb27478966a6dadc6f391f43265a3a5a6ce4a766cd3819bd0e74e04d88c65d40cb756555a9b6921cd6d990ad932eaf5aa2954060a3af39682bd36256433d47539eace058e4125a1ad684c168d523a8d19e5ad9cc566d8b597948c56259571f96b765e62dcb22e9d72b772eadeaab95ed9a2bb15c2c5b8238cd5c2d19aa8d3e7a73673e8e5cfe9a66f2b7bb67d0f25e3737d46599e026fd0c713b965bbd35d2c6f25d7bc253a50cd6540d4fcad918f9bea033e447a0c9ac728eecf65d92dce25b04286ac2b18452d5722db49501143344eac8d3a964363b061dd1e8b8906cada9deb61a2995ca9a70a21c2594c1546f35e8a993c9bf7ea9cf27469975bade55735d75e284eb8e55277138f13b5939ea9b6ba172b651532e75d96e4375d2e49dfd775e72def7263b397374e74c48f972bf1ebbf53159b8ae65dcb5cfabae1316db1ad56c7cc93a7567dc5ad9ad5a83ad99399dc973e75bd0f1d31874660269030040a854a28582e7b054ceb63504d0d8e1bcf3953acdc40bde1e7c27a01c173b35f2c1d44e788dd5f3999d633d07426562d9557171a1d0be5b9095929271d69a0d4cb9d5a65e6bb8956c3b1793a358b32e8a2d97a145b73a68eaf01eeaadd8ebe5ad1919d1cde33ba2da5ecbacc64d88f5cb79aea5d9763aece6ebaba1db8ce9644d56aabdd9b9ad86dac5b4e69b72eb8e78dd56f1c6c7db9acf0275aa99e507a6e4a85b0a411fffc4003010000202020103040104020300030101000102001103122104101320223141300514233240503334422443604470ffda0008010000010502ff00755fff00aa5cbfff003972ff00fcddcbff002aff00dfdfa2ff00fc8d7e1bfc952a57ff008bb97369b4da6d36972fd572e5faea54af436544993f50c4907ea6978baac39bfd854afcf7e9b97e8a95f8f3f5214e5cece4b1ec32d4e97f51650991722ffb5a95f8ae5cb97e9b97f873bea99b297727485a72d36d0794ce93ab6c7911b61fe9aa54a952a54a952a576b97e8a952a54a952bd004d44af4d7a2e5fa7aa349909d8f2c45c66eea67e9b9fcbd3fe0bff36a57e1a952a6b35952a577aed52a6b3595e8e60ef72ff0f5ed52adce0e1f14286fc4615aedfa33ff0027f8952a576a952bf35cb97fe9ff0052fefd2e30726530cd44a8d8c19971e87f493ffcefcb5fe65cb9b4b97fe93f53f9e889272ac29359af1a4ea17f8ff4d3ff00cfff003ae5cb97f86e6d3713c83fd275d90e46e957c7d3752e2fc9c8662ad95ad098e37c3fa6ff00dff4d4aff7772e5cbf45cb972e5cb972e5cebd756c5cf4b9914418ae2e3d313e3a64c4b00ac3fa762bea3d17fecae5cbef72fb5cbfc572e5cb972fb3644c632f53d3650a7f8f2d098fdf9724ca35880476d71fe95bca952a7339ed7369b4da6dfea6e5cb9b4da5f6b972e5cb97369b4b97eaaed52a6b359acebba5f3b7832e2c98335e0cf90b05ad0bb2c53c264a849cd307b1b69b4da6d2ff00d55f6b972fbd095eabed72e5f7d66a66a657a6bd1c5751d62214eafc91f18bdf6098c515e4a702966011662cbb755feb76972e5fe0e67339ef5284a1284e2712e5fa6e6e27926f3613699ba63fb9cea3137f256588d6ad7b5d0c6be7cc284c6ed91fa2eaba4c7febaa54a952a577a95389ed9ed9626c04de6f379b9972e5faacfa9db507ab38279b6cd8dbdaeb67fa4f21858b0c2eb891f36f3a6ea5f195d6bf4bcf9dcffacb13613713713c9379b4b96b091ebd8f6b3f96c0197ae4c6dd5677ce31e3df230fe45c9e383354cae5e0f99f5f03a5ff00946107a8c5fab6c31f518f27fb0aff00258850f998ccd9b639324c2794158d398e2a2a984345f9970cc3c6561fce7898b390b8baf6518bac56ff00338ed72ffd3e47d064ce047ca5a168796c5cbf5075c69fd5b997ac2f70125b9970c1c3d2b66f9443c068af3075871c560ebfe828ca87b54a943fcdcf936393862d7d93e7a7f8cedfca9fd4430d415777043088ec4f49980fdc24065c47e7f4ec9ecff38f13684925b83daea5dff9953abcbe2c2723e52c65cbe070abec5bd980f60e09ed535804f1b31287c787ddd31f7f4c787fa1dba4ea8f4ee8c3227f877e9e25cb97defb1b95fe7bb845ccedd4e5c991545dc318c2baa9c9ba01c82743f3f5f7dd532f87c7d43a62f665e9ff00e46044fa81a706743d5ae0c7b5f6b972e5cbed7fe15f7b972e5cda5cb9b54dcf7b9736972e5cda5cb972e5cb972e6d2e5cda5cda6d36973aa62f1d3330f054621619f77b31e2635f2304c0aac9d331839ec65c45cdfb51e7bcb65d8fbba91b05ec2031089d07515fe9aa54a328ca328ca3daa54a3f9f2beaacc4ba98ce4f63312866e981ea7a97bdd7d17dae0f9195f1c197243c9ba3e5fe207d00d15c93a6cde7c1fe2dfa4b013ca27944dc4d97d24ce271389c4e271389c4b12ff1f1389c4e2713a8cb8d5b266430b810d4267d063e3e9fa9fdb853b410fa8761d9fe5780ff00d80952bb2d4fd3b3f8f2fa6e6f53613823f2130b5ce252c1f07e3697014ab9f7b19518b2cf319b19b19b196659972ff05cb972e5cbf4e5cbe35ca99b2b9a12c4e4fa546b043dae5f3ea3c93c0ec25cb9703913f4febce79b09bc2c26c26d2e0826d3c953c9c6eb3659b88724dbb6e44dc99bc6c9736ed72e1c84f6310eb3266b9706436f959a1f83f86e5fe5240197a8f18c9d518f90b1b3093e90794a30d283dc7a89a8bc933ec4b9627b66a0ca163db3a4ce73f4fd84f6885b8bf50977dcb773dcf668443d8987b5c24cda5ff8fd5b5637ea36872c2e48e673dae62ff9a05a2161e0771ea30463eef9ed7389420a9adc1884e83f8f276bed7e879666e62927b99570087b5cd7822711da93cbb4f8879ed7e8d657e7b97defbf51d59c532f52d95ae5cb12e5f7e83a439b2752cadd6ffeae1f40f537633a2c5e4eabf50e98e3cbdb99cc0488ae44e9f200e32a99e459e402792e07b8cc4019206067cc3c1ab3c5df6e65f6b3e81c40412f1e2bcd84ada15d7b050669358545ff0088f96364b244af5747d0f9e647183020b63f23907bfccf8f5787f82a7df498bc3d39e675b83c39fd37531e62a55838ada7c4be57dc0e3b55e1be06f604155daf981a6d2e7061f6c0766cbc30c919efbd3572a77e0f30965232887ddf82bf1e4cb8f107eb8c39a6d3e176972e5f6e8fa0f24f81fa964d7a7c58af06b07e254393275642bdf1d2206ca58c59d5621d462652ad3697d97fb0b984b636dc11c9edcc47a8e29da0ec1ccba832c06e5812e6d0e4137e0bec5751320173e60494a01352fb0f961b19b1ff000b23f8d32b0c98cf10c3cfa1559db1f47d4646c1fa7e2c5dff00536bcea7278488789f50fc7ab164f1e662723ea6617189d29d2e289d6f49e65f8efb419089e5306533a760cc3db08ed736b53f33ea31edcc5266e0424dfc7600d6d4390d5cfc03f370f03b19cc2dfe113a8ea3288dfd4fb4ed63bf4fd33f50f83a6c7d3afa3ab7dba9b387213c37f61c31ec60f4fdc505ce50557a6ffa804bd429b1e3c6e7a9e9b4f52656c6f8729cd8ecc3cf61f37e8fbf99af0cde9f6697362f08f77ccb170ff63f3f24dd9e23432e5fe52c001d5623337548433d82ddbe3bf49fa79cb1312635a952bb12157972d8723900e3c5ce8dcc06fb183bdcbecabb90b41c6f87a7cc336213e4d6c49a8c83263ca9e3c9df981b598ba8283075233ca87e7b0ecd72809e485c9ec61aa9f30f2c620011470c7df5c9f9fbe046f69ed753e7f35a89d467da06d65d4f91dc0666e9bf4d54f5f502fa6c77e51337cfff00cc44d673df99539952a74ff313e51cf4bd4ed6145ca155c4eb3a6f2acb97d82cf9381f1e3ce1c3c33ec7c5d451b33aea84717dcf6f93d841f2168715ff00bfb63141b623613e019f538fc27a9a6fdc99fb8266624a930f3369f1dae60e8b2e7187a7c3804b972e5cda5cea0fff001ba504f56dec8fcbb3da4fabefb4b82023b06607f713c9531a63ce55783dc41f3d6747cf7bec2265756c397c878580ec4ad76c8e342a35e7b7d76d7d0381b9a267c4fb227c76b87b1e3f1ea18645c091b597c5d18603dba3e97ceff87a9ffabd17fddeb5722655c64c7f685167298bfd6bda04a840ec440daf6f9988ef8701d5ae6d7d87c2cf897ce7e8d729746c6ddee2f130f503194232630b88167c71aa5dce2bb1f418aa67005f13e09f99f7709a3b72ff0033e7f05f624287ea65b4a9acce946282c5b0e449d1f498ce3f897f87aaff00a9d0ff00dc7f7ae722a899f0adf2bf30763d8fc1887b6068326a67dca8388dcf6b9971ae55cf87c2ddbea74ab790f30632c150213f3daa7c43dea55436654548d62598389f772ea37ba7dfd9fc4ce116b2666fe3c058db4a8c032e2e8b2e46c58570a97548f98b45c8c857a949fb9c76b911896559b2fa7adffa7fa7ff00dbcb9ce3cca3d8392c78313e4fcf71fd8fc1edf2318e32fb30e2e704fa5e21f455c3d2e2ccbd4f438d7a6aaefd3a528a114a98d8ca9d657735da89812bb1e23197dffac03b1352a38a879821fc540cc993c635de0a13c41115598e2c014e932645109b23969f73ea7c4562b0750d067262f513ac753d27e9dff6b2537ea4e06ebfd09e4c5fec67df7e6bb218a297a9613a7e7a7ec65713e601c7c4177771952f3f46acb871ef982c3c4d8cc794387bec7b54a1daec93098671368013050972e7db41ee459f7f47e7c227844f0cf14d0ca3d87664a9eec931145391f76c794e31fbae1f236483e2571e93d87247b4583329ff00e3f44c57a8cf997f7394f24c07b7c4bfc039990b05f99d20ae8fee6bcb1a039816a58aa9f5ad4d63083029c93facbe4e3e31e5a8cb504b37af63ccfeb2f9eeab7e8b9f10c4e19872603508e7d793a9d5bf7821ea418cc5cdf03b7c897c288631f50fea67ca0fef9dbd9d2ff7c931233f4cc0af6bf45fab17cf500f655a482eeee55c1c4bedf136e04632bb1c5bc0896c6a05e4eb922860bad086a732bb54aa8799a13d88aec65d1f9edffa3f107c915ea6ea31acc9d4b30ec27d5f6fbec6084f27d357076b9f7d47fc7d209971b89d3640706636d2a1595161f5270f9594e3189d9a84d66b2a1e2059a99aca9af626e697020596264a60b1b191147922efae9db783b6d509b953e27347b895c89ac3f3f10c354795bed623f508932676784cb95e8faee20f9b9f645c1dafb8ec3b641e55c58fc67aafe3c2ea1454e6599b4b8386f4d4ae07131e4d5b1bee952a5ca1d876a1284238015635c23b542c476a266b0fc95262ac3c43f15c37c2ecb0b319f6dfdbeaa02043572f86e60861f8fa8d9358d90b4bf47c7ac77fbfb33ea010cb83e76e3897c4c0bb66ccde31f2655ca95050352a7d013c743b37c03edb9d2757e13dbe3bd76a329a0f8f8ed735b0178f6c12c4267cca9750bcf6cbb87e0f11989970f6bec4295d782443f1dabb1c97073d88aeff007cd7cf7138edc987d1f75043f27b1edf3d8fca31c58f517ed9c7632bbfd7c1ee254d654d78ef7280947bfcf6ba13800d4f986e02561410113895738bd2149539867dfdd43ccfb1c4fb204fb261822ad465d7d0071f12b813e85fa87c995e81e8f995dfff005708db078aa71284a86095deb9fbed5040d04c43f904363bdfa7e65d76d84f9868406e19f4dc9238d6819ccb6f4fdfc4ba0799f1396ed5b12bc995031942bb895e81e9fba9f5f7dfe3b7c4fbee22cfbe994999dc5ca84fa4c1c9970fa04c5fde84aec25a99c77f19952b8d61172a6bdbec8b054ce44f24055a68b0a830f13e65087b6c21970f607bd7658df92fb0ec0cfbef5f83ff003136380e3812a39ec7b5f65c672cd3c7e8fa83b27f51ccfa9c803b0bedec8089c4e0c03b732f9be68d721bc820612f1c0365f0d36ab0850692322ca1063b3a1950e369a34d4dea66a95a2cd26b1bdbebae178977d87aebd15e9a1dbeb89d3fc31d5f234a9f644aeea3519176495d85cda6d2e6305a29b9b576e0cf89f118b4155ed96b7b240cb2c42fc37cdf00c3902c2fc5d41cce5a2e438e794306c86bd3f12dabc8d5bb4d9a6ed2cff8352bf1eb71b154d4cab9adc20de01edcb609684d9b5109ef887304c89a3cbed4601054c7c95c94be5a2992cf92d800dd891d89f76d02ca027156ab0700ff00533db46a59025d4b3d8c3f90fa2bf18e25cbfc818cbbedb11362662feb92f6a8409c7a11754ed931ee83d175030313e7812949ff00cf2c53686d429e7dc605e5454d26a2015e838d496e9e7ede1e9c57827844d05103bd4a87f01f50025423d153595dfeff000dfa2bb0a858443ec279c86a168043d91767be7b099d02b8ee390454c6f2c100ac00d529657219ada2626dc6258140fc952a186e6b2bd27f1d9977db5175cfa07612bbd7aabbd4af4e3ff8c25bf519064c8ab0f7c09ed38bdbe3a84153f4e3742353d94cfec08d4f4cdba7dd3123141884000fce4851b2d7cca950ac649ac23b6b0887b7d7aaae6b53ec720ac5e7b6b054f6dea928095c50a02e1513c6669cf88418f82aa26b2bb6b3e604b953c6678889884cd90e4212a187b01654952ae196e13c9f9fbcab4df7d94d4a0d3a7c14c31be8bba4f2110b4de6c612d0399bf01e6f3614083e926a17e198b37107b65b42e00f28daae64d447c8b54745ad6a78d68635135430e359a855c88d2aa18c4410186a5cb138edcc12a6b2c4f9ed604d966d3713db032d7cc352940d82c2c2572c67317633ef364549750730f109ed89788bf3ad40b73c6250bce85b1dc02e7c7606a74fa784b8137247ba376171ac0f817c8138828430334de6d369cee3fb1e25fb4baeac29576d8e3762b1b1ac3842ab6ab2818a7662fc7061e21276b24b5285b318b08d55e8bf45c0cc26e659edf3eb5353e6242520a860594c4ecb3901b02cf0cf1cc9c7655b21085805ce41548554c4004f6ccc9e3c818acb578c0a95373a46f65f1c0816ceb50ff759f5cb3cf89b42c166d2a7d1f8da1344159bc0009ed941b23501a298af6ebe3d87f635a0c8522b18b6cd5eebd89170d42ca55695b927fa9d26a26b38ec21fccb2d6b6596b16792c8713da46e00f2155404a3b85993313dfa74b804d901f22c5d9a51835303286d92bae41913e3b2922285251485c5b38ba8b90d4f734f6d542228d60308b83e3b1244e2707b7098ce598b7d8b7b0bd21cb43f700056578456461719bc6af926e2b6a6f37b76e4319b8003dc0c35632a6b0a42b2a54a952bbd7a6a57ac2db3b5c0b02130e335a988bec6cca884b3cd0c2359f317085518a0c60c0b501e6ee50dfda415d81febd463f119ac1715bd9d1352b290689010ca9bf16d6bfdb525fc77026a38b016174b144b2dae3c61491c30b50814fb895c7ef5fe21e3c4e87c741171ccb96a7bb2c1fc7195af4c80f8acea9328c6a4ab41607c129c2512da83daa6b359acd66b349a4d269024d2049a4d1a68d353353343353359fd53189404f6c1c4e2634c832bb7b86d323ea7e674c9b66f83ee524416cbd89b3510dcd4ccf8bcabaf3c08184f209d364c9e6b9ccf91c086c425af164a5d8800e478c424b98c9b6e4ab3c3979f26f93716d98abdd8a7302c1885e4c861ccc546650a0234d6e15067b8c6e177e68df220c8db0c8207103d17b676daee6c26e279166f369b4dae732e5c5b307cec2c1a97369b76d44aa84500cb2e72471365bfaa6db202576cf8a375d92b7e6cce84fb8f2a00af609f106c6106a8b167611769e2da2af8e65ea30d180089acc39407f0a42487d72b455d401729600b666f1b2457461fc600a30a6d326320ea2b2b2c16171ef5adcf7a105f56fe56382e7844f32244c8a5bcc005cce46db838c83b35b8742aa4b92daec490e259687234667306d3568a0ce67328980d42c7b5f6b9c76fbae6b8fbb950ce0ca128453ee3c0b8932b6724ef3532a635dd931f8b102c7b70b361b7931531e398cce27f319e3ca4be02b8fc0ec5942cf98bed2811e283e2dad36cb4ae289b238556607933933c36cd885a813f8d00c80ce0cd523875945a633e380869ae3a740d2815d498054d552057d474e756538cf85b21db740a2dd15d70a72c350d4c2976a58c441032cbda0e27026c3b032ea0e60946ea54a953530eb389b89b71bb42ce60dccf0b421146b73c45620f63289958ab966973a6f7643884d5497e622dad6aca6bb2950a4adec25b341c4ea7a83752a08bc1c347a7f99535b6df9f1d8b6504869b9580ce04db8f71871949f1158c7c45a64a07581c05f32b31c9eed412c0a9754330938db3e4f336ebb39d4266b94ce72a930a3db364df80ecca0e4cab903b7b4720b1bd984194c19a07da5cda6c66ed3632ccdcd6c66d3c90e633cb3c8679223a5fb04dd94db4da2a2b37865f3404ea5ce3c56f09377359d32de601c43bdac24a9d75158f58436cfb181824f734a33a949ad29370413a7f774cabd88a04fb4aac09b4186052a4b70289e04d4505ed6626756991b131b513742bad31731f630e36857224c750e3332e32531a0654c690b2cf25c2b67c4eac3cb914a95ec1059d60f40e66e6b631336b3ca0cdc40d3732c980c2e26d2fb0812ca2c067d958ee404eac88d97c8544eb05216ed50589d2fb9beea6ca06ea4639628b54e2d8ea0fb8a18389d46babb1c8d3ec7cf47671e325a055aad6000ce2f66d9727b033116679562f504bf07b6875d1ac62e1c031f1818d46151e584ee3c4ba9093e270631bc484ece42b2849e29e2cc186d8e5056b679b22cf2cdb73aa16ef53e3b0ec25cda6d369763b0102962b885f8409e3612b9fa6cac4b3ed2ea09b913aa1b74fe8e83fe06ca189ce6799ab7202915bb215ccd032313a01e42481b03ed995c5655d4f653c748fa2792a16b9e42b2cb4f708a1a98050321282793db7736580f3e661016ec3526c90bbc1ff00131f66e67bb62c18ff0058cdbbe33fc99064334665fe54c7e684e12462da78df1c2ac60c609ad7d372e09ace2710094c3d02089c4b2629c626a96c424f29b52298f6e0ce20e4ff006561461301981c042671aae28179186655c6936e263cc526e25ef0bd1c9ee87de9acd66b3a57d52ec07b3e436cdcbb78f3b1b57f601cc6f6cffc873591ca156f211842b879c2ae2651392370b3c960d632c2db5262e39e3ca18bda9a9ca4d796558f8fdd4c21db55ea4ac28b911b1b635f80789f7a830a4f8ef73e66ab2a7c4e26970f12c4d8cf24570279a1c84cda7301a879952a13c6304e6d6758ba927b098fe20353cdc2e6d60ea9e3e4d8f7572a71ba158e2c6a63af751ca6d28d81cd719580c82d89c9517a8a60fc87b556020c9ee9ff00a0092ab73e86e55ffb92f3546978d2789a10c5b6e2d8f6b066c0c263b8d4bb08cf39a47707c8e231bec0c066dd8d4aee0cbec3997537135468d8d5400ac480b2ee7138972fd3d28454c9d50547667304ae67339306330830417358b57b76b22265e464da66cc464f3d1de0c8931b29c832a08cbb457561bead9f1d45f6c0b797f6fae49cd113945fec40507e6074394f518d43e70d891716307578ea15532514c84af948552171b3c7d6c87d6cc2f536964b78842a6132e6d2e0301ec27ccb97dec4ba9b4b950cb8bc823bfc76b80fa062df094712c89b0ecabc040b2a7d0319c8808243acb5a6702330ec09953ef2e3f29f1c2953da20b33a75f23f2a37681da1dab5e59a007c4b38625403e5c6420944cffebfec7ff23c70859b6a9ca4f3344e4afc9a56db62b904f2197cee4106161a876b02e31b7f5df6aedf02b69552ccb9b4b9c19af623b7d030f32bbdcc2e8b87cb808c99763ed301115a7004a8ed0b77be0f32a0edcc0c6616bc8d8f5764e4955898e2b155c796e361210f077d99633718df5c5acfb6a68c02427f8f1e42d1c301e400f9679356f234ba6b98f6dd89ec0a899332ea4adec75f2592794d6afc8caa1b2e3fe8793e9bedf3dec820cb84c135ec3b6c440f7d8caed7df8edd3b2a74b954336867f5808b51c7cc0211c78e78278678a69475aeccb38efd3b15cb930e405944d0021ae27bdbc6c2656054bee896469ed16d136994bd6a3c68a043ae8d8dc0fa394b0ae4fcd4a3070779b910e432d8f635398de4815a04edad30603a81473badcfb9f5e81db69704bee1a7ccd78a9f3dee7c407b5c2099cce66353ab6a7258bff91b8130ba2a9c895e636d99ac67343288d97b5cd8cbed7df9b7c2cd8bc463e22a485a5500f0262cb1b2098b988fee3fd76754ddb2422a30105025a73361198c1042f50997d8af1435ec3e16ec9ec12e7ff69ffb20536434c3e7ebd17dcf6f9f4180d424cda7cca9f1011df9be66d2f8505a212b81b2fb48d46308666022fcdfa83422e7dc067cf6a9f1011593a7da3f4d4ba82cb75a92e31d145b62d8f19391a83f1b4d8cda6d398b2b8e66d369b4da03667dd887e389c198d3688c1664b06855d44cd31d3e4f9393961f3f844e7b09f60fa3e27ccd4cd7bdf6fada0b24a389e2da300cf8d4099fe4f6a831b3cf164b4e8b299fb2cb7fb2c93f60d3f646cf43513a50e5ba3c809e93268dd3e4131ab799f20f3075246f32ad8fbb34e21bd76e3e7b7d6d426d2ccd8cda6d0519cdfd7067c45845cf8eca0533fbaf5c20ccbee5fafa9d3ff6f27bf272561e47ac76beff007ea067ccaec3e7536bd3e663fb4698708e9928a63c8e351c47c9a8e942659fb6c60b74d86ce35484f109e01efee8fb44100d567c46720e73d33c2e1274dd5d46611d62bf0a5b6c98693525b859b197c1972e7025df6e04f6904184133c750a8027357c2f2339a7f92d92e010f62654c5ff002370721e68886ff15163e2c9061c860e93352748ed17a57bfdaa103a414bd2241871aa9e9b152e1c620c693e16cd92603c63e467ccb09da316bdaa3e42edd3b15c6ae607780dce6ea57733882e6c25b4d4b17c8143e633a8c84e508d90f8e8a64f6aeac35633528578990146f252f9b1eca3053f4950e22a4e2027892363503c753e65112e246352a6934e750263e1f2b5e4ad615edf72bb21f7e761e431cc249ec3a7b8bd28b1871dae0c77e0c622e3c6abedd754301d56c09b0336b97c6c0404117dc99f404e66bee3cf6fa755d9808d56e7dc891045060f8532ebb5d77027d7db2dcd5367f62bb944c995972e0e9b26475c0bab63a441b62438d1d3599c998d8b16ca002abaf88455409eddb18023e465879870210fd32ea5322cb0ddaea6c27f59b4669cc72553e58f2ff5e83147b98db27ba11eff009edf1dbee6ddae027f1d5caef5cfc44b2c5c564ce279000ec58a888b0598076a5bedcf61077e637c7539fdfbf89fa737d4005a32544c6a0ff54cd81cb17c98cfee0c1d4b2c2c723e362abfde6d96db2ac4cf8dcb64d583642a0bcdae2b1a203c6c41e3e27c63904b4da5c513335b2af73e96353244fed97861dc4aedcca820ed572a5761b5d77aed5db9972ae1f8cbd4543901962a62062ac026c273d8377aa9f5f76a27971ac3d462bea7ab3115b2c746c5301c2311cd8da7971cd9481cbebb1cb8d328f0282bd0289e008432894d5f02f87e5be0fba1ce19998b4c6caf8863ddbe231a5d71b28e931e48dd2e5d986a07b575b37cd5c363b54f8ec3e7273330fe31fd9f97f40f481e9a9c7aae6c2020f722c67e9cde8d0234c780c5482542018b9043992798187a8513f753f743439cdf9499b73b180f28b731b3e3671bc50d85b7c866b9f293d2f5131753931b23f91b75cb1c63c2bfb82464ce7556ce60fdcb418f2997d42c3d49c61bacc75e5072261f24f1d8b53919828c99d440bb3522cd90279065196fc4c98f32e5565612cc26fbd7a0927bdcbed5c41d808073dbe7b0f40eff005005ed736513ca821cd8e33e29b289e610f50679de1cac41a9709b972fb03ccb84c66a809696275390675c38b78fd3a6b871a9c5ed46f22accd81ba96e94789571aa8c8c0be4c61a6001318f9e07634556033517f7553a8ca30c2e733fed8898f02638ae44f6c271e124bb2bff005c48c8722f923e1e581128f7339f5df6fbb972efb5c12e588584f2ac399279d67ee04fdccfdc987a97b39dccf234f21ae5a1b9ccb97ea2d035866d616a36c4ecc66a44e443c46c190a049a6a69440010991df1b017d3915c11ff00b586f28534053cdae684e22ba06b80ee76584b76ba45e143cea7dfd404d0ab6c9e42485d61c6de42c74d810e2d8fba790d92a1b262c41db1600a703421a1fc1ace26c04f22cf2acf3c3d4b19e7733cac6790cd8cb9b4066d52f8265f05e5f676e55fdbc76de06060e46d4ca443408a272e3509b186dd42c4459431b712b80b4d8b26b3c3a3b61b6f164a5d954ef915485527dd8f21b235c6a795369c6bec78ec989775a0e4a7f6085a8ea86e86cac037b83c4dedd519f164548fa1870f2bd45419966426f874640513d9072daac245ebc78d4418664e9f188dd1f2c8c87d3fffc400281100030001040203000203000300000000000111100212202130310340411351223261507071ffda0008010211013f01ff00d8c97df9e54365289dff00c4e9f66846bf8a9abe1129f5297ea68d2db1742d498f523e4f7e2a5cd294a52e7743f91f184278fe3d5189512499b3b3e4e1717cef0f14bca97c104fa87e0f543d8feb33b21334a52a371b8de6f379b8a537219fcbfd8f5d66ad427f598fe53f90dcc5a87abc7b4da428f0bd8d7d084e33109e44a21b10fb7c58997e8c3ac744e308421098841b188d3c2705e2b8a5294a52ac565656565294a52970b0d9ec62e1bb0f085fd79bd1730de6f46f46ee532ba1bcae4f85177c6a2aca4748dc84d1aa334a5470538a294a52e5178691f89299786e09e5758825d70be490ef3ecff821f169a12ec6bf78f62efa3d0c5a30ca7b21b91fa7b369278961bca443f796997b35eaaf0bb1a8529494f45cb161313352a2d3e2595d21e12a4ca2978e944ec5d6352fdca1e34e10f52c528bc490be33f8e0de52a2cb3461f1d2cd44fd1b17686a65312fdc2f4311ec4a08f5c5e6634e96cd1a60cd4a3c4e2cd3e883f5cbf0ec67e1ff00d1e7e0f8b72acd5b341a9d75618992894208437cf43e8f46e35ff913144f2fd1a463e0c43ff518867b349a9262d3d9a34ed50f97e2dc6bd31886a9a749e8a7b161bcec43d28da434eada6eac7ab2f0b14a7e0d94bc11abd9047b7988d3ab6ea34fc89969f3684d0965e12c5c3c365297931714ba1be48f7c61082d4d1fcdd8fe56f091098b97c965f857a2626590869f2b789c678ef15ebc2bc7b7837f416663f07e0d3c6f2dc5378d9b8a5453717ca9acaf5c1f1fc3b131b99a51f676466d7884ccfa545e86f108f87b17f46d213c30da421313c1394210dbc297a20bd651084c4c42138c122108344e34bc74946d660de368965a98d3f4294b99984210842105a4841283ec66944e0d544131653cdc2e09ac42109f49b785d2c5e0e885c7f73f82c4214b9489f428d8b9eab8d3c2e2938de0c5e4596c4c78d38a52e75634f29999eb14b9ef1384f13f58d3c6e1f63469e16652c52f268b9a5f15c2f66a7848985947e1d8b50b2d782f1507e1a5e287442c34c8c84c266a342efb2e162e69734a53b1087e35c349a990dc516a3762e11b07a4626cf45e1792c2121f9a1a50c7fd1b05a05f19b0da6d46d46c3f9209ad486868f79bc265f05eb3190dacda6d3690842652c6ad50d3ecbcf56a82d37b34f47fb1ff0006886d20d13ec5490f59ec5cf56afc469ede5a7f87f99a53e3ec7a47a48c62e3f989e47d9b45d14a6e371b8a5210da4676464a6d2323c59c21b5af052e29b8a529b8a5e2fa18b490da6d821220ba19f82ced1a24f7c590847c3fffc400251100020201040301010101010100000000000102111012202130033140134150046061ffda0008010111013f01ff00ce5ff995b6caff001f5612c51469eb6cb14be9a28b2cd4597d15bd3f9af0d1ca2c4acd2311a8d66a35165e2c787e86cd458bdfc9469e878a34ecbcd9649f03f4342447aeb651469284858ab3f3c6a46b359acd4266a2ca28a349a4d06934938f032ecb3c7b28a2be2e58a0cd0694694514692915b2cb2cb1d1289451e3f4515f2d9c168b2cd59e4a669668668341f98a2693492ac691213232f96cb1788d08d08a144e0e3365978bc390e7b93d2c522fbacb2cb2cb2cb2cb2cb2f17b2cb2c932fa109fc3c890d334cba6f6de574a6514514562b3451a4d2696289a4a2b1c1c148a45228a28a349450d0fb1322efbeb08b47e2d1f933f3668348914ca28a6533925dd1950b928a28a669650933494536280e2462c688c5d0e2c8acd14514514515894a8beea3c594b090e3978b2f75668a2b6ce43cae492adf64236cf278eb9cc5d10926521f070c43785b12c6aa3f43f4132fa6522f2a2d91544bdee7e848f0d128928d62c52a212b47b2ab7b17a1b1e6f17bae894b2b922922cb1f478bde2933c91a79f1ca99177879ad8fadf9123f6b2ef2a2d8962baa36d9ffc1226ad0d567c7e4d229d963f62daf7597993a3c9313114461fd2b63f4256ba20f9163fa386a27e371c593f338fa20fc9e4e48aa5b2cbb18f6d159f22fe8f9343f44214b938adb63f47f3a63eb0b12e512f15938e925cb3fe7f3d70c8caf2de2b7feb26c536299ac92d428d118f43f47f07d11f433f9b270d489f85c59a68ff009e4fd1ab28b1e56540ae843c7f312f435c74a65965966a2c704cfc111f1d62cbe972ef9f4c765e6cbd942df5f04ba61d2b09f4af825b22ac92ad90db58a284b1a4499a1891a4a2be396c87a26b6430d0b178b132d1a91685b6fe39662b325ce60f92cb357426290a45965965a2fb6f165927982e0ac4f31f7d15bacb2f6d753de845e5e16c5db79b14b158b2cb2cbc5965e26c588ed9657cf7d72cadafd663f02d9a8b2fb25ef0ba63f3d97d4fde17bc5ed7ef11fb6f7af78e36cbde17c565f45ee795bdacaedbcdfc37d6c85ff812f42174b972591ff01e162cbc5e2cb1c4f42627f5de5bd9451456e6acf42916725f7dedacd145144909090b7bd9450962b65f7ac5efac5965965edd38b1cb92cbca18966fa2859bcdf4de6cbcb6298dbbc7f73a8d62f21177b53bdfffc4003e1000010302040306040406020104030000010002112131101241512022610330327181911340a1b1425272d12333506062c1e1f0820492a2f17390b2ffda0008010000063f02ff00f5ebcce015398f45ced8f2aa863ebb7f6b012aeaf8509f743e2667377d54b4cff6a3b685d614e10301cd4fed438c0e083e26d3fb498ddf0b71768cdc48fed267e92a4e98db1e89be47fb4994d0a72bf1763e7febfa75bfa23d9a32ca77a95cce5cae530bc50bc729d3785d94ff00691781e24cfd28f24f55004041595094ef25d9bbf2d4ff0068cbde1be657c31dab4ba6817be10100a74c1c9d98d1d6fed1ccd743c517f15a602ed06b329a6d98570ca11cd288d9359f98fd1362807f6891772f07b2ccca396522a15c8f55e3fa2f1619f7b7926c6e8f66d9e51cc7fb40b3dbc911aa35cd06e5661717e08fc37381ecbb17014abb46a3d887ba67f98ffc5fd735565656eeafc502333a8d95da7c47fc4ed33440346acce17a154356fd429130a93842ebaaa4c27e501cd708734eab98e948dd657073bb10da3a2dfd3edc37f98936594349fa2f89d99cbf0cd22f5ffbf5407be3301574e038161a344c9e88077675f35130ed8ff64d55f2a12e2634c1e37ec8fee9cfde889eb8538fb6ff002ec09ffbec819506ab2c02342745cd03aff63753657928e002ed7ffc66dec830694c238dabb09fc41cc3ea1797056acdb641cd320ff46babfcf154b604a73a2ef007a5546dc3af0b5edbb5c0a7c785fccd9ebc15b277673d5be5fd0a3fa0f528c181c2c1b364f99ff8e13c0d81226107fe126176ace9ff002bb377e4391de5a7fb471a22ecb9907b4f29123e7edfd08b9d86465b53bab62091e89eff00cceee4318d69e5ce09f216ea9ffc1e53341ff7a283ad0ca7762eb3f97c8e9f555a1b1e170ed1c72e6b2a5bfb03a68165a35bb0552b96319228506ecb2e763697798595fdb3a75c9e15959dab819a39f6ff00bfb6078338ed9a19b13e8a4ffea1be60d3d7dd3dd4cd3f86c8f5aa676e3f1f8bf5717c077fe1fb7f5ff3449fca892af8cbbc2dba83ad53a441db6ee465791aa9f88e1e4554ce0e65c133e478bec5077e2b3bcfe6eaa8ac70b8e2bababababababababababf7f0e546e1338e4d265186cb9c6fd11ef678f27e07fdf8f557522df2161c15a6146afdb0b05a47cd4c12740117be1b3b955cdf6546fbaaaa70dbe4e8617c3ed48cfa1dfb9be1ff2aeae3836f257e31d386061384972bfcbc956afcddb18954720f279ac783754f96afcf65262546cbc215b87b3ac730aed841e23dcc7705ba38714fc8d54ecabf3e21b7527b81dabbf960fba36869840f7e0e8ca95f11a391df43c17543835db1e0b61a42a857ee6eafc12a2954405682a3eeabf79e1f10570aff2ae034579ee33f694ecff00fe939d41945060421dd8ed898cc6830e810fccea9506a172886baa38a8a5666db8685152abdcd4634e3eab996caeb994ff00bf93e774221a079a3d428e3f89daf8346eea1067e63ff7fd27f6bb380ffbf4ef1ac1729bd937c2c030607589c2ab2fe21628b5c208e3cc3d7aa054e35a8537050e0a156c6d853019bc381c6b8e6d7138449f922e3a20f37e386b493b0503b3737ab842ccee7775b62d6fe56a1d9b4c36654f761e44c22e37383099a1d1078320e399b4ed07d55698db1a9596547065ee3750abc3cca74c3a6007047ca6559745d15b821b402e54305ee4f0f687ac7b511676820853a2e8511a779d9b9767a5fef896eea486171a5aaa458d8f102cb8598b72b850f19e0aa81c36e65e480400b222146aac8201740bae13f2126ca8efa2197dd1ebc41fdad19b6a565636070924d02ea517182e441ba6c8eee14270f50b35330b852a146cbc9398eb14e6ec78a9647972b86dc74b2a95d3829eb8ce1d513d6179225044f4c22ea703dfd539b48d21471068124e883bb6398fe5d38fb5fd0537be7796247e1d474422dbe118e668fe20faf16c135f9bd153840715ba91c55c7a6117c2308422ea88a9ef632d569ecaea678c3a8d61d4afe1b44efaf71dafe8298075fb27038436c38c617c286ab998ac47a2cef1397eaa2c140471a23daf65ad5cde305a56537dd554057129b37444e88547730a70a0baeaa30a7c855a1de6bf96d9e8b97023865dfcb1f551dcf6bfa0aecfd7ec8d0c79224e883468bc94715b19c2b7145962870ea8a8d55175c0b9b0d7fd0acae107837385abd107768d871d978ca9f179a043437a053dd75c029e2a77b2540550479e39b086824ec14bbb3701d420fed1b2e36054775daf9267afd916831ba1d9f65ba971eee319d05786309c21fe9d10ac83631c33b2a29cf1e8b7f3ee68a4f0530ea8f97c84ae9b950d12edca9c63755058ddcacac0aa540a2b93e657353c96be6a03aaaae017887bf0f69ff755ff008aff00d43353197d939e6e45388e238254a3d68bb3df28fb7731da094ef82cfe20f52541d3862f38d78aaba70c70ce14ef2a0151aacd66efba8d54bbc46c140af553776f8430ce11c50a848f22b4468143c7a84f870d3ee8fe8fd910eab64351f643bd1e49a02ecff4f761c5ad2edc845dd90876dba6b3ae1be15b68af4e1a0aaaf71ba8c6115e5c17572aeafc45dda7b2cd66ee6ca80cfe6c222551867aaa9f4ef4ca722409e559c7e6928fdfbe3b61d983b715718385270f891cd1eeab85a8a7b231d16577a857a61caaaa31af73381c7a2a7710d0173767f554ecfdce07bfbae8ac9db129c748aa944cda8ab3ea23bc843db0681e18a70d02b70db1998ff688c80159489075520dbea84dd6572aadbb9a6989c0f0c21c5793d111400edf2670fbe12371fed3ff00da92da744d6ea0ca3de34acb3541a1b754ee20e37e0bc396573550cb7ea891470d775cd0aaac5531b636e1f3ee271badcf457a63d7b89eeaf8ca894759400d67d156fc15eead440a0edf18c2986dc1fed5319388a9c28afc165e1f7502caae271b2837c24625471578aff256c230ae95594d5e254ab705b86730ff0078d15959653e03f4c0a955c480af8556eacad85e98595b0ae162b65fcc2a86557e9dc48c678765754e19f91af139daba8173387bad3b83dc1a5630ae338571836c2d0a630dd154530aca985eb8dd412acb647184702aca0e15c27bee984f0cf74c6aaf703cfb9ecff50575d310ae55f0aad5517870bd15f08854506eb58c2938df8254aa700d702a9f252a147787db09d10cbf22d9df82aa70d615d5095acab2d31b5557ed86b86d85559188c2ca98db8a51c4fc91ef9c0687181c474507b82a9c16c2d4575533e6b6c6c3dd5242aad7d95095273616545fbab515d567d8ad3d578d78ae8cdd78c2d30b2b51595954ababd17887ba896f712b6ee2ddcdd5f08c1ca3b885d457b90775d0ae9d31aaa42ae1556fae310a64ab9f5c2ca8a62556de7c17e38cc6144ababe17f91db0bf7743255b184e953c14c671a5b1a70b7c82b4e159f45e226bbe1954b5c56eb2e8ac4ab2d1514e55a85e2ae14512aa5515bba3fd1ce15c6f88c4f4e0a70dfd5023d4c2f1401ba8b8532a1aaca68a1570a0e092150c2a92ae71b2bfcae9f3546af33c6070c8b1af18a2ab56aa0b90f65490853dd564aa0fe837e0aaa7cc9e8519a345d72f845070c8d70b4a8c2ba28e203f2ae5c2945524aa0efe4980a6447ca5bd96d859591a706be8ae702aaaf8f4574754235dd698db0db00a689ec3ab5646787efc30a98f960146dc45fa7dd0a36365fcb1ff00899fd955a70a056c2dc1754e2b2ab68a37d15a3d709406eaab58e8a89b4990b2c419d9657447d53b3fba263eabfe5100a04d654c4038d270b9f7c6d8c02b45d57ef868b45a704d061543a2ab4ab0f35fb29223cc299c399511636a752adc338df0325517c4dafc408c341eaa850aa215221022b5844e6be84add155fbabd175e10668b6467dd5943949713e4a734a2409eaa09e6ff002946a65034bdf559dc7d2554381eabcb75e3fa2f1563e88814ff006bc35b5d544aa0f442106c66337355513d477572ae7bbeab9885a617256be8aca8af754e1ea85298c15595aa2aab2fb7961d712dbaa85aaff780d97d55a2baa81803030fb2ae17c02b913b235af5a4acbbaab4616f4577204c1da57c371a290fa4a86b8aa3251cc4917599c065d148020ebb2ad0ad0744065cabf9af275017864ef74c3308c15d7e5b5c355ac2a8a2a40571ea84109cf3040d9663735e12f9e8ae21691d215151bea5789abf9aba6cb4859c7e1c6f45511e4a8e05560ef084287191bc2e8853dd4555d5fd973457aabaa7a10b9aabf6562bf72b43ea86f752e1ee1663394a86da143818eab413a15575149e6e8ad0172dca6e63e42c8b5c69aa6e5a8f35bfa2fd9524792ca6be68e533e8aa54415e2a4442caeb0364d3d14e9f3394587090ff000aa70815575554a7a705b5564411759783aa73454e6aa932559de76540aa04a142a085f653a28d16abeea5653ae8a03485365b95cb545a7e88729a55124c79ae624b6344035b5d4af157546493062ca41faa8175245519808b1d141365195569ea8d0bcca0decdb2ac5784d550095234d154d7c9189f2efefc16c6b8ed55e2f60a81c7d16cab44f7f683ca11546a8c1beebc979ec8906aad8595949808c47a2b2d24288ae3ba6d606cbc4bc4aae52575552a331ae8898f2855a79ab4994f369944f42b3b01942401eab4cbf559668a33fa2cad0a6423fc401ba4233da13e8a6bea81d77d50327aa80839b132a330256c3a2152637569f4ff009575d0d91928b4183f7551fe94c5509df75379434230be362bc25595958e165a7a957502b8d958ad95f1f0aeab2caa3bd16535aeaa0b620e8ad44e0d9015f38eaa030356b83b7a29594db094647d542d87928a0f2a2f13fea558f99089328e5f168af8502e7903a2afd4a0dbfaa88857b68b5e8b982a0f45f9518d15a4a00c2d108b15555b79a195f5502eb38165cd469aad112f11b2cc5d9566522811748c93aa11089cc7d510806b6baa01c7e8a70f1e610a01aa8824a822c882aa6141a8553387fcaf17b157555556ee6eba6172b65d158ab6112b6e8bc54479be88f340e88f31c2a800b94ffa25090e55572bc42beea0f68150c9f6473191e4b9178957b477a393dc6f955b118361d584e00da8a155ed245e0ab98d954d956005524551d4227aa197d6565a7a146e02302dba399a28b4089b84038c2e5d6e9a72fbaaf6535b2cb60b245059733e20450289244c008e6201b4156a690838199eaa868b3c06eb4aaca5c053d567a983b20f340e5985c551730c79aa367ceaad45d1469bf046703a4abfd30a2b3bd9784f0595978550ad670d55d5951bf451f4512a4bbe8b754699513546a0aaa2d1a621b6c0d1660d69dfa2d3a568b62a1b11aaaaa902aa47ad11895ca0aa808f66c11b9e0a20b9bd16aa5400e448d7d5466aa3e6bc3eb2a08539510157354291247d572f2c5f55bcaff95044940b601e8aaa2c8374fcd2a8f0a3ea8e8a601a5d06167eea0b72bc6c6eb311ef651196756a74bb37928924f9200ba88171959ab1ae65cbd28808aa856e3bababab9c21787e8b4f65fb0572acb4c21cb908f75695b616534f5406f65a05cb7715e238c85e9651a45d0a4d15a7cdc835b493a2e6ed27e8a492df35ca4386e101342a8b283d15cc742ac4f99aa3da1319b4599d6e074098310b987ba0646caaaa429063cd4cb4f905e28fd216a5139479a8cbff00c4fdd6a4f929f86f9fd50b37bb5095ca28a2c762b2ba03b726147c404a99f608d9d22ea843a1660080aaf7792fc50a8089d93aa5509fdd1cc4e61f991e524f92710d9f241c09cdb28b1461c08de57313e70b94ce15700843abc37555755138531baaaa0e18d544e124d14f842a388e92a0b67aa15f65cc5c99b70c9d15a4aa5557c4b654010ad1501c44050865cb1fa567736da293c0e831cd59595eda28688f25727d56d3bad6888148d94e6f7c039ae907d5520bb695107ff6c2e70d31654a0500954a046d5aca83576e8476598eeaac93fe575425be4dcc89cadda72d50404c15cef2e281aca8313a1558aa8805119408bc51723e9b108d5a9d984cd2e9ce6025bf654812a0ccea87452578a477d4e0e5b6ebc4dfb292f6a90ecc17331ca49565cd7e0f23c2efd48ed60a80428c2f75caaa15feaa4b82ca3d152662ea3429b6ca4415d380d1d53f85541f70b2c1936aa032d7cc2f0fd55c0f253982a7b23342a23c9169741f35e2197d9786778d1480f3e68695b2bca249046c8c688c50ae6fba9e8af55aa9d9453326e929ac68316aacb3105189f55cb48badda364334b940333aa2d6f6a3c91cc29be8ab65cbecaca78aaa98dd5b8eaae67c94fc40a86550945c75e101169d511c0469ae165fb2892ba7554155187f8ae4011175d5326f2a0d5c383acd14fba8cb0852f44c100e6747fdaaecda050f42bd47e14d35398ad97353aa0a9ba6f2c6cb2bdc8975479a310552937463f120e72a7ba22842f1df485a9f553984752839a6a54b822200d95397a28cdeca2796f6545cb39550152655f30d902da792b66543ebaa8350a38ea15b1e60b94e1618caaf0db1b2657f105d5076a78e1500560a4ab4704b68750a7fd2937a2d94ebaf0447aa360b609af09aed90db650f0a2a046ea93ec8de7aa2d95afb22e68e6322a886ca80af506ca665dd57337ca4afcbeaa40026fd535cf3e99aa89dfad5488a68b37c30d1e69a728ccdeab3655700da35466bb09461b559f42b4fdd4e131eaaeaeabc74e3a1551ecbc4a6553ea55c4f747b675e61ab96ea5c678238221555154adfcc2a85452a4a8140888b15388aa05c036680a34d7650fbe90ab9b600eaa653444cec803e611f8b21bba1783752cab50910b2cfba92ff006b2ea375cf31f9858a681cd3aecb5845a67d173997ff008a9dbaa91aee999ab97651f88ee8824510b74463d91ae6f25cad8100d50e9b2e9b2b0a22a667d10ad3bfe9c31dc5782663298c2b8cf15709e3ce2fae17575ca3ea81ed7b42eca8ed1452a8abaad3a2de547687313fe69d99a4cd955a23ea9b95d6ad558542a0af45b7dd49d11ba1303aa2409f5c25b08b88920597d611a1a68b31b7f904eb10a4b539a098eaa28b4ae888690d2a3eca221514fc85b869c1e4a9c5cdbd68bc56d9786079e300514f1df8c469528e5f092aaa825549928b4596524c9375339b59014cd7ecafec85f78521b4551234d510fed5a3a4acd24854537254ea8667574443cfff00142b656a225a30b2d51cac92a223a615a9402a046345afaa95115d0ecbc301646d9792a9f95af702a70ed0bf47290dcab4551eca55f1a2ae3e25433c06b8f2900ba9508973c004e8a249429ae101788093ba66645c535c06b542ce6b4fa20448aaf04a82d22b44d9ed119ed25bee8c4caf0f4a20a0abe355b705d570d21502b2aab20dd292988c591f9eb27f2cd251d823b2bd02eaa1d24aa4faaa235a63cbdd37b4b9eaac6116ba26846cbaf4570dd973768e77fa45a7550a01d11e814e754cd28032b98fb2906e14abe34e3bd11af0514611a271fcc6899fa8a07d147afcf53de5399986571d35a286b27aab754490eff18a843b9a7705bb1ff6a5a8d9456428b220cda677c3fc45d7256428cd45966985f81de5dd5b81c740a77050fa2f4c2166dbfe538754edbe544ad08ee282e98c88c8dab89dd57c22e9d4be00707235c428c8eada8bf08deaa997dd7898a7e28f655ed07b2f1fd140718df2aa41f55349da551a535b15cc29eaa854e683baa86b96a0744ee5b211472ccdf014e1dd57bb97d82a010875aa85e4a119c0844c68bd5153f33194ce945fcb2aaf6fa551edbb5f169d174bc932556d892e12ed04af0b89d911910018d8d3cd0a2b70799c034010ebca3f65755575130237552e61f25c9dae71d442875950aa1235a2982ab0586f1759fb3323eca0a88ee6cb65751181df1ae11eddc06fe6a2398e8842af7740bc0ef65463bd97847baab9ad0ab6dd50ba5788cf452f93b68a3e183fe5aaa34b5496cfeaaaf0345340b2c08503446bf5427c2a4fff0069bfc4d745c932ba6aa4ab2228735d5200f25a7a5308e391450534349aafe611d04140555258468512006ef0844389433b72f5551247d7aabfa2ba92446f9578bdd17437d506bb24834160bf92d2015ccc746e4a91da360da5005b2aac855a612159555b1a7baae351a60d53c4c3b397aa94141d30f1fd1439feca6ae1e6bf11f5469f55e16fb2f08206ed56a2cad803c94ffa56c74f75477a288247e9c68bf6c649a6d87554598df72afe889135c3ae1538157c2f81eb85312fb3acb336166cadf89e4880b3b9bee108348a85c84759d54ec8cfb1d14830856765e4b2bb554badfcc23a1eaa3336de0a7d9526572f6523520a1411e4a44643d57239c4f9297766efbab02b457575453384a837354174e31365288e0b0c37c2cacbaafdf09e3b5d75e2b2ac479a89a617c2550601442af0d4e3184cc2ca1dca6012b217e71975d14e5a2874e5dad09c333dd35bd91e4e5d42ca5820eca9726926de4a2575f2462149354394968281159d9074885ce0c7450c35b239ce4da50706b4836128879f86df2a2863801beebc5354e3a47e6ba74766e9e8573b63822101c54c481aa1165edf64d4786fdc8c34f6e30adc11c71f4555450574c6f855c8f38957fa2c9a6c9d55ccea943e18f5402155710b3563641d93aa170ebc6a883d83b2efb2398d11e5f5b29148a2e5b7d90ea7659042a8a273abe8b351cdfb286974a8cc6811024b62e28839c32c59aa141b7dd7f13b3ffdb447e1bcd3f0b9ab2fc3429eaa6549af70306a13c14e3ae16e08b2a71d3809127197705c4aab8631055950732babe3cc8b9f551196775d502220d5524941b5e9a223e1f9c1418f96d44ce8880682a081741d032fe659876b9cbb426fe48b4012dad51e76e7d8044b7b2f743f0f4b29f8dffc57858ff552fec5d97421d2a44f9a9ccc11f443b4cfe4516d91d5d70e22c14bad750d892bf8a7346b284fda50cd0236a2e50f13a86d57380e65ea86421840fc4fd14103d15d47c9dfbdb2b0c6ae0bc615e5752a80ab2801b81e65554b28a705f8297426c85426d2a8bbb490c6eaa8ebc1692508a1d72a1cb5474cb58d4d1676bdbff914e666969b9d172d85936ce83a84f39aafd653747115c0ee810aaa85483f559a39b78aabca94c75241b0d5469f9534436eb3b585dd6e89159531cbb5965883a002c806b4648f351f1050cd1788f5d94bfb32ef2b85421477bbe361c17c6eaf86aad556540aebc47d141713eaa269d4a3aaf128fba3844fbf0155416ca9842add5942f88072e046a158cad97c390d681b286439bf9822e3a5911aa7cc6c8c335593a8a05caf39f50b3648eb2a35bd166cc3303ffd2d77aa194d94020d6ab7d9596d09c279a5568a36591d14fb2cd2e3fe4154f4aa8854e6aa7119c6a365322d5216906b459a40d8af874718d28bc55d642ca4cf428f2380e8a267d6aa5bf5a2b2af7b6f7c2ebc5c62d81c06145555c28baa9455d555a9ba9142ba2b00af45cb73412b23c689db68845555441ca541208de7451d9b829c8ef64065316b5d01491a84d25b58bec8ba6dbadb31dd3ea4f45cdcdbfdd48765bfaa97e972166d7506e50dcec2543408899598df5a597254dd72827a934526b1b0b2900dfcd1368461ae1d519467e82eb3b8730d023774c5143049d4f45fc2a7ad0ae6ca5d68532bc4227559b3f941baca8c96a9e68ea11137a2bf2ae6a04e0eafe9d11f8ad79eaa81cdeb04a003c49e8a08e2ffc4002a1001000202010303040203010100000000010011213141516171108191a1b1d1f020c130e1f15040ffda0008010000013f213ffa6a54a95ffd952bd15fcebd6bff0094ff00eebffdc3ff00babff70803ff00a75ff902c3d0b97ff9b5e952a54a952bff0006fd484525ff008ae5c1967f8997e8bffd2afe6cb972e5fa2fd05eb052ff009d4ccb967f86e5c66612ff00f4ebf8b0fadca95ea4592ff96a5fa57f099f4bf5afe030ff00cbaff354a654a9c4b97fc179c24926b28cc7a54a999e1e9a4b3f8d7f0155fc2c00dfa5f94c727930f68ce575f7fc2a57fe33e952a57f128951f5599f4a6577f4bf40c160b087a17e9432b3ce53fe1b815a6f3da568c97acaed5312eb1f58d4a14d95a7781975cf4954e1ff00057fe1dfad4a65cb97e952bd4a952a57f11fe1cfe0bf52ff0085cbf5ea1bcc701c70be970299ea4a46d9744d9de19867960655f37b97d66691d4ccbbff00c1af57d2bd17fe335f4de58e664f41164c4a3d0ff2b2abd020fa00215eb5e8a6665b0f42cf4bf435b1be11802eae6159ef116610ba22cb9c2ccdd796bcf47f8dcb972fd172e5ff009ea54a95e952a544952bf918f5b9b8fa19cf39e52feb54a3d09fcc1999845bf8292fd2bf9070325f12998e6764867b4c6c28d6632c90330843910f1bfea5cbf4b972ff008d4aff00057f015fc054a95fc6fd6e5cbfe033333de1eb52a57f3a944a257a54c7a543c7f2a952bf9629fb626d202fde1164aac77b08a95983128f6a9457a4a5ff0082a57a54af454a952a57adff008ae5cb667d6e2c597e904a4d25987f1a3fc752a54afe39952bfc2d38dbbe26cea399d71e211cc684165d60a5c9d54428eabf94b99f5afe35fe5b972fd2e5cb97fc05a5fa5c58fa3e8453994f0b2ad49ffce7f8ee313083faf0c125b4f718376df6d406ed798405a62301d6636cf128fc8ccaef6daf34fa67d6bd4afe572c972e5fa5fa5cb97eb72fd2ff00c4ff00063e87f3b972e5cbfe17eb7fc7ae5cbff1003204907dbfe9f10646144ac5d3be7111925ca526f3e25cdd8ed2f60bbd47b6db795c196bfb207d5854b9997e8bfe372ff857f1af5c7f0f7ff2b1f563e972e5cb972e5ff0172fd4bf4dbf8dcb972e5fa969696eb05d666560de086721aec2f4b9b9dfee8d1b98d9ccab2bc189630be5105cc88c6aa730cf5e0aafbe7d4b4a80e89ed30e25253d16977ffdcca8cafe17e973ca5e5e0e5a5a5b2d2d2dfc0f97a2b292e5cb99f5d76f529293ca5ee5c17a4e9da6636ab1b1f78d6402aa3427fa6029a59e5cc745604e1a8264a3ac72c21e18ebd940c1adaf66ff00a8b51809daa18cbf49796ef2dd65af3ff8ac6313d0be862d2c98f401d657a7bcccb9696cb4bcb4bef02f996799df87525a53d254a94fa2aa733da284bc173263b5a80b0adeabff0071ab3d84e1f2758e8c4d3069c8e91a5f36dfdc4b976fb5457df12e2f63f0435c9815d7ef795c3678b3a3cffe53e8c65e5d96f45cbede952980f5999717e867d29da76a78a76a50e92e29292ceb2ceb099e9286ec9d09e13bc837fb9ccab1ef0a42ef30d8105e258db7784eec57c5a9da67ee6154b5ac42ae1f0461d8fac6c164b90ebe7b456ccb3482feb5cfdfff0029f448ff000d7f4784a9508a1b497d7166fa9853b63c4529c3984dfa23d025fb7c4b76f896973d8f5d733bc96bbfe2c1c08d16affa8be7d4da00ebefaed039cd1b1e13fe44b6620fb7f8f69c8070477bc630b8d2d1bf2b28fb4b94c7298ce3d607f4e594b5de2ee62fa7efb15a81634ce2f9faff00e52463e8233bc9da7e2538265c42dcb293dc62097da54a952a164c15e875bd2a54aff0a9280daf10d21e55a4c4a7a4530bbf684575bf082aa28310c53afb44c4967132dc18c4e6e908f023eea2a84fd520d873f684425f6635f7b8b02f76dff7edff00875fcd22426e12bd152a54a952a54a952a54a952bd2bf854a95e952d4bdbac11aa3b52cc26f31365f12fb6ef95608aca9f0ffc427fb5e083cd8c6e8c0e3d90577a829ccd6a617159153de00dd0be235767984681aa7492d2e402bf94c1aec1fb9ff6149664ebff00d7871173808563376ff1a95e952a62f5e9539ff257a54a95e95fcaa55a6ca8b45890cb144bf371d9bb4b8f102f11d4d03eb058e05668094fb92d2caefc4a42ee3f08d9a9a457a6c3064780faac547afd1d7d2512b7719a176ed9ee3f10a86509ff00db5eb4cbb89e5003573de64d623d718bff00b0e0be2076410f7e634572b1ec45accd1628d79ff5f785dd2d97cbf625fee3e67293977980dea66ed28dbe11787105d779a1e26af110ec67b7eb519e093146fe9fd4c2ce660dea7518860325b25c9b53ef37f5fbff00f7af741b8aa989710b99c4f3183ee940f106e1ff00cd4ca7d2978978485dbd54b282dbd27717bb30bdc60f6f99562afbdedfb08a65daceb48ac999033ea3a1cccc3417387bf484c5b03f7de2b3e127b7fa476b95b266f9faa9f12da17ba086df3170caace571d1a35c9e3f7825f63ff891ef2c39f4d8cc759c429e65c519e11f9f696bcfa63a855c7da0e5141a7d58e37fceff00f8b9f466a808a2b072f012fb5fc8416b029cef9835a8f7e0a9971e78bc915a294c74b0fea694c25434a5dda185309d257e6717d23ceaf45da57b9b95a2add51abc5defe99713a313ba1b5e8efd2ccbda9f32a428a93c571056d2ebde351012ee9ed317b154babbb7e46e000a2da65cf12787a0ed8da5fa2e5beb72e5be97fc6fbfaacd6a5f4971cafd184d629db292b00306625a6bc62592ceb292b292b2beb5607f87f1f5fc25656525652b5fc09dca792afbb2d47da5fbe604dfc514aa3cc55b6d9b389918162fa4f229b96783b60a014122861f46e610c28d539ce3ce7ee96539b2fe67b4b9ab9a1a8e44e85915eabbbed1ef8e2c06f542896e333555a6f35ff65afc3bfbce94354e8c3aeb87de2a8a662aa8a366e56c4c065397ebe3e38972ff00c37ffc4fa32f12ff0082cbcbfa5daf40f40a65a58ebe853299999999999fe77280202cd5bde52bb3c5cc75a31e23bbc2baf3dbcb102052d5c07482d5734fd8fa459978be62fd61770cf517231f40c2aa70bc5f89aca0518b18e95d0f83a44ba89dae565030e31fbf48ac302cb8393e519b21bccb83b8dba351623761b197cd0301a3f59f7ffe72b332d970fbfa0b8868a7c41308779df977e6f448dcb9dc97fc442b95cafd0148b231d651d663acc4f89895e25773e663f59facff0010bd369a2ae58554f29044bcb15760ccb8231698761bfdcfcc5654969d0e0f32cf72b3a035300cc6789a5c6e5dc5c4fba3f48713ed30b4d8788ba28d12c9d90c250748b9106d3943c71f9d7c7f2af45885494e5344c7781df106c03d432a54a952a54c468db52c8b2fd2816588e6944a070dce2e3a7118262b3549ce635c93c18eb6fda29e977863229eaa36d5df9583fc52fe9023c85b0877277277bd0b4b42e532999eb2fd2fbff0169696eb2d972e5cb11c1ab59dc126ef6206c9783fda2473f5ca2e452fa3de37cee137ed331a9a50b331c31d128173253ef29bcb026e1389a331ebc4db6ee0449295b95eb2b1db5ee1a4ef2c2b25ebeff7e7fa9ef4d279504ed16acb5e2e2ea402dda77ba96de27b45ed9201c88c4627967fda889772ec17535a978ac8eea970f6d758dabd3006e3606ae0cbfa45caf314d0b731fa12d84b968a1818ec9b6998bc525ef73b8e255af10de6d735d250eaf6998799efe879972e0c3d0c4c4c4c4c4c4c4b26263d55a506e00d6471156665e19d29d5331127787de316aba940624d199967d178b873e8ea710dcb3de75905ac178beec71845896873c6db21ff0014af208ec394a4a80690b4f51c7d2a0ee5db3295dc4af107a6e5cf88e3c7a5371f04e950c6e041b4256f3338c4d759c20ec6744a0ba41e66454002f697733b3d2a7130388ae59c9fe38f5bf425cb972e5cb972e5cb97e83101ead377b8d1ac008afd0f78c65733a1dc66201587c4eb846e3d2338884d7ca5df3897c1e8470439ccb06259ae25b932ba835a807729732a8b4ba650731530f793e4d7d165b32cc7010c65731b4cf09dc9599c2196b5de6599058df9850625dcb751c1c4af45cb1c331b94ce236c373c330da0d276a859552f4931a6788f846bae6508b716b239997bcbdaebcc4039cff12e7bcf79effc2fd31ea592fd16cb60794daf3a95a68aa0957cc4789e48f4cbf58e63064a13937e876b980e94d14631fd454ea996353323d22c7539f9958fe0054afd635c4088f58faeff00447cc54e5ed431d2fc7a041ea81b40d4936ed8c2bf73edf6609bcce0b4f69b45bed2bd4f319675730ba5ba4735576f446dda0c5c30d1ddc1086146e2e62cded25a729665f64cbccb6d1eb15ef06485033db102230657ace2a9ac438e02dc2282d74e128dcceabf425298137897739885e4494a151a95923768f921327e2a5cb972fbcb84f7ff000877fe054e89ea8c974acbf5a662ce2a54cfab7b64e7fd3f7bc3b81d30ec45cf9a9ec11587a4d712a3f69506d3717d34778b4352e52d4733de14772ad792e06157fab3e2372f05239120ea178fa9fbd483506769550158365e9ed06a37bcee6fa72be3cc3569e3133b590a87329402d36906e32f3971304f18facba4f41602ae3cc602e2eaebacc24aa737d269ef2ef5a8e62f3d21980747ccb1d37030d18af78d55c779734b73965b98a0d44ce7de361b2732dc673362289c9d92ee116e6351bf40c4a7efde2756fb4a0a6bbc5103d4842794c42a512a54af5af4bd05b4759a6575a7d232bde261455a864e9c47a099769f57a96a29ccc3feb00a060d12a3de73a867ef0d4d8b1f377f565cecbc6e2e3a47d13338862e0d9e97430ef2a4c5ab63216119e58d7bd8195de7bd67fa8c602af4a878d19ba4fe2270552414858c909b485b30271925d8f0bd201061e91a72b858e2c83b5ffb99c0c3375a3fbf68f02f64d29d4ebd25dc557117b55de53bf84a2d53126e19b584417c1e96bb554ae2be5530a8a47115cc21a2e6f033696b9626a08639a218657be66d173163d25d8293bc47329284741857787a5c3d065fa1e9984a95e970785351312c56664ed34dc1fc168cf416cee3a2011f30fa460f8f5c9c559eebfe88e0f913abdfe91abe2c2e471f69776bdcb8a34c337e63d26d854a8756ed8bed1c2cb6c537502a459a5b862a242cef059bcfa015e075d3114854348f1e83de18643380cccb898b44c6bb4b3332659e61f7f32e9f104c1720bc4c9df188f6fb40e555cc1e9a9810499e999633798a4cda660dc566f68e8fc4bc53ccb2a0a8ad835a08d5d36c3269d928a3188ad0987494d84ef05bcc5e34759ddf98eeb7d885b78cec8e7b3e99f42a10af43d2bf9543b3ab510677cb32c837b0e92f58dc7004f32e6226c8b3983f2f68db23b9331e97e9d23bfe8f13ab18cdfcc0294791da63d84573b6a297358a5dce484a9572347a04d20991a98d969b538c2a66b4a3a4a618bf285d455e78850f32cfe91cca95de01d606370a3ccb22e099047d9fdcc7566ccc41b43da6ae9f69a977de02fdf99cdb02168a0f2c5b805145fb4a94d39253784ed1c73730ddcc799c46b90744e2086e1be66b9acca00c236ec6c811e473da6bab3479664576b019b65cab9d47998a10e346b7390e7896212da10af43de54196ccccfa5cb88da816b03b67e1f79792eb3028b55660ba8a37e8ccf3065af92f83fafdd42603e0f4f97a2a12602d945ba5feae65a42cb58b9c88b5d259e8d87b71283b92967663d6313539870e22e182a62dae61569d743e97eb2ffe0170c779e667a8852a1518864fba6981af137a0d08fa54bad5c2db03bc0d1cce35d9e8c54e06cb6fb9f49d980258c33079a3f12aebccc031b8b777a890a3b2e195676262d016989e90dcad8c54569e10691389761d1cc5669176ef192d892a8ef28dd3ed543e419ea52ae2e70b8c626b00d08018cb552803249f52665ecebb2229e911102e556feb087b7a92e5e25fa0cc747e621bc4f3005f669f94aaf2751577860dd7372b89a8c09740e62821e41a3dfaff0033cbdfd98695cc4af68b2e9d225d1d4c3b972d1e250997899b085b4cbd99db32e90a67994e90620fd7fd94cb05e999918e966d64fbdca218acf74c0a3880a0df594465c6a1d25bde1d724fee54c25a02f3335ee520be0670b5651d890e6e5f2699e10f8567bc1831bbab1709bd22b234a79a9b27b2fa02cc39806fef12bc54be917a08965945198e20b77b46d7bc7cc56f1de64eb19ccb70360d6601256c0185f19883ae62733a5102c5d6a1dbf49aef67919eef88575f520fa5c12f501983a26572211561f49512c6c18afa059a97956b99ad3e872bc8194f131408a5b6bde59d494ea4a759ef95e8ca749e31effd2a5286699f28d5c26a2408845d47afa23938252bd3cc284422bcdcf226b52272557884dc0987dc18f3f9f17e388a1c794d057422ac5506f2fa4eff00420cb4656a2a1d111bc4d06baa7e3d0097518cf328665549e9c312ded18a997a621b3e12d713c430d7504c21d0dafbcc59ce832ed67888ba402a3d13397e9039bab95eb12866f04374dc572732da6b3d7f7a4671b371cde5478b5cb1bdc8b91f540bcbf13a12c8f175177d63b59a99e909c4cfa1995083346e34c574030e6be03ed097846e89e1acbbcc1c9bf42bb45a74caff005800530182b8f4e6542e1e99f4eaff00e13e3bf72502ef4e91fc136fc4413c7df2b3a0cfbc25a98251d324717ccb081ae25ad44118a6358d9d26e86a38241a2db172b9e5d95c31c2eb5f598dbc5a0d16ba7a457cc9980f2dc54bd70f9a3696ed825a44af6970cc68fc1da2fca58caf50bb9de861a86103b43b7b5df88d002628c7c453e171e49a9bc6260338ba9559866746623393bc6c043656b7c4a7d93a8c854e9e7fb968839626074dd46ce59b47e2386c90190e66ae38c1832f13dbd065fa2e690f43acc2e0ed14dc764a7894ef298e9c33cceceacb666d6e56a5a7660e035ae61800c1802612fd07adfccb97e971cc55e4933ed7f64565d1a46cfdb82082e9fee59cc5958ba456d9843d273f3e9b45c87561af2619c9d38f1e94d8e99536c82f688c31d473326b10a5219eb15793a8b04ab23cadc6031586c39f0fc473612f03c9e7f32b3b8b440eacb3463732c31f744e2b247ae93ca590b5c397fa967395de267acc18e1a9ddb8ef33ed2d715b2df68a82a8862b2c0b4af33b4116299540e57d21577e98e8844d89f4352b065dacee0accbaf8975ccbb85757d3de62e73049de0d412ac3dc323a873456c979651303a9d238a5918961c8e7e260b4e5e57bccb80f9ccbbb4f51cb1e341d88ca583f3128aeaf47fbb94c11a48eec31995e2389612fd13ec1f6418765fd4a51b1f00fda37200f09c8d4ccef07aae47ca0e2e2dccbc90de9cfa0da75974fb58e8b50cc2edfbdfea2b1b5f6901a8e6bcc1454b789d1796557685dfe92b17c92f806d9a086a9d315aca3941f32c904761e26dcebd1ec47399d7d307de8ac4dc2cd93aef32f594a0d402f31d0c67ac79026051b85f8219d590c47ee6593dd2dcccac08b1b8d6de3a1d60d95aa6b3303c511b2a940a6545ee7d669707cc4bc38483da0fa55730f32ae554f689ebca170e97c38962a5e0fb046b42dcce6d140e0980fd4b8f33980dc1c97e90fa2f9a7f7311173ef2c87dbcceb39c30dba977e53a10cadc4c00dba420a8cfad9312b0cea5ae0d7725bf3385f64cbca7eb15b6c41ec7f72b158302b5373ae658bd56d39779cc65732f63e9cccd5d610b821d7b56b28a354fb4be3a42b6ee2a2df8838d8bc9c4c70b960e214e829945a923a97c44111a2afcc2c7be8b5f84b20c397b423a1306a874c400c63b46e2db221a9b1e6343b1eb32d338aab8a76844dd8a05b9fc4340a3bca9c66756539e90011b0f4968df103bcbac2c94887825df731d58f78c066c98235b66282e90cb6e28399fb7a2538fa628d0fb44f89470fa0b876dc6c520e3abcc06b206340f1138ba6511f4ffa94383f1f595309dc2a3cdc9d182245d021c401ecb8eb330ddfbcbe90025768b885fb4b51339777344b78a6643950fa905664b3dc81a7c3daafc4b180ade5081ac626cbeb07304771b41f4671e8ce6155129036adea3792e630c46cfcad4a32ac4d18cbc4ee6b11306d810a7337338ae8dc2d7895d94450bf88a748a78f8947a315f1e5de196b6e91b1da3aec7556e308abadc3f895a9f26e3674569833d3bc68452f3f6238c3a40ffb4d8a06515d444b12ca3aca0dc659755f78b582141e6556b5305a806ccc1b6d7cc741c422c64e939c2e1089393e972ff86e706bb5370a3ec5bef30055d6cfa418bec74820ae0a1eb09c1a97b98b2a2298e6a368ac4e0dcb863cc0c7499f898e65b94c0c657321810ee2ac2d128e0b50b4da15f0b80cadb2ebc103ab3af35a8ac5f45f5f43986152fd2f1e9799bf7b21aeea388036810f6ac4c56605400ef3234dd74f42d6c81155052eb32f2e0ed2cb5e9ccc29956e9f4b9975ae65706ba420661b3880501de2beb1894c6298ff00b1c085d0fe9dff007b4a62d5d3c8cc307a55ca36cf6c4c260f2b831a55ef2be5101776d4be2a36c173367e90d4ae658ad12b8a11cbcbda755196d3a66200df79d08988319b71b8e1f128d9331e972fd388ed5ba427d4883e65f79c3160976a729a6e2c62ee7694c5c1559d3bf48f30d9c4a387de56b3a9a9a0316ccab59ed3177c930bae7116b9952a80d87d22d73068ece605ced5ab211f2ca74ccdef38cf494260f79bf7997716733660a6e54ab952a556e2cf731fe4e35d62c0bc4e9062b00c11cb197ab3ae7450f9955de60bb85f16bc2ca393111a35100178ef1ad74ef0ab05636c43bf78f56d830a9698a9b8decac333ec5c70fcc3be385d79436003c66245b5f42342e20ef056d15ef0673d388e78f8882157da2469d5ed2918f7c4b383cca05e2fcc52a5b94eba8296dd373345609938c21f31eed9357486779ae652d3a31e0e4662d3502f24b3acec3e6689f326c6bd04cb3680d5e129ad54355b8a859314ee4b77e9744b797105f8469c660f294af9b82f99789b41adb3ae662bafe252eb7cc74e65853cb332a567ef3890c3a443a17750a8ae7b41202e60ad1dfbce56b730e6551b6932cfa0bb3519c66625f6f4e37e90bd4533a60475753b5fd778e582387332507bc0953e65e2ed5e25ac73d2739cbc457458f5639321d2894e2bef8890bbea6e581c398c96acd5d3f497ff005412ad0e811b787b307268372db5c5e2e26e2c9d26d3ea8075dcad315cd2c19279fdef121ba77e670082f844ae2ecb817b02ce0b925c765437a1753652baa6f86e11262b65b0f256a0b61de233f0967c915e1c41e1a9ad7de6936be6609627c229519ba20c259791de1826ea0b823ccfc41de35a85fcc7aa1d5b9605219d350d4c957385e3a4e88abea945699f8990f5a9c0d9ccbcb52b05feb862976835417bf8a9773b5eb2a2f92465de1b087a11b5cb4ac8e61a66eba91c260e327ebdf8954be7a409949c0708f5cf30b7fd4ba0658a1663f145b32df79c567e2791ef0bd11338634f1ae8c335d350396dd097f8a2bb5d74238669e712c0e4990e03ace437ae202b0aa51869ef12b1a7bc4c8158cc6a55d7894c6cf3d6129a5d658d22f42a194f225ad93df945443510a962f771d966e566f31c57ac309cc1081d9650b622ea84e2185d1dc6391cc1235ba8598eb35be88037b4e7a207297daa71d20d4ecac176f344ba8607398982a195bd7686898bb8baeb03accee744ea270c4f962baea4aad31da767b4e78971cf7943c20c73b9e2b6fdbe26cdd5d3f74f386bc9313e8802d53c47d1c43813a62662660bf41946d8999e4f027bfb545314c4b0e2bc4f0f78682963b47e904a4daab054c580b5d2e70ce7b33792352afc1011dc55152c0ae86624d3e4e095923b74c109364799941beb7285aef735e253fba5b7425088de22e7315dd91a6559553db9974a1df246a68710e2cc3bcdc1c75a64d9894b06eea5392b707435c45d2b78b840731cb1eeb8db20ebc73d6016a32a2aa6bede87136621215cc696353c1155d9c4579352cd43e5959dfa5e33b9cdfc236dde71ee88a139e67cfa3bc45829352deb99de6054c18b2b3376599316e6aad13cc05f6884d12e7b44f100413ce2448595af695a4a624bdee0eac023be205c1ff494ff00883467b19a2b8e6e5bd2e622eb30ea198c969ff25f774cca3a0743f2c2cac2e59a6ecab58f7872ca998ac29f19602a169cd41856dda555937cdb13cc399452d43672d06b1094bd8d4c76c2cae3c4e32af789846f3ef1cb51bf78f24cd87c32f62af681170cec753467538ea6619175324e4886f4f78d33d6625fb47061cdcf69a8ef1294c37b9cc3300b506986ed9ce274a95a4b0e59ed06fee430a39ef1dfa0dbacbf13e53cb73516fcc75014f335f17d0bd55b84cd9c6658b9279ca9af40af4b9d47198eccf3e6556a784cb896c0bcb00dcb788f6314bf98f43d2d229a2541a53b8750beb169d9ed03a96f48634bdf31c056fa4db2bbec3f132228ece7ed2834b6899215289c7cc0034db61a8dde5487314ec7799d32e0b81cd5df48f73c882d20e773940bd188394bd3a4513005e5b7e92f4c10eaf754a5dae0ab825e6518cfcceb0aae932ab951b33287510752f3489b18803b92ac4c61804e1342b18953ed09cfa6612ba102bde5435e80dd4c19c40c9d65e43a4e61370e528adca5352b313a42e730d3e20678e66234a46c7c3c45bdcda67090b9a4c134d43398855a1cb98b420de985131131f881ee94cb4b99f05c4510556e62d501bc6cc41a172b6d91ec4e57ec4c9a79398d5ef7cffd6366bb8c250da3ac5f2865c1e5dfcc10b7d8729bc3cccb060bdc94e5a51fa6648b1dd9ff00408814bf60c4e3b59f599002df189c55ac61980942dde23071e92bd1d7508cb399c724deff00c4da12e84cc176530750d7232cb0b517b8bac18ed98bce44b72438c9616d9f44c0ac7c6a3f23ac2bc7bae35c72f84a605ee37fdce3d38959952a1b7889ea4a7dc8d7a898cce257312c832955a8779598db227a6e64db895d60dd18cd66e09cd2c687e6533986a1356d8ad8388bcb71b70661860cf88675be2199e37dd976feedc0372b2a8db11e663b9caa69b8c55e20812abf11b4a0762712eba3ed4bd27d2659650d199ee0c23851dab362abce712d5d62fbccc12d6e162a0c6229501ad46972bd86a6cf2890dced70df671594e572c52857db10dbe100142fcb1e828eae812d6f7ce23d870f0ea5155919417cc5bcb962d7597f3310bd11b5b95521d1710cba353b9c45b6b730d5eb0458ca7acb7e232f11c40952a543136cab9e215e8623bb20dabc3acdb2f32b7567a5406a285fe26c95c4d32f884c75805ed8600aa5940f08111dd21f53ac1e8e7a417dc99dd347efc4b119bc4ca15a9bec401848f19adcfaccea6a6b98b99706cc905991d26720826dae998239651a3e650332c95d6bf10ccb615b88bd78b6aa1934072f73967ddc7b4c0075bc4c44d3fd437ec10acafba16c9af09ef0c74948b17f330d29e658c33f328810f2d44b73b14425df171028ce6f734e98eb2e338f5d4bd640ef12a8350cc197880b4bf483a4d3de563b4f11c4f11be66daa9f2cca0d4a2e759dbd0cc545f555ea056f12bacd6bd03acc71025157b88d097ade25bb79955cc23b86bd39890957a974779af683771b6ddce70c286ac9533a89f1feb0ac5f88aac066de6277ca2315b8b087594b63dbed0aae93bcb3261312865754b2d7a4605fb4102ba1b3b4cd627230400b2431a134419042a694fd658b5e0261604c97bef3b2ae6642a8ba5d44352f3e2a0aed67b4eb2bef00e0263d53915ed01dde599dca682c81acb01d96f995ec3c32c617de56d94e634dd7a3ba3aef399589bd158fac633983f5f548ea55e562af137b28986ee0c339d40dd4b2cb5609d012b886ebd182394974d5cb837a98c7795d3e253182d7da32fbcd10557cfa65b62d1a38dc3caab0fc106cb0065f12e7111cbaf46a2918cdb1e841c77e66ced36c392690e9748a5de60d4a6edcb789634ee091c2a58c881abd4ef8321141c6b312729c3b4ce003b1cafb4da015b1fd4fc8135e933fe2af43019d353c476ef1c254acc4f55562a758ea547e91cfb31398efd37b96670ed3266a01e27504088e11ecc4b79f42eb6ca96c53799fe930b9d712b33cb1e82ccddcccaa6615295c4ae1253afb4639c42b997da5c57756cb783f496766c994835030ab17ab2b646e726e60708b4894e550d4db46222e21da7129ed1082584b2132cdbc31574d6a34060d35b985a0faed866d9e4bc402803b1fe7ac2ea2cbbdf9789818463db1ce649919b328dfa5b8251349c53aeb1101511ccc6631632f3fdc045e6f2259606cea152f57d92aa2c5c3419075896e6ebacaf30bd86f7130e9d6319cbd425aba51d75815873c43136821c772e0083d9962d6698621eeb9a33a8435764000cf25177beabb9e65ca5c06f9964bb3ed29c7e258a7fb4dab820cf0beb105bea9a76537f1fdc73685cf775619b7732f45caf18b82b5a9dc11a4ba5b370691a6a58aabd1862938952f660087d2b55d519458d251af3c3003597a09f370d2afdd35f560077e92ee3c0c2daa7cc13d3b129e97e6a6195af620a5d3500ad66aa19143de6d579afe230ba4d12df2fda8d8299fa90616efd233519ec914a42b6f0456cf651302d81e1e213b3373fad4b0d718b97e3661bbadcb2f3895dd2afc917940cb2e9b5454d94735b8f1dd64e1de630586f302f9ce26abbcb77a1b025f3bc45a10afaca1441d6e60ddbf33ab47785951f3985daa9a4a7b4d30b33ab208ad8ed31b18071ee26197519319f6c4c0680f562e4c53c40b55f027718e7b3da532d2d3b462280b926116b357755343ec9b137dd0264893b017f55662097702a38e820468cf680290af13a227886456f1ba8e36cff942a6a31e662f42e54baf07a759c452d1b89d1f304d04ed10a419d1c7c265bc3283d66cddc32478d1d75965a5170b44b4c5c37403de2cfd086a14683b0acc69e65a2777f12cb064301929a3d2674987364aa6547522a565b6a51d1b413d466b690be889a6f0ccf42d86d89aaae2e230a057008dba17e7fb84c43b5dd41b88e457e21d10acbb8fd68f67de3cd80b68a9f7edccbd4bce53432e851b63e5fd4bf72eb15554a2a8b319c708e1bfcc35dd36629329b5865abe41da1b58a628dfc234b6751b748edc6711270d1c352ed4daec0bfea29b42ff002a522c66050fb7a57a12dd65fa5b04733481ef2d32def3b8fcccccede9cfa6bd29eb3c819805bd8f58802e53c6e21a0f3a94980f262beb1f59452eae688a45a6335bf8833555d34ea06d6fa0b965a469a8d337518b0fc47310c0b4c14b531031717b3bb2bd8109bd46689c80aeb2a49f3148f17095b82d9d6df58a4e4813a4647032e626a65cb1a580a7350b2cb66f17500af09d1fbde3c94bd7b4eb30b1c0ea617bcb956f100d6830a7d7eb1b0d8acdb3a74d6239532f3cc3a2ce10886796bf09402f4bd525af2310caa8c540c876951579ef895a629d3243f28d5217d00d027346bdee28abc79986eaba0648298674311aa1b93d40009970d1f263fd441e13a9ccee0668fdc4a2f72f0eec950d016e6fa3395eb006fcc09e48a374cc5b6b82d012c6a2e76dc505ee5d10d5eea31f522d2dd7369914396a196816b5318b3d52b129425451ed29efe8263f8718fe24f7f419e3de5233ec3130d7d67270ef18db747588b93a49c52f5884ac3dd3830c7ee224f06f2f82741baf344b4be2588388f58ca49434fee506ed2790384535939e797da0a1f608d4a85726632cd3c62106ad28afa30cc29dd8a868cc735c911d75317d183516e8733e42ff0018fbb570fefbcd05c30c89d40ae2151a8d28c7651f39496a0a2dbed0cb7cb552fcf8d9186d3775425ab56cb34805e21bcb39e44cc1c1c19b3738d01acbe92ece033503054356042c5d9bf28e4b6875ac54b761a8e0922ba4cffa8f6896a18c93eb84d7f70b6a70bb108e92f45759ad16b0a4ef70dc7a192380aab54eccb91157829ef0b115d1f9854c8881cbbef7f4985c547170586a9e2d31aecb55185dc3dda97032714c6d35cda0e6e31ad356bc7fc99a363baf88b419d81febdc9938746389e12c251fc3dba4f64a95eaa3d28fe066e7de57a25711aaaa81d5998959b99c0713254d10cbd2052364c56db8912286023cde99cd06cdcb5054a82ab75f581bebd748607563bb0f4508f611d958f189d317b730016972d577f89d7f8c928e0669a38e6080b6cb1ea4ab3fb96e232d6e53dcc5748e595bf1e3f04b1576b175f112859e47e5078a0eedb1c5707bafee20a2eaaa752cc473b89d90ceda6758222ac86da22e1007ef59570393ab985155e208a97c046ea07354337050fedca52e06fe6a3d559685a97e775e1a7fa8b17280eb223109c154f74b6ce95694de3108b0d2a8caf5f1da3ba0b8374df48f3e2e1f088188f3c22250b18be3de5ee76f6f9232bc81cb1882e11393f7e6593026f213b86e13725e165cbdaaa9e9f337f078e613d82b70a1694b7305b28ec9d7896f886414de66c50f457a5447a185cd7d3a3d652bd262dee0b799a61cc7b70c4b6ecf8886aa3d2bf1188d5f7823789d610a5dc7b96e23d3749e5035e84107c2e57074e9a9bdd0f24ec05aacacebe9f1115ac9b277318cea862aed9ad5836fdf881954acaf30e259a522b7d862575fbbc4c51ab18ee9577000321e92c1562e7acb3c09d29f446ed5a31646996708d11ad0d7998282ff0049896c8d312f4e1bad4d780eb899a170f19b941b0e57886da34c704b3b82515ae49c11b2378ea30e40e7746ee125d0c3a7ccb3ec8ee8fe67d043c40ec064e3e20ddf337fd22192202ae28e04dc52d5ce5099ef19618ab793189922e3103fd4a768cef961d62a3d902a80cc53096d74c589519c54742850b3eb1cb8064afac250aa3272834113bb575f31e777613586c6ef618d575c4742c4df994d7057a6fac360954196b5bd9160611a74fcc0a51e0638ee84dfeeb8cfb4598770ee502d71052c189bd19b2df8cc45617da6fc1cce56c257012cbb714c6f13cb322a9ec443950ebb8e49e555e83b4fea34765998dc00c2b4f0ccda33553be92a9a299570afccaae6ce5730c5477dc940e872788628db6d222a571b035b820a3d596ea2f4bc63132f30e218da7299629d2d06e311d1d687e65196eea720743a8947daa0d12d7c41a08b67511165d5de60b36dbced304a7b08756fe1896adef63287094af1347b4e1a6018dfb664d8d731fd285472ab81253ed4f2156b2ca2204b669d553363bf99d35774c4ae2acde6b52a603ab17283381ac7e20d34764e294be93347bc7481fd92f9478845d8058add4aa08132d62005cb50d730bbab346b59e49910ba70332f7882b304c385dd6f9f697a00de35302ebf22e772a410533a81e8b728388c741d5bde36a5f4c6a39e419844a7add53946a1aa70748122f78b8400771a85ec6fb95149c5c28472a75ef3982b4710a8f670568c05aeb8d440c5879831680754cf1dfa6a1473f57fb8659591474f88628faa271a21abf41504730f33c4b0e2fde650134080ebb9530f94b0b37ed30dc46d5c2a3220ea4f11d628d16f79cc19ed16ab0bc8f49525480aebb396a585831b2403b40d475f7528e6611d59356c3a03569781ed32e02f39856c5747bcc77721ad101a3819bbfb08eeef08c20dea51f66e03459718542320ed70cfbfc4d31ecb2882c8177a9adb5e6e2f4ee67862215cf3041bf68936a02de788035159779558581be92bdea2249fd0c0ee2c1916de7a7d2205740c4511722b1e265c3b86a590b0059d60ea957b3fd410a32e323ed292c4cbd2260d466d72ac55d288edaaf588ed0f03ba8980ba5e2a88c9ba8aac595080563b157328b0f70f865c02ae05c7b431885953bdee2c4a1817581f89a26b019f33a820e6a65b36b99d2b115519bac2a2abbddaf30b10d286689aaa5287eae90c29984fd7de540659c50ea521ef80c04426c50b34370aee5568729352dbcb3098393a4a19a2bb4e55ce97c4b6c1d1059f6c14d2beefe20d7e16fe2753c1145aa5755f16307061f78e0732c629f1fea166f38a6b03c3065d032c36bc31382b8cd4bcd4d3e21a327cd4014a5bc5389462df75c01a57854a2514602ffa96552e6a69436bcb8982b0794d4a053d6658b4a4530759772ed2b172ab8a97e48f5995b03900d45873c05554ad29188526fca114814f729dc459f939430e034e0b704bc896a5bc9ed1e1c4e587de7607150a1adbd11d2ee5e509f7020cb39770a1297d60adc26475cb9596e790185ea7622b9801a68a26aa6302a1f39fea01755f7dd0412d4add4c04baa55e658c70fd89482ad71da5b601eb51b10de29851570856639b6d3053baf0334778426e5a3967fb89e2cfa66900d5cad176bba5d0a1ac9b854d470b116a65c3883cdcbc87ef996a07f6261c0fb699848e54effde228cdae2ca199621830fe211d86298a0c2bb70bfd1031b36d2fe91715aeb0b954e7736115b52efe907366aa21c772a64f98105e44cea235898c52eaea762f1066e508a6ee5cdee1fba833a3b5436dbe260dabb15309f7d8735ced8740867d7acf7d08a979aec13a83e9f6975ab7cb28ca7c25006857e93a2110972b667068bf41a80174d9d4c8be99c138869bf788d0a6f69b14a185ebda1cc0e884322cb56fa408d3ef39881771b6495c39cba2f12858fd04b104b42b0fbcc2ef26f017d3513c2d0095bf31641ae2c20e53316b96629adee8dc75990d61891a8eee33a03f0948d07232402da041869030b776c168381d622e93b26a437326ee6329f3011bc3b251615185b370c3db5f594aa075e26856eeda96741d8cfcfd208d9e0abf31be6c5cf482270e1b5fd89ae0c638bddb9a7730529680d4d7fbbfa97b707806c3de73451dccc086837c62ff001f31455820eccfde585216602fa3ed02e018c9bfcccc0e7a8d4ad7a30574c3615e4c626817bc71573a96aba936460dd62bcc376995e18f11b6a56945fc6a2601475b07965847336b080ba8e72b5fdc214a4c8abb7f70c101ada352ab361f57f78814e0daee03b52a8cb7302157ccaae329d74c49e4b988e4a0bc977f48b11beb02a388da546ae552dcc16af47fc97edaf011bf06a2f6650e2bacbdce21dbd2680798a5969b8b30b37b7bcc96e171725d9d6e014b5d3a9658697a44f84aacd29c542a916a8f6663eec3ed06b683ccba2678f484c33a18e7de1796269acc322c238eb1628b6b6ccc4070b49fee2c62f1a8096cc574995cadc30368b50ed1aed6bfd10d816b730ab5d66a0a782970d56a963d5f1fdc5b3a835e899600b5957825a60305e65ad13d352fc7716d889653269b88ac8ad91ba65ccb5712fea4ba86a9869989a9a0c2ad46081c43f69531b9c5383b2dff0052f022af927d22d9554ce2bdf88e46745d8cc5a51acc4176564e4c57f515d06b2b882555697e6e5e689c16076665936f543e8592c8bcc310f0c4c1cd05b7cca1d318d45cac9f1f100ad2cc23dea26c02e4eaaa6187a46a8238b35de659e701ee431f809fb547511eab3855455f57c5c0c9bb0aa5f886657b1ddcc41bb0b562fe75370140e799b7a5edafea36254e757e8ad42371991b978ccd897da30e603acc3fd412e580221a385655eaa58ee3006115c359d5ca34287aae0851a87b7f71a5879ddb5f48a52a762c9c21e610682dd910231cc015879c92b2b9cfaa44a8dc197984e3c595f114334c8758f31862dcb17a52bc139cc7623bacbaea6156fde10e2e1d4a4e2541c18702cabcb4d5228604ae109b570713276c10e92e8f63d48bd25cb3a22044ec2f5de640b4fe9963bda34a2ca8b4fdf8b94b45d5b19fa4eb80bc2fa4a2a42b197c041219318c4a5607ecf985d5ded9863b42a52e39c61ff660c30b96dec8964576d771dc654b01f99cb22b7ff26d44e05d6347b55b83eb035ae916563ade4fef89440ddaae61d2eb63beb2c665106b2be91433c2efc4a687b95b8bf808223a40be238c2072e49ef2c5c0346023226d564855a41c65d77f8b8c11d05893004def1a701140ee3f1041187d6005dbcd3515dde65d361b999a96bda58ffb359b3c252af29ee9df70dd7ca1d68ed02f49e2370eb3b9a651ff0052fc34cb958413ef32d436c770f640c84f0c47cc25bac7d238ff0051a03389b60a2a13314b53c9ac57389559f42cc6e3556ed839802d2d7170b33668332fbbc3fadce50798ad2d5774dc2503a33aef1b5d90d45ad46339c2ceb2f2fad58556000c33017b4a8b30a22525ebeccbdf19057da6b887a0555eccbdbf11a574a685c255a36299f31c556f4e4f7980d1a948f76f854b52caf363b7c42d397a4e49a8ec0c5962f48b41ecbe7b6666ba3d5b4c143bac3a977576e779b858d955956235a29d674cc24255395fedcc15055d8e9d1f68bbb4f94eae0f3751b41cd94192ae16796acdcb905094b67a783dba464a68de547b45562e50c16bc5570b838c993ed11272e1bfc6e2f279698254a981b5efb758373b0dbfa622eeca5e29a9c4aa7c7eb1c4c2ed305995c9789bbee11724a5d2c7c4ee936699b6aada22bca3e6058f444188c0dc1f8850964860e528f695b5c158f70dca05be8d3b99726b702d7a560556f99de9a954c2cf041372d7532f113222bdf2e6194403d60b4c18625b27f7fd4d5cdf641410c09d7d0ac33abe262d77764bb1220ed078f534a3ac8e8dc6a6bbe9154680276ab9a71bed311dcb0f86adfb4365ae9d1f945c2d2d9db9ff00b2aa6a95c4bece858ebde5907330b3975064720b3296f14bfbc41055755c79821bbcd67fd4a5eddaace12999a2e39413642b829dfee238f16c85fb4503a71c2a707750a9b6ab556ebf6fe905d74a1fd76984002e04cea97557b9cfc77de2df5c2ea8b752ab3f840ac5cbb3fe620c2ab85659f88430003310915a31fd0eb0154e94603dadc43520c84df89f73e0e7fd7ef1be4a326d5d6586f32bf4efde05f52d95152aa5e1c3bf8806c6888dd7bf329a40601bfdf32c1119b10e6b99911861b83072189d729d52204463ac2ed3cee585f74c14c2ebe855e692148e67b0c65e60f5b8e6a557a412a236a82cd08335535b8a1dfdb52c44dea6d3a816b6ac55dd43a10daf73e51c28d4cf14e65cbae65ed8dfb44671a9edbfac75bde20427afa5ba43e4834460e6017480cc1ec856e95069e30a70dfc42f077e94af04b37f54180dcc1c9c241d273577306c51042b885195ba4610df98da02f930ef0148cdb5f996836aa4711e80d2d7cbcc248b75ccbd8c3e4625b2cd98aae996e5820e5bc1fbda505ec66a3a8d022c72e5fdc4b8d873afac40f0ac1414cbaa197bc23592c5aaa58f2a39be4fde256067e1c2e22ab746a14614d72f98b6b5b69608428374eced0f6fe5b44bec3ab74a941a1609d066e3414c00d372f000e81df4c75a37e25f300d9ea1a2950dad4e266bb58694c054dbb97c7d22f1c8bce6a5b1f382718db55380d5a2676c26374658abef2df33b91228c57cc6e1a075eb28ee273c45a357e21e0f3049acc17d1028ca3923ad660fd9a22114982e612530b55a8e4b1ccdab27994bca6f58f4de2354cd81f663ad8b16d08276958b123b82502b0b6735de2ba99ef31e4cd4d057c0c52bf61957822190f681d84d8eb3c37313a4ea2051616f1050e625d339023c89f04e637c30480d2609fcaa956d9eae6115787a429254eac4305890cba46d1d0ad420791b154fdfb7c4b80655dada2f5732b219e6c51de30abb1d3cd4795b607ef680288a2eba3fa81802a5feaa39e5659c5fb768264d2b15f69c218511ba9c97ae7225f36a55d10e405cf59889a1a979522b76d3c115fd0d06e1a346467043e5358531cd885d0b7b87d897dd3cc3d1df982dd5f4275240e1f860a5911c2c510a029e3fb8b25026ef3663e53fa65e632b288fc4b9552daf4bef08d952dc4a6aa540a29e65f5e21c96216718f30a6275625a65ccb85abf3338bdca2e99dbacbb57bfaa511d460c96838dcd731e0466dbe81fd23824ed42067218081c5a84d574a9d78b6c0a0ab496a65f8811ebef00d15ef0fbcc04f7a258cf1ed1df16c70afacc3820e2a0d212de25d150ace819962cb425c9e518d8eaf12ccd62da62a0d9befc76ec4ab7802d9a9641a2723daa2068c69dc70baaba8b8290e461d5f9972b16c3fbef047b22b076fde0ad0bc8f6978201cba9af40ac63508b52315c4b5f2ad37ad67cee06173c9d97300433785bed334b60eae232364ea8d4700af662a2fb72c0e236c5e0a1e250af5ab1aeff4432b558e5808aafe061059acd47248be9c4b102d1cc45da15b662deebcee2292eb9fb2704516cc7613bed1deb91f7c906423b470c79818cca9a265e83a409ef2c25f0ceaae0c577d788acc4c748b7647626e1accd212f0d3867bbda60633338c337d665ddb33d710ef1ce751ed34c962195c13c1a07fe4e9afcdc72a1f74ee5f12de6c423a9a97a07fb9b26510dd623df36aa7bca502bed0b5be9b9e0c40a17da06cd20b51abf6820c3c6c3c3dbfd450886b682c28f78a5f920794c3cef12f5bc600fda3cd319be6e558a581b400bf6bccdcbe61a73318588b399558acdbabc6ff00772d556562ac821d0a3bd10316c85996b1510c817970c68e45ecba895619d7bcc55c73532b4614e61962b3d616617ef33561b854ea29edc4b96addcd93e4cb6cb6253a6fbcdf9466a60aa6b99999df54819bfc4c0d119786c50d42b86a6e3becf8203b1a7fb9458e2517354a37b97898ccb812972e6d33261985095ca45e844f682098e1306219404e907e90eda954c316a5f89d1a9519ccc3a4306e139a29a69323f784b5a054e7132438406c29d03ef295b00711085cbb3881e7f84a8e15135e4713611db809d515ce6d8be1cc3ad7e656b3f4f4da0f4c4339853ec8db5da91c9e6712eb80a0da3376d95fea2ee2bf04a60facfa8eff00138583216c1b6b0b1da152dc6e66743217baff0073616172f0e3f32ab78261aaa88a62745cfc4b7694de7f7bc14e8774970450ed8f948f556c454b283f314a8a2f01c46b7744a5db1875a8ab99d115e5a27788019cae2f37752efc4ce9707027419f30eb0a9628e6de200801c8b8957a167d58f73a15f3fea02706ede665918945bc623829fe1481ccbaefe83ac7487a73de5b45ca5a9431899b92502c997e21792467131d0952bfd92f912cf0e21c5771368636a812ce99e66e8abd6ba75838de0730affb190db16e91734b41f032fd6677a15710670befaccdf68fd2141773820a66e99ee1280880b5bdf5f4cd4e2196a59c90c2efda73c6b334ab6d9c994d890ecd47c60b5b8e2740ce860a305d3744080a905c3f6a2067109fc91cc6d8704c9f23710c6ec826175d89d4ab3c265fdc4d0a2559732ccc0e650e278a470d93c041cdee60c9b8bb676460f12ed178228571de256db043b7ed46e3e54b837bbe6504a516b5f589636ba7557e235475b9f3152d0c41a2158b9ef2b6b984e3d0b65d32ca9ce26dda6dda0b7a831180baa8eaae7de51ccce904b3682b6f704a0f34c3674eb28b6658350aadcd58985ff731163a1d60a1423805db1016c046d790ef08d6516ce0d041c0b26613bfefc42074e239cca3cf488552361b9845958729865534733e3f32fa7cb4fea0daa79cbf89a305dfed861793b43c835cde909d9afa77f32a846f0ffbc16565a77244872fa1712b6e4533a4b5ad137e3accc4e9a53a8eb552dccadf44ae91756f3de5841e4d3672308abdc1dc7a328d01ab8f52b8956614340ea5264ea647c41dcc0c512c5ad32871962b4a5759cc24b54cc5631d62bb1e86977167fb9494625ab9639a0dc052b468eb0cb8a9d3f3060e45a5cf6b730d6ac7df30c599a3504c8cba96e48ecad737e22af0ecf8cfc43dd103119a7686ca004750f4ccccbce671e81d54daa5e65b71c8b81a46e3b89cf30f1534ee563b46353c26b8601c39e60cbfa8ad173a90156470b89896d1d28f982e58c033ff004cc65752e0f37c7d664563c57edc34a55b6fe60dd746880977e4e1e3981d7b2bd47545deedfea76935b7bbef2cb2c07eddc0a743dff7f7c41c31d88158af6603576762365d2e0858360ed9a91cc65ed51045d538faa5a64df0710e299df8979ede65d6390c3eb7cd962e3a1e4050d733bc4e8ae8c7b0a068fd930064eda97c586eaf931ac1d3771c015b205805f333d56ba443dc6c9853be311369599ae60dd5be937095073d58799d097dc882a00cc820afac54a5a5d4b2b558853348f75701c43cf30a8e82a09b631b788ab99776cb3c90ec9509472f983a6683101e39a8e3745fd22adba97d2e5cdfae6e03352b986425e813267e6ca68880e0777af98c3de4b6fc44559574cd9e26044b39a68ef5364dd8fbc20b13a265081c2cbcff00a44584ea4bf0d3c1f11a94828d24a088870540b91d0ca28cb970c416e94b32af9998055f4cc11256f23253b7bd4c84771c3f5940509e52b9934351a1891054746dc69fb98872ea15883fb89eceb280a7132c0fb30cedcb52acb7981d12f9ed176bccae182728af1fdc48c056d1accb6c1c755f3b9bceabe0351319bf27c4b1763bd0d7318a3c2ff584358baa26212dc751ab5723811e45b86ab6c7680b66ec27d6309b5f0a1d68529be3cf5940cf800f7bcc2d6b4c3b3b758ca6929bf5aaaa954def6d4b181c95cdc7f32783981382ba3b2683771a5b1b94e9eef40be0dbac55c314607e2591c331de19828f31b86c705ada8e8981c842cdaee558385ab8d1c4616b18b986668946a51bf318e8dc64f797e30c0a3d41df12e3443b8b953dbf294181b41c798568b34187da2b2f60ca962f42d8f896c69e5c9b8388e88289a58ee9acc2d16e3f082b9758a1d71b34a7966a403c4459a798408e3aa017dd1485ad067acc9803e206794a312f7caa61c7311162bf582cef92534cbd2536356a6842f6f5e2885c50746e69ab837aa9999be90685ee8be2e3300cc28e8e7acea35b185c1b3c74867bfb4c99a06ee5958954530acc42cbbc5c6f436f4e26d57da0e7c54a1b607c088a4d6d1f6cb01314ecac7c2e933de2143597dd9dfd56e6c4e78c475c814b306eaeb8d45e4d6edd52fd984770c73775cb0bd4e06cf896ab75f0ab65516f2fbcb238ea8a59fb853e0860b2d4e685f2f32cd33ec626cbd59070ef0b0d9f0a959e6c51e95282ccb2dd28aef02e41776fa7107d7906c78596541bb0d3c93840eb0a1c1a4cd9faa0c62d7c5cea5dd88428c4ee45d4f985afe823cce62c9586a2f2d469aeb2d589df2cfb44b2f41b133adf1059fa2fc0c641d03e90bf9c61b1ab4dea71c389741a01d732e9baf27795dd6fb4bb769c10ba68806cdf5ca525b7f12bbae56ca7c9034399668fb4e9ff0065064ccbe29f135595f642b75973324db543c112d941afcccb26222cb2e3cc556be82d323ef7797a8d5d5dcb5f954b05e20abec99b9021d8992a628315af79d428b4b866fe938dee36444c431cfd604bfa12dd5a97d3b4bcd0750b62fccdc0536f42329e1a7bdb117f35a5697f8970ef556f61311e9a5809ca03fd07c4c8a1d5bb3a1be2bdae598ac7188b583e908d0154a5a421b3df7f89f41551c9a7e906197cc14a431cfc7b42c6505a2c9bdf0fd25a6bb778d63adff531b61eefc42d9ca0bad3f6fee29c9345566b3998294323837d618cc148e4cba7c75869c8ad6e1270b0bd37c7b429c1ddc38e7b4b852e2f1ff5da64577306804b7c9299b52bbc1a836d415f15f4233e75305b35e26dede9c5d4317af596e0744b0346167506322fbc6163bccd1f0d468f7eb2a716b0678f7961aa7cc0aef0ca67b77a9a614526f7b83d6e1662541bfb4bae5419aadfe21db5cc1ed35b7ccf0eecf6bbf98b59773b05789cef8f88739a308d9723da58a33988592fb1069a6b50316127232b54c32743bc1033900be6b32e29d758666a74b406aa2b89aad90e97285c8f6752f7f099d55b28b0170ba725e25b6b758cce21d32c5bb0725c75a83cf263ec05b31c09497fbf310af012b0ea85a64f6f37f59816c69d42f575bc7783080cbeecb0357d0f795a015765cdd74e7e61b2e4331771591bd32cc1c0ae5560606d37630fdc436d4757e8dca8e62e5c1a55759a83d0bafeee5ad5374185961a31ad67f7e22ec1d0fc259bb872819a77bfdeb1a9d85e69fdbe63c5416f0431556504e6abb39eb98a3baf059998606b9836bd59711549181b02aedab89303b64c02a16f1495035ab774dc6a2cb61d61cb9d25348258158383336f7876471d712af73aec5c4943acce8e79971d6a6d5e2788cae45f895d732901e4c77cccdd5d12ab0f5ce259ceef8992c105bd330bd7f30bbbbb945bd61a3570fc0979e881d730d731ac9537b3cca746763fd4b2b667849e4732e081cd999da7e225aa7dd9889e2623cf482f07d21b6417acc2529e928ec9d200132d69656387b4c31108d1d5f31b4996af697f79bc93aa39bdc5e4b9bbcc413274b855689cf79c30d1dd991432ac261066d8cc682816dfeffb8720f341a80d1ce8c04b17d0afc5f889c5960d535f68b8b4c220b8b14179f9eb015198227826ace25502f276fcc02894e53a8e803bb015e2e32b05bf40fc463e8675ef7342c2de2ad7bd448753014f8fbccc281b29437f8943d5cdfdd2e6daeac291b527fc42d58cda13087c7d65b501b32b995c5ae0f32b6dac6c303eddaa1714a6d0c1ec7e204c52e185f6e2273b4657d0d92c4680cb1deeff00a8c1775303f57da6150e9563e253814749ec0e9287301eb3632892b99599872ca5b654dcc16b8f41a272430e2537fdcaff0055033a6e2602856f9e841a1c9de52f76789456a69afa436dd90cdeee55671e652f6dc5f139ccbb60c4b4394e1bfd6a7171e561ef3696bdc9c2a4e4d44de2b4b28959c063733b4a55787ccd30971bc74e2182aa35a14f12e3c2d1703a4c31cdd9da5c53b46b9f68551077977ccc4e3c4c3049f04507d09694db9be61a150c3060b2319885757300477289520505add5fc9117a8ac2b2dd3fd4ccae4b532bcbe7ed09e63d8fa799c00813dd980f039ae2f9fa47fd273633f9fa452b5d6ac004d75d10202a146de67d0c0f3e23b8742865e7fa85500c67a6e2e68dce81a3198aa23981021cb04732cf9bcc06aaf7897507707fedcb30cdb3f285593996d8ffc80de8e591e2e0d6dabc01fee220b2853b28ddf5ff51684b5acf0654290607231c7eea15b0576837d5596dc1bc9eff13a5261782514a9d56ea2362af979966f529cf697cf3281773aae7bcb2cbe7d159dee5f482bc352ab8cba4145fd415fb7595c7c93666fbc31d5992d27bcdf2194a71f399a3347880bbccead4eb8a19a4b7e09831819a0dcefbb2e7c7bdca4c1e588a00ce503fb892143e13702eee361279649adb7562a87821f480dda9f612c1475a87441f6b31b38960ea657a4c2722b27d260ca9f3a81202be5de6350f7862b8182a85bc9002a0f294d659d7898db63a455862dcf6cc55eef1ccaa58d99fdfd6280ea1cc71558798e0570ef7ed2cd280a1cff0059814138ab3554bf372f88416b0c2d7795b6ba3c75c910dae1d28e90d27417e2ff00d32d51f2383c31560685e9cee62376796b8fafd25bed26b143f5544aacf1d3fec36594163c79fa4a1dfd56d371450c804577afec8b32e8e1e905715a2b12ba8166f8abfb5cb0641eb2b5a6526fda3cbd1d20efb3e62e247607ebc423a06c815435587f49c53884ca7760360237f2e9bb9c042c837e61c6b3bb7c8c5e4dc977aef164f657c1ae370d155faaec4a40caeabafc40cbcd80ae757cc0999be3dbdbda28721c1d6e05df786c2cf246ada5ac046f9f8972e658b588cd152db16fa32e99c1e6504b33de67cd3ed3362ed9da1f94d855f7250e83a12f6563a4ebac372bf33af18d4b45d5fc432e595a2add4db3064d3a99e4e2579e654ea57a4336ce52274a6ff46229d0a71e713dc1c41acc459ad5598e72df79b48ae91905bed1894231842059292ee527209940839480a09ee884a023f43364035bc4c9a5de6cf3268bfde65c51cf0918e660be07f1161ba11a7ebed32cd9b334f3f88bdd577da2ab6afdc5bfbda7039add833fd4af357bba1a9634d30ad06beb935de16bb6055c35afdd4465c2bddde2b42ab2f7943abda3b3d2ecd83e20119364f3fafd60ab5ee17fa51facb69b2a1c8cff0078f896d996262abb7ef499bef5ba1f68366c3677bdf89415b9c4b1e650de30ab70eb98d4b3d06d7b6aa0d360611ab8a809ab6bcfef58814f157bf1e79882bb366df712f54e137e6fccb8e4c8ca4eff006833845c3a84051ed3fa0cb8999b5329cd75940a0ea3c3fd420c3936c4a0119db04700bd9095a09797ad5c028705071def30a3dc067c662aa8e4e1d4a5c1669bafd6501377dee2b9bef287b03171e095235d763f771ac6e2691d52ca0d61f45c625bed2fd3ffda000c03000001110211000010041041054ffee84d034f72b3ff00397b3f36cf9df165cf73cbcc76f30d9412e4da7d44300b00176bf8072c0821b73fff00f39af6f77c31fb0e3dd5747eff00ff007844981541ac924f41413c1ed3fdd42096bfec39fba739ccfa518d34f1069ae73c34c3b140e055b941e170f118b3414517ca7113dccc6438b842477c32e72593573c16f3cfc22a85994794b7a0f668e827198f9cf37c31932c2e57cb0cd0c1404528bd75c56d32c0e975a505e2b40a33d027b7c70bf745ef8d58a0818d8f50431a54410720e3bf76db1e0e6522957c98bd83c536e45d43e8a1b28df12608bd7844ccf2440581b9ae77412d1288b6256bcf3723b7957f681a25405633949182405bd32bba8d229cf512264c308bf700a1933272014f58d6c8e8e1ec0537a684b734b103c992c62632b6cb890c98c41541c1b44a06c342f17382ae9aabd400600c857a1cf27d5e9c496080014fa69280927771b8241960cd66858c0969eb70107f1ca61cb4edd1a324881c02082082f926566236681b2adf0544db42b85214476c6b1c68600bc9db84a884ac8ecb29301920464b82d61f694021031f2cfd7184c4454e51b81956329c993ba9481039ecbdfef989171d0a13a99558523439f44180e234b801a4a03012d032209411dc021479270e99bde18111f749943de052bbe48a4ac22b5b9388044b331824de8196c8eec34e35aa9650c2743480e6c2eca821bbc60d3c20f8b81e988eae280830e19e3ba178d8e68b55968d75d45463c40172988014aa926e61cec0d2427ec5109ec7719b81d9781d516e26e038cd24db395f209aab2feec466258e3ec553da5a709a058002d653cff9c632bdd72b88ae4d32ee2d90a91db56152f7ec92c3e80c28758521cdc6f55299c3ce1c0a013de35a225d27d1d9c1d2d6a7cb2ea7a8790bda2c65872b1aa4b82f5870672ebac0672de3f242ca8ea423f84a634d6aba14d23e7f95e940755744d915af3d0b56fc7a7fb29c8bb70111a773d8b6daeb03d58df42f10e040d12f1b82e2241e15604f35e354511580b5e0ac3b279a0b26010a084cafd856b0742b916d0194a4c6842766b6fbb743e8482357c9242013c149c45617c11b517825f417a35f64e594101e94053ced4f25cd2f3114e3d674b4b103b8c8210e1faa39d191cbd573384506dc94675f760c5f09c35e72081bc7fc8e3a912b848510ec174c2314420fc0151287c2b169410b1248c906d428840f2d2f2c78518c9de97968eee93b73986ab462064c251c4910a18f086d907d7a1f6411991303741d79f63f3396f80d2999315eec968400996fb1089c7bcf32d0e632dc420048c3852cc041c923d6512f750cb5510a8d97c7894b9e9a1138d42e631461c8b503a37367f10e597f1d54bd1629a6d15b5d01480cd702e07c1d05a6d85af5d27ff243caf3ad43810313a459bca67b1a3b03b6b6a0425a46a18dfee785231d50d168d172deba9531977615e888ece259c606bc353be0c80801fdfd8a98bad98bad10c277f12d2ec63cb6000f97cdabf9140d340828cfc0b23423aa807b2027f0b6b192a838d5c88f03fb219c206881dfa02e64b954a699809a3792fa10fa89a882cc519392f3baaae0ea94608e1481e80003c6d67ccb82f62dc4147a7ad66fdbd8d60a301994908e5d0be6f5d0c38e2c271fe0940cd4bff626bbdfa8288103638478e4922104098d871e2e4f612bb4fba0c423f3b78b040f95a2d1021f34f3d9a4152e426802dd37f19ff5683278789232030a83254f01450c2537b60ec5d798f7018400ac155ce34c85c107d2877460d1f2e3bb2440885982740108d465447daca2bf05b427991a1fdd90cd4de98095f0418ab0409a594c63c93c03cd41e11a0845ad68d8ca86d3db499493a331890181a9f85101c80c98266bfe70005ffa05da23cdab055c05db1041abe53c75a122bcfaeb63b8e4f3ad348b5401ac846787c00ea20a3c6b8cd1bfd2bd830a6e0128687c3639dbc0c05a0d6b229db27282d335dd0c4501ece0392ddc981c49433652a1f7c361e418f560867e5a2d2bf39015ad920579174c14806dd65587f3875275479c46baadacc7cf5fdd6729b71f899140f01d78a693092ab289180d60085f8700ff004831b291c954b151840b18d722c3a392ae1d7bffc40020110101010003000300030100000000000001001110213120415130617140ffda0008010211013f10f8e7f0e7c77feddfe3df8167fdb965bfc5967c33fe5df8bf0ebf873e3bc659ff0038d936bf2c6d7e0dbc65fa4a11dcedbf2db6db7e7bc96f27392b8ef9ef8df8671d993bc95f76feac1f2df8efcf7e1b6c756db6daf1bc0596364165d7c01defee05d581d4cf1b79cf8671967f06d8e03b6719c67cb5bbe1db5e338e816977f512ca72185f9671bf036de0f3f76ad9d871836eec6c7935636365d5b6da5a5b6d836c46cd1f727bd81ff39d386f0db7e79659f0124209126d6d6db5b5e436ef8cb2cb2c6e7dd9fe91bda458ce8d9236b6f3967f3a4249ab5671881626b30605881c376e100fbb59d5d0c8595d2049f7dfc77f877f805a1e427c23ef9656d6378f78ce32c837cb79dd8dee4990cea4ade5e7b60b9637777fc5df19cb9ce4eace4cb2cb2c82cb2c6c6cbb86deda923fc67beefb949ebcbdff00b7d17632cebbfe2cb2cb1bb820c90c97832cb2cb56be218408169d17496427ab209ebd6df4447b77e74b4b4b4b4e34e1a58b162c70ccfe9299edfd13f95fd53f943fc87f96ad5ab56ad92b60111e5babc12c25dbeadeec65bdc8dd876597a677776c36f1b6ddf3dddce7ab0f8c8ec8969b2f200638c2c202c58585fd12cbc25724c38db3eefbbc4b845a7040d2c24b71bace436f7cb48fb2614f72f22076997a967b943cbcba872517366202d3804fe2d9e03c58978f59462ee0d916f0333d814b6646bd58ecae60451dc9b286567dcb696a37ee5df22cbb8d86216ee058c3b9edc6c0ac2f304ef531c17abf76dabbb1e4703f53bbd5fda40fd4ee088f531d91d92b1907d216f721d4e78826aeab2c838fa88822ecc9935ae5b2318323bff3664cf1dcc19b791e64f19f53be00812a22aee476ec296fd25b285a797e924c3dba23849cfabb6c9e043dd9af5221edb2788cc19c27d09d17467ce0b4b4ee7bbfb903ab70eec33813eaedd6c1ddda5c165fb68ea77ee317623b23c059321c6d922cef8cbecd8796dbc600611c78ba0c22b03db232ea3210c61a01ec7d90b1d099f76702f492ff00881ceaf5dbfac73b91f17d8bb3750d5b2f2dea1659c3243097d474c9186c63f70e4471e18ae271d174c41a41c3d477dc1ea7b5eadc8bd6419d96c5f924571f61fa8b36d1030e62b59add89374750f5773ef50da5917823a40cdb2b6d59d5eb807b83b91aba07fb0c6ed1d1f07e659865e5dbb6d59f4b07b7604c80eec1fc58b6f0a524c5d9c13dad7c4220f25ee733647eb86fe78f927d112612cf6dd08edbc5bdc6b6f10e1ba8738221e361adae97a849eb6019187b385dc113a7b7dd31658338d362f538475027375859bce63a8fee2660fb869084cb7b893ab58998ce5a727768eecdeb06f7616165896c1277ab7db237327fa933bb56b6e86f51db007b1fce0781e44701ea56deac89dd963f59609521c12c81f50b32d65accf965871b092fd16a7bc0fb0a3a6d1b6fbbc42c5bc113dc79c2f5638d32f59d2c76b367863cb3a88bc71dfc74e1b4253d9627b6b6f7ddf84fec3c6449c77c3ced93096fb85b26c1b3a185ef0fb79c109762ce3be01bcf877696902406b6361b19e59fbe20962ce719f3db38780a5d670236f01cbd22c8c2dce90ebbbba0f52ef90162c5bf1670d877ee2742eecde44596596597dd8ddc3c326d910498cd1c248d33a5d8d910025bdbd99bf642eb6cd87c0e1dcb3cb590db503c33206d21394b17575751960f14f105f596753288d4525e91db78d97bb5c310162cb76a3f5604dd5bdceacac4091070ce3b95fab56a16db5bb939dc0e019909b0322fabd6edf763199048add8bedb1c671b0f2a1ede975691e4a6583d921259ef85701f1138f50e4f6efc34776fc583cbecb1c75c7993988fb9e977168ceca8dbcf2dea425d2dedf5688359fa40fb9d900e06db2cb3e59c06f1b6e17d0b1deef23f030b35e99636d93b1dfc0b20c99d208ccea47e4294b02ddcd9689e361863e1a45bc964eb2d6d8d9f7c09675664417b18752848b41eecc258807922423ede79c3fa82cfa813d8124959f79d621b4b49eece191610dbd92f769c3190196f61d5d5eac86eac24bc4091bf7300b03b6d9a11d66699d71a9e05231610acb187212d2ddf25eaed8fea31780dd5a64c67a6187884ba3c20f963bdd856de9d70750204bad90117500ed9876d8e04b2d6138d2cea7806ccd88bdc7f5243900813929b24957a4fea425a6dbdf50302c7f9777fbc7b661c85bd9bdb4f386f2773165d9c309d4dadd3636c6dbd823072c491e415a65f193c074c47d44ba9852edb8cfe257d5b6d88fcce0b55a4cb1f5c03f791cb62c87f672cef867c272f36104b494f6ed6bf5768877763651f20e7520c65c596db7bd9b1096f77d405b7f79f641c5ee5f81696c796f19a75776369f270ee02ddfa7b2a54ee0fbb166fea86f2eae976a374ab0e994ec81e1bc360b210d9d5f72c70975ea6764cd98adf00a21c20b300b0b083274e06fb31061e493f2c032bd7915f50e3bb0dd40791c587cb58875ef0e5a7b1dbbc6ede4744f97b79c96daf07c4ee207c9770cb3e0b6dad07bac230906cc4fb01d58bbd918b0f10a487920f7763086719c7d36c2d719c65963c6da45a441967f6c40d99e0d64f5bdf57ec7b84f65a7d6c0e98306c116fd44eae994b32ca4fbb55de334ee7730ee38de161b162d2c58f80f5752228422422c3dda5277254ef88de985da7df65a5ab03bb4b79da017b66d8cb5b6a1e5e9d47718d9244b9e25b6fffc400221100030101010101010003010101000000000111102131204151306171405081ffda0008010111013f10ff00c57fc14bfe7588a8b97ff8abe117874a137fbf151514bf28e94594bb4bff0082fc27441a45434cac543090be1b1317ccca5ff1dfb5f09c6216e11103b2868b0f7cf84426450dcafa2773b945fe1ba9ea2e51a3fd10a39120974e0e0da1be8bfd9c1b1dc75229694ef0a8e9d2327fe0ee2b12fc1a0a198234ca2841a0d0582786a74662484a25679312ff00152ea62a2110a130d412191116a51a82a210d0c4c41413424120aa3a41c99c0e9a12ca5289e74e91e262427164944088506a120da1a868516363fa97f8366267e8b362c4da21ba47305d1962568b90a2cb213e21310989898989884c4c4c7f609444c249126d90e150ca58329ca7e8f4c69e095893a123441110bb7eb9a988a26262620a7cc92ff492194748de0851b616595fdc5290223e0fa8666c4a65b9b76ff89144c4c4c41042fdca035621628a8abe0520a250e7c215a3a7e096425ac5294a5294a52e528b358252045fd0170994bf03f88c2eb3f72e31ff0046182756d294a5297e294a2e86c22e14ca5452e52e294a36c6c90fa3c2704e8b3f3171887582628a28a23288c498b3a138898841389c49df0ffa12fe8ff61fee3fd8492492242491090c9b1b3f4fc131ba45950c7901084470e1c210842210909084af984910c81fd87fb85fd0b4361985142c0819a437945e7d3c470a068e0984ccf259f30a1a2bf4b427060c9c16f473546ba2be1fd723186cf365965e21641b3f4bab573e29448f033b04869bf0e5d38510c4851212ef46e89c1231a5137fa25891cfc1884f8111083891fcc66fdd46d10854be265123b97ff0b10d7a2310250bac290b64ed109d1f3d1be7063e89b487fb0946b4be5b28e8d31946c6e21b60d994b989483dff0091ed21424878829a8c7389890b2a114fdc276e638c497e9043427e21a6166c6cff004c4c9f08e9c172b1b3f08f45b886e8c46dc3d821731d3bb72944243ebe8d83adabec2d787e1c782e8efe09a09a19062951fa3f4436c7dd6e2cc69c21bf4ca5c082e11fa26238211dc9a9a1205e89ff00fa1a7007bf76a9052f08fd2a1a197e8de31b9a631b82630836410958b7e21c9d1ea133f07da3c42222c6eb0241890898a10a3a54fc1f4213a773f3106f185093887f420b1a21d346cf7e4647083a7c29a21dbfacc27e08a746c6c83d8a1fc5c42e747e46ff00083c178319e065b63f4c74371338c12a3e31944b3a7ec1fb477e8c290427062eb1aa2e09d1e4e0d1ec3734a5d44e9cc0cc4e0eb15626e889b1c57e0a9059d78341bc4434436f189e4e05df04b577e89847e08745e4d4910789f7b82719b13909513bf453d28a09fd886944a5e1d831104d6310fc23f95f14a512c6ee4265f876d34242f85284d9453d784c6312621a1b4d5f691084108f5f3361e3e1172ad412bd17484e08f5918ffd9d3c77ed6ac452e7af94c69b462e212e8c3c2a184654a30f983609c6ff0082721d2b27dc20b3fe1d1218ddf8482eaa26ad670e423628bd1a97095e8890a265f989d78e21a418c63685f14e64789884cf08c5eed1887d5086a784f870a15fd770888fd2590310306854735119d5e9d3a74ac54a2e28537bea2909a12ae0b2310e64210a17c582813145637d1918dc98909108704704fe118883e7a375e2d63450758fa2c653913abe17562f9991bfc7e8cfd38c615fe7d02a1a118a70823fd18bfa2cb8b5085c1f82c988841fa7993689093c45e42afe09bbe1589a8ca74a579ff49aea905e891636b542b8f44d14ba994f467728997fa3e884c69a105fee20a1515151515145df726378cf47fbdeeb5dc7e97294b94422e5188594e8937e9cca56132e23a32946f875aaea9e7b8f8f589fd7bb3e13471f824ce958c4f689e545c52e365c778a1b10b1b1c310d3265da2c6fa53dcb89bfc1a3f46a426ccb8a5f8a162626b565bb898f711fa216f9ab851217220feafca652946ff0048651373297e1f851daf0e1d297694a3626f68e626227f9610fc908e1ef1132944c7e1210c67e1d2e52ec162790bd10be697e29d288acac7170519042f44d0fbf04e90892ee95953381517132e5294437d2e317990842322222a383684c9114ec2ee23ac2fe8487475f84c8c4049b0f4c55e1c091896523cbb4a216f5e64212e270e0db083619467c8624285435f048bfec7d5c184b4421a9e8f8e10e41382b1117c2c68a51b5948e1c14f0423ce9d1a4f0a220a2be0454470543497875e08e07c0d04ff0031908d8d2ff0bcc55932e43c090e14829715e5294b8f82a1697707d235d6721120c04e787a5b6d09b471e95e8a424b1a5211a436d21c1365e0abf3214fffc4002910010002020201040203010101010100000100112131415161718191a110b1c1d1f0e120f13040ffda0008010000013f10ddff00c9ff00a3f07ff8d30cad952bc4a407703dc3ca1ff93f152bcffee9fcd32bf14ce254a944a253f3184ac4affc57e0c48c544dc489123518c63118c62463518c63affd8ffd9aff00d1f826257fe894ee08f3f9b2592e7acc4a95f8c7531f9f6fc54a952a57e730b972ff0038ff00c592e3e916bcc58fe1a8c63518c63518be2318d47518c63367ff0007e0ff00c07e4fc9ff0093ff0057f85194ea5575f9a2512bf0cc773894ca654a953895f9bfc5c7f39830857e6bf14ca8c7d6371fcb18c6318c6231a8c6318c631ffc807e2bff00443ff27e4ffde257fef32e59ff009ccccb65cbfc5fe13ff2bfc0c1827e6c972c963123713f2ea35f862f88b18c6318c62312351221cc6c82df5013b601d934b82cdfb415e3ff0027e4ff00d1ff00e167e4ff00dd42ff00f353131f8a94773d52bf2115fc4902557e3de5fe1257e18c6351d46318c63a8ea31f318c63a8c48d4485facf4c126f6d4c34dca7150ec81f1ffa3f172ff1f4cb21c9ff00a3ff000aa6303d43bcb9997f93ff00164b25ff00e2dffce263ff00cac8dcb97162c58b1666318ca62622448846123551a8ea35189cfe0fe1b1a964b878c178b83ed01b99f107f07e53ccb5677309638977104e3104ee59f93f167e0da0f31a31a6e184f595f8b61ff8a94fff00863ffc732e5fe2e2c58bf86318c62c631b8dc6351235123091188c47f00a89e65e3398654c02405412a5d4e0482f300e98307f1444ea5bb31f0fc53a8794c3996e20099ea0ba9772bf2522f88978c40f2cb25fe38bf697995e609f9b254a952a57e6a54a952bff0037f853f0ebf0fe589f8a8d4a8847ca54a8998912318918c62cb58a788d136c620ef3307e1b919c263b6506a3c92fe20730e48456b994546ba838534c69b849b1826aff0005904fc57e0c5f9604851288d065842b8e85a88e9ab7007bb1f702cf26ee783b5f90890845a095eeb75e663b3e7f14fe1780ca9898944a2575f9bf12ff00171712ff002cb25ffe6c967e53f2fe17c4bf11bea2f8822118544f711dc45ee51e2511823822e89ed88ac48e5729e660cc30caf8801ccc34c17715772d4644e2d8950128f24c3c9182ed33c201e6e17087e2ff001c7e100ae00b66529b2b40db31f971ad14d7c35ed14080c3cf9a9b6cb8b6dfc474e6bd8555529b1cf19c10ee6a82c3e40c9e77e211235d8d84263f189ed3131d7e15f9ccb972e5fe732e59ff009afc54c7e311224a255ea24462cb8a45229a8c29510965dce2604b2e57fcca45630d8ea22223e11da88a16666711181033b81e6298b852152981a98f05c330bee0b76c27d5f8012593c92ff0b752d9ed130a9a50da53af7a98b29ae8a167cb729fa2cde56ff865f16a3c07faa0a2b4b5dc3d12dab72a676f4298ead988b9396ae87cc512a5c064f5ea5ccfe2ff0019972ff0c659162c599fff004a8d4c7e28488ea3645fc118c5de48f9a5eb32b5a89b94961e656f189635a9d63326679c058346dc4e82a25d625313c9113c8898d0bc4f240cd5cb7996b328e66b20803a9456a38e231eb4c3b8496fc40a64a97712c949713308d50d9d4bfe5d1437cbe0aa3ee2c452ce7ea11561c10414d0f4ad44bbcdb334ba201c8384e13cf895abc96d00c9cb497e6ff164b9729ff86f94657152e67ff38fce3f15f8afc94fc1252bf0c26cc47c7ea5e2de663cc0ae65919a68b988a11addcc6553a1a8ae625407117bc4046e1943d1031ea94ea09115a955f1111c71064049a733c6e59cc6b6c2286e53a9d832bfe250ca710214710a989647997e06abfb4616565b6a6a1e2c6e583a704ee0a836f528b2f294f4881f49599ecc093f68b454bf32d2d2d2dfc24afc3d52a54a80fe6a17d4b7e27e1a42295f8a38657b98ea63d27a117c462fcc59e98ef88895bd44d6a29e0f896b8622ee256d4a4aee35c929c4a93c1a85f303b952a3094678a78656a57894ea5095f8208c32c94310812df8d6012881f95efcf92f095be8f2e76fe3ee09886669a43b81692b30b78a98b549f896a042cbe3c470ac9177543fb0f8fc19898fc04a94cb77f8532d2fdc14b7e1495fc2aa590fcae5fe3114ea29d463e117c47b22c371aee34e60cf2cc7994399876c7823a818d8fc82e512899ae07e0fc19e22750b99fc8994e627b80095e666504cc205cc20ff00cd7e2a5797416eef0f8b9535b1abbffe41d994f546141ae7b8ad59431330a3ca11ba2b752c214f1fef9f99c204bd169fef12d2ff000a8797e2e170c93d50d7e2a57980ca7f04c4bf3312ff000a7711dcb253b94ee23b95ee20896263d1172dee3e72c96ee2cb4b4e653b080392fa134bde31fca07fe0fc1f83f147e0843f1895f96a01e27a3ff8bfc8cb964ac21c485f359fb611199ab6287d01ed2d316a4e6eafbf10494db4d23001cb71085807ba2fb4b076f188a20d3a7c419605f5f08bf1b87a906059572fd7e0d76cb108138d443a9ae2579259d91eacb750957b8aee5b2fdccd9e825cbf3f8be3158f945597162c58dc63a8c186351c7115e2a7296b8dfe7c7fe2cfc4f0fc7d1f85fe067a25cb8836c4712929dcf3667a61e5093f19f93e3f8d7b8cde22b6b02935e49101646faa0bfb8223654721e3c1e35ef98a4f056e987949b87f9d7dca6bb8d5343b733618722ac6ade0f588eb77bcc0203caa1dd3d4b3980f304736419b2124ddfe0b99e27a256e94963a48a77117693d4447fcca653dca7f0a8130e259d131e23528843b891235123123512351a890411311253f03129dfe14ee7a8f9fc2bdcaf709dbf2de527b3f1f4116d512d63eb2d968ddfe0478b2f37dcd772fdcf34f37e0262f930fb3b42597bfa4a51619017f463dc973b0de635b507c92e05fb434ca1435529cd87b9499fa1751b0c86a5dc2c1e92d57dc566934f8062c38c97b1ae713883ee74c394601fe90be69eb1e78c38dce8b9e86741399097d415e65bd13da7bfe73c4ccf7fc533de5783f2c75f84c46a54488c6a2448d448230230d665b2cee7ae59cc406c8f4869724ab988e20863704e61dd3cd3cc4ea62fb9eb857a828a729f12e3646adcaf729c4f542c6e07704e8fb9e7196a88160bcc28c3003d22825119df696df503e9d210a94b0c7183ef9a7e7006d4dc0201e8fc9282001d0109ee3088f016db7996ddf62ff00ec5fb16d71e270245bec8951d017602af5bfb43b20d668b03d3515b5d8b454c5a43ac8a1b8f2fe67217bb3e7e7f27e0843f07e6cff00cbaffcb1891224488cee244891a8912520cc1f814dca63d22d59fb8c3bbf70b77f33c8fe000733073f85f625a3c11ae3d13c04bb30ed1d1434293fc09c9103ea1655a1e7f53c58f7308bc0bc2090095d9b752d522d4187abfd46c53b857ad589f4ccb53b63b031e8699fa61b2986ac974c211463157b4cd14e7297d4188e39a003adc203546d788f5a0804ff0016e7e2259dc514069ed81450e4d540bdaa5f6f5fc1f903a970fc129843f14ca653f8a3f144affc63f1c7e13f2d46312318c48d448227e03b975d1f7f89d1157a6a2e59ca099e082ae608ee70ef0af52aea59a08764f880ce20359209c4702276009d621c290baf983f3f73d198f48338977a462530be22dc13a8d792be622a40c40f30e68701ec24b959695b4b57e4d7ff00613ae81c86aeef64a86242576f1c88e1b4712e068a93689800d730dcc87b25a21419b9928f751c41a62cd0669fee20182c5ab1c8d3b572a6f4dde06c9a3d28de0e853dd421f8259021f8210fc07e2cff00dd329fc24aff00c27e2a246bf091a8912351822408332e71eb896f4f49696712d775f501dabd206b4fc403c915ea50b07bc01a4b04b997e4f92070bfca4d47a0098ae8798be5f98b5d03ef13c12d35f1ff0052d736f67f507309f11490aaca7b4c3c7dc2fd3de0ba23d180ff0064732cfbcf6952a5784af103548ad56997804e20c73c41a5c2b2d281f08fc42edd2838ea0a098375d9beaede0798d81ad5379e4480628ae4b2afbd4b9044f98ebceb88388ae80de8f41fdcda0250c2f7e90930c083bd2668038ceb5410b182ad804e805b577830ab06dd4608d00d647aac3ccf66109508102543f07e6bff00767e2bf29f96246a312246246a2448913f0060996acf996576a7105bc15e65374dec88698909856ea1ac940cca3b6f73c97b335c57b636534850f330217373a2beccb053f72cb1c5752dbb94367d59973afc30fc2a55ca81662540c4a86bbf484756d540f2ca1c830019c185bc3b86ee1d1b9b4ca66c141a19840d9bc5a197dfcf6c273d01a85f83421dad3d39822b932b73710254057f7c6e35dea2fcc78bf96b32c8d0ef11524c9af59585a7a10bcbdf62aebca39e594fb61a5f3144f1ac99cc7885000752ca75ee30e7c6fc4f3c3af3081021f92a57fe2bf35f8a95f9c4a98892a51f8a8965c489133718489122442239b660fc16e1b4956db4f32b489afb9bd40f2433f581d867a867550d3f985e19fe6abf96df8612a0a5100dcaa352be92930201994ab98f71c00caf04bcaea5ee2c4f899de8d8ce6af0d379d6a675737c827fd654edc8705053c27e26022e81c3b7f2dbec4d00ac0f888805ea4e20c309b1712171191e489d80c1dc69468752e8721b940ade2f32aed7a9ee3730d870a944eb4be6340d4052b1590f8e3daf61481058dd86afe7d6510afb0017f622cbfa2f00f29a3c88ee30208083223d3cc21f8204afc57e2bf07ff851195298ea215a8173455f39b63d9ade87f52a2203e90792deea37da0eaa244ea261897dc728e17c463f08ab89922a8c35016e215942ae15570257328947128946a563728805ca4a2693e9012a526dc944a952b12a69154866c6357fa8c24a77faea302cb986a296cceab883585046eaf387fdc4055d93ac692f5e2cc54c61dd6dfdbf3dc000556224696061e60babc1a4e224696aadc42600184352a69a53b89574c20b1a087637557ef14b6013567d8a59c08641ca316ae6f39e8f1674f1db1698494a981c6e5c464ee1f0077a3bb1b1108272c303f07ffb57fe69951d471109fec4abb62392251acfe06305cf488d5a441a08f2b1054afcc181a2e96528015dcdebc0af30cea1709cdcf10478855f887fe081894acee7b4a952a563f0139a98fca15340b5e2b701d502436f6f070452d91aba8e0d180f8256b555544ab5ab32a321708f23c9c2ee58d9ce8967dddddac3e502cf9b7fbde2d6cda8c76a7967ccaa87ba0542c1c406444f1fee141c748fa36cf882eccdda6b9ba3729d4f07ac1f29203414b5194a19e5581cae41128701baa8ab5d98de618b58775c4b10bf9375b834cee314e81e857dbf83ff00e07f18bab9a25939fc31fca35758ef894bc4d733c7c46502865f329050d81829276b9779c9995a31fe9e7883c01f4b02f54fbd44668a8788307a83061706e0c183986bf179fc591c4b83f9e20c5d3510dfc91c439a82ed098ba00718bb7daa050b5f5a13619a96658d0112f01a3b991463ccd528cbbc08e12bc859ef9993eb72a8e51d86f7825996fa3ff208909380e22728ab2228ad9ccc7264771e66202adcc40e0ed041448308d02ecbcd44c163ef6817f63fc30d252eafbd7f62592a216522ee30142ef5b6285c013c067355d9aae25ae1cde12de0f2458a29c0e2e025b100d52dbd2937e7a60fe293c3ac6e19209dc3f3643f37f8bffc71716576088316f6957624394cb02fe93b595e914096dfb942ecf7955c2421ef3fe398dec8b948de56585078be3fb8280afdbd66c356ab2dc20a03ab237a88e60eb8fb82b785ea6a0f10dddccd75060c3a41bdc1cb7982c1832e14f10bfc0597f9bc7e060f579f305707d4d512656ee9f59b38b5bb63daa0c8ff00f154b2e27f51ec4468a96ef880b6a0425050737014d08a3867d87b1c94434f6ce2000775844389c55cb9180d05658d42f065e096002d1c928dab31476c6901b66a5c68695ca0993022cee3d1004198166838aabbe028ba448d42dd8247134ddd82ae050e35520318f3fcc25555d5e510780759772a18f64b334f1937c05185636ce250a9ad9999361ed0505442000a442ba356d6138a1db4b140d8362558df50669bf696818c5bb887089868ea0c377eb2ce9a97ee76372fcb060fb9776d4f2625f999158aee5d60d77f8c732eb41e91b8daf48b574c525b8a0a9710004cf98d710d51e7a8ebd2f822b858ac853d235a017df32f6e57b62c798d5997e17b32d16ee3a7d44b9263ba6663dca5abfb8763f53d5626e981e3f7286c85574fcc55c08e0b206eaa06b50b8ff294361f30cf5f805da93c6cf52626aee1cef8cc6dc01d4c871175940abb802c4b0ddbfa12a28e46a4f69b5f366240359611329cabfd62025b6cdb0d32e9079a2e2d801d46ef84faaffb1f5d2f6359f9657d60160e82b2bad752e4f62e9e2ee757498bab22c70a574aad10dae038150850090208034d7921b7018b0a0af5a88bac3752a1cb9ce2515f093a6d4c2b4356aaf2e1d5ec8d07ec5655563bf42122548022cd5bb4bb3970510afcb6835751ab3362a7d72b28015435004c22b0a736dee38ce48c467c130959e59a482aee2ecc31489b79f6fdc2bd92d782adf616f808aca70f3050597065ccf733dcb7b97e7f0b96ccf72dadfe2e5f98faccf71bee2c7d7f0b1b8ac58a9a7117cc58b8c1517cc57315adcdc54b98d582ba9e26219b30e62741868cc3ae0b9a66b5450e9879600e9876841665768612acea1ea7ccb964b978fc28a16b37c00ff3510b05cbd720f68240d5a659e228aa9701aa842e8dbb838512f108fb0ba07910f97510c7e4a8006b1607b79b49a66dec29973445b62f193757af6885d86c65ff00625e5156b39fefde3d581e2a10b0bbd18b81533fc4a910db9bcd4b2938a98701063a25aac6effbb9684404a4c141505063ab42650d087916aefe6fccc0c809baadafe9f0c6931128c88d5b1417c9617b2ed2d600eeb11d23e50ccd3eb2aa5ef51920bf582a8219693627a349fe1a8e850e005ef8441e2084a842ff00f17f8b3f399647f0c7f0c41acc4735eb13a3f11ec971adaf06e58043c8bea3c9db140ff314f8293fb8f591e9b8e832714896599b2e205b83cb1e54469e609844ebfacd36f89ebbed318b855ff13ccf89e3fc4c98c3d25bc278536d21d181d52bc251c3f295d8f994bd83d6520aec45787c3fa9ec95dc9514b9fa8e4804a163198a33855455efa831e1585a4395de09506c60e084caabd654e1b5725405fa69eaef0054371c17a1cadf0264b836adb056dce76eff007982868033e6609c92dc418e0edadc0b2ac3c663b96f28948155d40a057109487bae55514a7150054e3d251565d38ee600edff007ea52a85472e9bb81c6451558f310652bab85734a8805a965a2871014e7e12527d0143114cce1258cb657172fab7d330ea986607687ab28abb3e650e3b094043f641692868ade7d20bc02ec387bc249c5d44f9fc3d537adbd1293d729e26d5645acf56223acca788b79a8d176c0a868e6064b0eae7f0dc8d390b3410aab63c1fd351a053c6698cae7aa9947c4af43512dc697842fb42ee826520dc6b20255cbf82895d5d3d47dcac29e73dfea39c16b1c9d47021b2c8a370ee4f3a1cd03732c3700e5896a1cac3c52b845bb60bdb07da0bb96efea0bb9e69e69fe04ee7ea5fbfa96ed9ea8cf28a491e84b2310a1b1d16bf2129be8efda30069ab93ea38fa811a6718fa9531ee25d6bb8df345bf107d7453d75fb7ebc66b585baa22db3942b42d310345fb77327eeaaa2d9975570a063010cbc1a9ccd5704a56b735add450b665dedce23519f0b3505bcbe4dddc5af1310abed1c486cb74fb885d6fbee5f74252917606f620df0d5475330061322ba56958b746ba1f51af994e9734d32ed9b8d2578510c8c8cced2f79abf6971506e897cdc5d41e0117f114c8e84fea5e087acbed82a28766419ff28c476d1af308e1724db2edd9aa05ca9d406241ab29f11542a0cb4fcb7f7320070040f313ab959a1a4aa62d36e18b616dcc4ac1a138f32f91505d9a17b66e647c4c41053e6561bae6f309015376f1082e0e5874d5d10352d7b313d006157f889c30038f44b147931ccbed513505c17dc4c0bb84526e01e60197d98775879b3dff003081e92fa7e0be9f8592c869c769e08f08d20bc76cc09ded5ff04a2d77a6e255669ff7312d377ac4b23bee27188d029ceee5db1c385c03b0aaaf7fea65cabd9140f1a1ea06c9bbcbe605996fbf04b9791f88021ba5805da1528170665db6aab5503e90b88692dcc20bc372e1e205318191cffb72b6e43d442c6651c457776407c2ea98a62d8544ced3105d855ba446c478a41f0ebcea3200f01e527bb9b1a0ed8a4c6bc414abf5961b1e875309698bad4b37764be41a394585b367c4aace1eaca2307aa195572628e7d66271353214ca5b540bce61dbb6e6a834e989616f759b9836b0798b0cfd40e8cf994993d3c4618e6f77087a35675d454515c0618d6f40ed06923c744db8e916f4028a25ee967cc5a15c40b437bcc12ae8f2dc0f20712d5403c12fcc2aea09dc121e50a83e21e104e228490080acc3ce5678906cb42452de71eb89b29eeeb823e6f12caa87a5c4e2d03366586b2bb71b9d2e26cde4ee50b4040f31d2b14b05351790bcea529d272f58f645f674c15b617654d45bcd2cd51981aeea005b165cb02f0bb971c97132a0aeef98a500be7108177bfd44261f0544ef5e211a80764417802bfde63890aa014c756bde6b05f70d607bc3391f887d946c3997a223bbb96c69ba3129b495b4be07ddf0744b10e0ee64531109d0f3157e0251c8ea261652e71a7b802d8dbc712a079e73034b3412a5b82621042db79820b70d60c4045c76ae60b02ef75ccb980b4114032ec88d6c732838439097652d3c56a2a5aa3c9c4066e8d244dddb92eaa64baf16162be9f3f5101ac401b7cc414bb56ebdce261cae9a3a97fa1b8e850f289af73db9abe632b9e822ba55173598ad032bb55ef2f0b72cefda0b05a85f50b829afb82dc0c8f87cc3d60f504ee103060101d4b21d48a74543a483752d1f800c75c4aa02a06ea9ff00ac18a343398fb33e44b6ca470dca16bf315162c1b6e0a7199562e78371e052fb31b5aa0852af0665f4f40e009b85b17b79813006eaef31a76dd3513783ef38bbee2e950294f5c3810c633155cefd3c40c5a1497bcc7141c15338e4356c2b17040af174402234aa8d9150a62d1c58e697d83361c6602aaac02b7eaae206b7293530720f98ac91f840669f704880f41e2c7f626277dd446bdf7f512a4472364af5a81d46749b7cc4d630b594a600197dc488a3316a8bd586aae3e63f7cb39228a58f0066b17a1ea23b97e880d380ce371f22ab8a97ac0379a35292955fa20c833c240ba07989320e6d12e175d571034a8e550c55eb8bcd4c8532bfc73385b289e8ff0054402e14a03ddbef7f716e374139d4ea20e0f45648d0014ba23deb3eea89154059895eb0c10850bb3f50e8cad66374ca536adcb2423c4575a8aa18fc4a5013630f9586f9848fb82bc40aaac897a8366c7b43c305ee17dc2e0301842056d03cc2bb851e621b6bc5cc2e2bcdb2cb06c92bb165a176d8a884d5f98f2bcefc4d6cd4f44ac6a35c11a091703547075e5ce88466740a1aa038b68fbdc0d9ec6f2ae73e72f30646db6703c40459435e7980b820cd05face2d1d23701cc3605ef8865aa22d616ba82ad9d512da172e62216388806894b02ed3766ba98fc9bba80bd8ca1af982e915bce7b3928786d96a06a35c6c4d23c9a94fc0e175c2cec73e9d91f03e272f2f3155c31281283acc25fb965d616fe93224001a53a7ebe257eb46832ba07f119068dbe2be8977e669b324221596cab23ab444683352a4801b76d7985c79d5d142bec95c09b8f19fec81051160e08120bd8d3c442c8250ecf0dc45797b4824ea3988d59f240def06b12ccaa4b8d4be4c8bfccd6b6f386288065a332204142956a5358845868ce39e62a880c7cd95c376b0dc951f1b80dfde3d6283a2d6e98d4060a0ca57fd8d8a20b9befd31188b32e9077666a97bd56e5107602fa57fbe23ad169a6fe65e39fcb89f598d8ad38b1af520058dc0ea042f51db2905ea142dfa4a0633e605dce4181a841840250750103175cd414fd6773e83a9711355aa0ea8e7d5af48f3dacddf309fb6d623b0d37ba30f409dbb893c47842bfecb737a36f51ec7e7e40e4fb3cd43c20800a00d63821240bd4646fc8fba63817db404bd507bb0ad91c9b4ee0df0455cad35729bc38c626e5c28547a97a89beeed8a964514ad4d26d8ac18ad82f04f3198d99ca815f5cfdcba208f14e9a103e1adf858ded6d772930ecf27500972ddbdc5f6d3ce078a97a013d8c0210503ddc6a0c7b90b45fa04411442e2fa5930dce2cc742277d3e9e6f0542c57efa9602b056f2caead8da3b31ff7ea0470629cd53a7c40162a293567eb5e9c442b771c61b17cd87de2546188ac50bf79214676b9fe2160070d9c7cfbf1d415083a39adbfeb89985c5695d54b55576c13190604cbed1a1ba5950444fe902485bdc5b633c28445105def03eb02ba5c3d5f3db9ee554cb28ba6c6ff008f8998440db875eb83ea63018ea380a56b644a18154156f70d18def7142e501ce7b661240d29611a5421a76902a432bdd5caaa42b6358f9dc334306e09b06d1984ff0022082f0c14a1dc3f710280859d30dd545d10859dccb4cb57305dc10ee5bb83e29603960a1d0281db83a8cc296e4236c0705c4c1326939991a4c7570c98c4c25d05eb3b941dd69a1d819611495613f952d7c05c735ce07ca35e76deb4430271e389ed1c1c955b2d3f50598dbca2cc616a617a87acc701ac269f319caa7e602428650416733352adc4144799541f09ad38dccdba388335d31a66f1c4a71ce15da2e5b51351a55fd46ad01ed2286f00247b90ebe2528c3372d7bce41c0f10edb30de0604ac12f5570bd9653ece1b1da581a5749c33175bf58a6a9d47b963a552a2174f2838aa3db821cc85db5cc7c01c260a0bf387d667d05386a2b2a10c5f503814a551c4229a334a31506ab50f9f98f198a9b7e60c012c8b3305c2023a8aacd7adc036865bd471db2b0adc1a97e0328a546a889099165687a8e5b69f44c4608b419631a968a8f6a4ab032e43f6cc8d015c1bee82e26125001ab38ff007a4151bb872f112b03caa20e8414af2df3eccbb08a283cdc39228ae1effeee32a011acb1044b04c16ca79a85972aaa3276fbc40db9c879ce07d664c056b07ee1e8a699f10e58f9825315b328e99d9ed00be200d66017a80e253b80558c0a829db05ea58d8fc412c1e4b551e3b13871eb2a74a68c2bd7d89b6370b75362c552cc0d8af488d544ca1aa545e0f47471f2890faa3e35aaaf015e2f32c15879f7ef3cc13a85b454b7b82f882a56805bf7f78232904001e8beb8ee0bd3219cbf71055542abaff54e78176e22983d0964aa3063c414116585f6dc520e077514a8e25ac4048a43aae625ba37e92e4315cc20ec3063534a481cefe517e2349b825840f66d4f132adfa4c5133cd1330ad51c9f5cf5f131cb22aa14d52c371ab0aac34bd7461e7adf8821a85398b686109ae05df12a3edbe9bc6bde39c650ca40447aa187a6081502ca6208215b1c2fd616025f6fd4174096a95dc0568e141c4da1b78b6a239507166db88a0a365667f69db081687945552990e0f58247580f6cfccb85a2334f2c770aa5d9bf996a8145593473876f3732c0036397826416d595284edb4ad9bcf671c4ed30c77c31a4404d62baf9bf983cab8a34bb3e7ea588ab0a5f67dfd437994bac992bfde9141016534cb209c0398c675315641043e125139391d3dcaa828cd5190288b8f129e3ea58cdd7a4cbd278218f494bdfc2006c5622e821d107a41d960e27a8f9867c4374d2380dc78046b29fc521066a8b5f1b8c500572be66002674ca169777329abb8bb5acb6d7436f5067083a795d5f198cb9b03c5f6f6eb3e253b67faa9ae1065cbc1183093a02dfa865102ab76965f7659d4e4d957380f58070bced85e2a25b1243e4fd28c661a4e8a139f33dd13cc1e98add4074cf572c36a4b6ad3998290110ac1a9514e6b2c61c67e50f52873ffc8c0eac469cf5da53de177183319d30f0859c193862df19141c540a4a377ff90c146bc61beae0d4a30282ad75392440ac8d2791c9f1a8889e4d1576778cf911e6573881ab6fda5559b12ad8cf2731655b6152d7faf68b06dd53f65f388dd069581ba41d39c3ccc0c286f9b7c4b2e46cc4dc81dde60d0a4cb2ca31595959990d76b66bd226d05db02bab958343bb700c9dbb51af68d58c2c1d7f71b7be17fe4b01679c66312fb468f24a9680d246b801c3b955d05d46aa136da2ae30cb9e5e3106c32695ab2befb966a069b62dd1e76fc448843a0755dccec6312b9398dbf66525596e7ecf8860c8c2196f4414a92e325f9fb8dd811b49d9854ff750b08802edbf96600b6d4b9c442b58d4718b96897a4b6afd929bbb3e60f57f316347cc2de20302e16e609502b3996b50287a36b268060b1f2edfef5b2c8e448d1f3100f215cf72d60c16a731ad3bdcb3c9f352da17bd5b051805cbe894f3402bee3d2e3c33e1e0c6821ff9b05195c99710c36a94b5c36fb531a216ea97c4618bb36742f50175abd47fd5f12dc114732c01c1b9de31d4a7cd26a28b82f6c16b26a172e817046b03a20661b77326b8df88a945aa3e04c7d26241b4f1510ce40c60cbfef7946ac51c89679400f8e6540e043604b13c4168172baac79611055746a5984ec7492977e1bb0cdf72d9f263d183a1af16754e552c31750b382606cdfd40ad2c71dcbc6036e8c4b14a0cca604bac55de7a23cdee4317a9efc4d5aa55e2ab10ae55a81706601330169a3444102d02ae2ff88b1a90ba00fa835c6aa320f300e1eb2cc983ca5cb00722998e02a83d662d86cea659d80b4e65386381cbdcc0836a67cb1ccb193cc400b95b7e33fcc50ac2c073b5d7c4cc82975576e71f31b0aaa1d34bef0142f1780c6f5fc4b10b5505cdca1708878ebee24d9c2df38db77d7dcc958c84cdbb7e2e5a4551a65e7fa800fb4c0e23426d0cf4417810b6df8182960be920e851f6815d4f54c19fd411de61e1096535bf30b646856246b809c1fda53de64fe951763374027f7151e7c3b8699c26499c155dc50565e8710b4e425aad52fee5c2529889ab06fdea32a39e586d77e31e21ff00427ff5a56f294ad7d6757d13c896ff00ee08d46bf9c2592a8683e817ac4c44ad6d5ec978adbca75feb97865045cb5d4b5aaab78ee5d053bb62cd37c1d4b6f692f34a8533ee4c55daab8eae6a04573e18c761ef17682cd398b81bb97494b80c1c39e7fdc42a06f236fe42225aa29c95f172cfa20909b40f35bf7a6ca82e4402871a03c18d4a8a06068d9197306e2ead9796d371abb59938aeff007f329d6a54bc3e3c62195618855fb25b7a5e3780396cabd406777dc0e2111c0a6715c4a6ef7eb288b05e71111f132f2726aa65721a8a9cd106ba0fd40b6d5940efa888940d0ddfff007e6615ee66c1c416ec75becaf43fdb89c1d2b91c7cb026b814bb7cdc46ea868afdc25b004484c78bab8f206d3086341c97dc513abcc261b318eba85e3182d2f3151b2fa981006ea61a89ba946bfa87132a11342ebe310b51c1cd1b5ffbf5302821b07698b97002eeb4c8783efe622b0806553770456abb1a270a371a86b028f3a82a130dca8e06fb8b6ca4831829949487ca0cc50a5de6006ea6cc42b41f12b9ce6a1f6476f40a4f912c16a14e6c5adc6e052925800b40599ad865bd0e62bca242d603da5b3c59497eaf5da7f36130a401c00a03c557c4112b7eb28d3f530e46715129c98f588561f985f820b597513e17edcbdd702a08426957c5eae5da0407aebd530786dadaaffbff0051144f0d76f48628682f17dc2ee4656001855ca19e4c72ca6129fc4104266e5654a3752c61c7a4b40b77c250b2035e61b10a4c4ab282ced577e62065c40663c6eeabe2150f82a1a30e68065f79787c804c12d101dd70fb44bb2451ff007710ba1ae0c7ff0065815d2c7b5ffb1b11c02bd6387c9be6dcc776b16f54e9bd5799917eebe200752d9534685d420a05e463fcf332d1b5324ff75f70a390a42b0d7facf12b6d2dc74e05d2f7403d63239911183af44cf88eeb2500a73d19f96bc431b14188f451182a2ae8e60a839e2c94528bb94806ce5f12acb28e3b8bc82f4d4ad81972a660420d75fef7fa8da6b87312062347336b4bedf30af2b054dc055634d9cee601d7186b31d8d43746d1cc47d76f347fae3390530585ff00e47b28f53500b356bb4ffe634dd6196f9f6976cb662f865540c3a3885b0fb96ae6a1e2f985734bf328aba94410d5b041d41f52da16e4cfa6338806aff9865650d20a7bcb1a2d3dea045d05d2c43bc0750d5e909a3696dec66029306a17bd54b9e928516958962dc8ee108c000a28f1e38fe658a18f581bb453bb822d9bea29a2f482cdc30c620a9b258d4580e2e311c2b1f5a3f9830dbc8fa53fc909501e64070fa0cf4dec8f9fab79c19b3cd06e0bec0ba81a0d1b795897561ac477269d915a15d63109401c2fdc2f5e256e7467ccb146004bf3098bc84a657dd81792d5c44529f12a9ada97cebfded01005526856fea039e142f52b8cb3ede2288e6325b0b047ab66ab5352b430e0ebefea22421a1bcc0da40e8a86d0ece2a372bed2775b8fa3c9748b3c1ae4fd02cd2e929b0aeef10a8ddea189cb73328a6dbf33049110bf94c95d9871fea9620348a4fb2d561cdf113dbf29c1f0143e2fcc7c9db9f495acdab5ac4155952bd239b82f45c3714ec9a259a65a9964ae9b85a6da180e61581755566e65bb0c71526605348461a6cc1779a80e25affea51ba8568870aef5e674732860f50a4d5985de6cff0053981a0c738972179d55e2635005d5799a2c20d9e6376a557afa99c404d1d7fb1f112b0618af04395a9db57b42942ebd65174da710fd31428b6752ae521374b817f7179a8c6c1e9dfea21028b19974707b5fbc77aadd96bfdd4e0295ed82529e8461a0501957c771c60e2a2f02cfba4c9d4ddd7da5fc5fc4b8ac169c9d63bf68cda86704bef662cc306b8d04a755c7b467bf03f16e2221eca68f5d9f12e394b044bf4bdcce78a645229a28b7da3474f582294f985efe61ab6b1b9b9ec7e425d9329f7bfed2c88bf1cdfd0e10c0ab783a5afcac3e23344a0ab4a88ef37381887adc2dbca2606bd2265ca4b1cb6cebd615a68215b7b9ec0af4accbb9775479ee71e513b22447003eebfa31516ceabce4fe61adeef9947a785c5b207da51100ec335c4691142e23f05f987c766fd0dc17416ca3d6a3273b2e95a8b1eb0786b23533e331cf80d185e0701a659815069f51c4cbbe033b666554ab64e6e5eaa5b48b4fc47884d168b6b3a2ad7dd9556ce43367fae56b03e88b600701c400999c6772d1d9ff007f512027928f901fb8b4202dcd86af40bb82a5c1755b6a5814ae542c2295163cef3142e6b74531ca1ab3254508553cee08eda5dd3e223242d00e5e612ec44af4d7bc121cbc1d4b60ae304aa62dd06bfd5f738594b37e51963cba772ca2cae5b3fdce65443a1e2744db7831b817d4b2bbfbb06716f5801cce2dbe66334205a470626d8d6bc3e90348601157d900b300f2f5320dca0b17d81bb54f47f12812b6535e871fb95e801c687aacbcdaa236bb3d57f5075b2616cfcc6281556798ed759bdcc00219a15d4cc0d31ca42e064c1e2fd4e629417498e7f703810d00c7fbd263b36804f86bea34889b35bee21f53bf35a1f770146161283e4721e8b03d1a2997a7b9960d0be2fee376a44bc919e295c10c0f6e80bafefe62ae61b78942baea0b214f7c74dea58aab942c5582598a701bd94d4ba965b77cc7046eafee589eb1cf11d15587d8ff009f72bdf447b07ed8d7b4f5a4a3f632a161b5630e8dad0ba9a01be0cbc76fea22617c0dc56ac12b07aadff78804af91799cf6f2e08654a1917fecc460a509aea967f1c4241d5083d05d2f403c4b02d0f343278c6252514010365898053f72e41a703fdf72f1589daf372a8346037bf9855a1b5ee64d6714415c8a554196ceaad80c40dd8608a7419c9a10f0fc82ff0054b5ab4b5744afc52cbc115b1e9b96a5770683834ea5c143475284a4d23516917a28cc55aa3858a00c61c97515317b5ea69522dadca1b56a57bdff00c88b48355b9b47772b29c9cbbff339b7d01fb19c60df93fa8d9afd4c0b3fd4fe11176f224ff9a66434df922aa4d7599c92721e9ee020c665a7daebc7cce0d2156ebb7a1eec194136561d671e9288def54ebd4216edb9bafa37f105c4a6ff005adbef50cab3ff0004dfbdbe625a820d5fb7a45560aec943b5bb29d671f01f7122a021f3169726061566a1029ad5ba8510b5f64d8a9d5b2815cdea068c8182b70de9a84f7dfc4f4887a1edef44454dabc564423c402478be224526763c21b61ef20f3c4d4e14097d95a52695ee5f37a71e66dd6fb9bc4e6a36386e5ba975b32ea343500462582be14e22ad22acbcbde2450ecac1c6295558afa543b14c0f70bbaa260f106a75545e66bc343d4775b59168f98652bbec4c4887139064bbb9d8db9b9934df5cd47391bb2ea21ba50d2aa6fbfdc40e587406f874ab37798045deba4da344e4a2561d06e2875b94301b147457fc7880ecbf043fdc3ea87565ff00b16c56d56751002cefbf795697b8bef138886cd6622829658708e1545d8f30cc09ec7bc1119aeb6608100705ee30d039c3d7a4a9a0b6d36998f8d53004dd2af552830c015efde724a7a2e0c8c186c213450abb057a7712f45bbbc7fb9f98ca84cd9dca554c573b8de52af12949a08308f442d96559326f5d4a36a7d48eee0e907d9495ef71157bf1fea23a90b367f457dc5e6e9d147a389674082a3d6a062fcb7eb2ceeceaa3403865799744d8cce0364c4e5c05ee5e8d1d15c4c4bc3764d0718d4bb2eadc92cb2fb33312eb6ac336ca844b3ebf89dce5ba737996268544be22dfd84df36c6241809d7d4a11aa00d6ff00ded0349240ca8952d89341ef47cee721806bde00e7189ba8762f0f68da645e19607564b376b7b8bd3899fbec8d646b894a0bb21a2d2fb896846f6b0d8476a1570074ff0055f129d05540b978959be22f24f1b4350fb57c40c8404a038a806f7b6964c552b1844968ab719844740801776b05e08ac60bb2a2ce489a10d20341ccb58e5031bb942ac781f723bad52c4702c385a638360f81814d4a14fd1b8b1a88f47978f0feb23a4bd170fec39dc0ce0f55656faf488586c5f473937f52d014ca0a41ab59d057fd4309771ff117556a99be0884d4a53154a1559877a02671b88a6ed0872f0c1c85afa94c0316788269870ce79ffefcc557476d56a16ae4d5255456b28301a9e89c8222696cd8f3bfe6a356ca031e1ff2442cd2aa36f88ae4557c1fef11816e035e652e84c37c750950d3637ce6865bf8105e33b85dbc6fc44840de17cebee1e7820363a6d9f88d8b0779817516f170e87dbc4b65506a882720abb2f98ae416c4326cab1b8f673b3a8614ec4d66e64016da964e15242ac12b9b3301ae81ac3349ff0089c37819a405d2ee966f71ca81571710bd5a63022300f000fe65061b4c592e39059653ed2e0b0357bc7fafe63610286edc8fea210a6853b723e20f5eb19137e48bbdbdcd5e9ef4928e5ac0e80afee35573cae624a828dd440d60cb42999642520658df32dc8a82d5ca16ee02da43c22c963df3f1284c91215a66ff0067bc7447144d9a1be218444025570405090dd19f8944395d4a6481e915d4cba311cc21ad8ee3925b8ba6f513961e731c4c274ee5ac60edbb8f1629774a78a8c521b1398842685e86e2151edd216d69180d474741acae9e58ad6ce4b86acad7ee3576ed58f874f4cfcb0fa4914c2f03bf27eb13c4905aa20a63b232a8dc2af994c05e8a88aa6e9caa15a1a974330e395bc28f6a99d0a0682e642ae8cb954cad15b46e398c20d7f9e931800290fb4b9da5d4c082ca5a08ae359962c20bbcff00ab12f4ac2dbc2e1222c77f4dff00f2044762bfdecfd4c562694bdc6955828adeed9467651ad9fe3ee37d10a7c408a6be9b955d82bbc41052939a54c25b6824f775f10244170e87bf2fbdc42c092d4ad70bd47154d9545ddca9658fa4660d25ecc3ba65252b0f1a858e4d6c9662837733dab846740d26456ed06cddf2820add38b7882a2b45107d0960836f641b603a31095d4bcdc4b5d2c69b8af09852a39c26186b91c5b1cf2c996ee5702fb4a99797e75790fe0cb934a54be5f6e097448ada01ae0a01cf6378940b2b3d1646dfeccb1645adcf8857c034750acd0d6e89cc1d5371b4e5cac02273fb95e00f11055179839230f31416e6596847a41bb62f96216076005a387e6648144a2466f38f6e798c7eac418a6eaf35e25b645779a1943d11bb82b8ce7b44e41adb152e673603ef3baeb40a297b7cc10b517c1fd332006e4c3e3370342c34ad1e37012e3672b3f1d4c642ca059f3ff21b52e45a82b8653b87acc28aa2fd573ca374c0f35d460dfa3fdc0d683c8562332641c89c80e7ff0091573f90aa96215641aa806e1d064ff110f40b4dff00981d22fc05c231e19525fa5fed2c9c3c36f6e2514f34b4165f32ddd32f5b62a7ae421296e6eac77dc0b52e31808f30b81710dcd62dfcccb5ce5eb7c450c8505db716976749d450dd51fe7dfd4bb608fa2084b6cf641627b9cca47045ea58ecd0ba253e9750c05e9ba456caf8d90e06574d3860a8d1dc4ad611e664ed6a8ae250acaae69d10e9dad2332c6691cf9886ca5f31059828f107073c92e80abbe10405a1cdc48a3bdf99990b1515515fa31820784d186aa89b888b5528a38233897c42b4021b490c14b6b6566b1ff3ee60029bc384978342933ff52ceb41185044f81c432b11c1eb5bfdc6080031e6c527ba32b8daba55ad62dd802d096982c69559566d229d5162a703ccaacd44c38352c790b5ba5e1f67301a42d2d881b655c8c847c75161776327cc25605bff0002bbff00a4741f04d6afb772d407c9dc25e6336cb9b40753668578b5add3c6afd26016865a2e572aa6d0b3ee722dae050cddd5c1c8f895488843056880d60ab2c853c457a01a1ff6240b34e4afb882cde2f0ff00531a0bda60617a508d5aaefba82b056896a2944bf27f94545f4aff00822a828caa5510bb6106841a2d799867499a167af509d75564fac6e0a5b7672772b822ee997e750d7e556ddb7038b4d1fe5cab80015ac5f57ff63b4eb7a6abaee3d72e347abc4170dbb8c0002de397b659b5914d7cc51472a4d9056ba6f17c4b915785d5ff00b7f52b901388645ba605e16f17c7ff007a8fdc134a84acc718ec8d812aa5c150cb12860f82204043d450398428536aee20a2c06df495176585c30b402d48095545f937288853171342e0621903708ac998842b1e2641113988a840e21208696aea14015dd6095029073729173f48d366fd262d733cdfac685882dd4762e529a15e8980414accc008c0288b236a65a3b668712c2f05599984ad941ba9c437c21d026e174b7c8b8c5a96cc02be57c4c8a319c6060469ab3b8b9239f5956f3e198920aaa0ee6d6f3a8e5d4cabf825082c0fee55b9bdb981cefdb3d46db96f50f601e187000f4856c12f58ba8a36cc119bac00731a2f8f49c4202a95a2faddfcc17b5b4d0afaa98760328cdc79af26cb6bc571ed52c96ef5a62384d091b662804187e9bcc576d651909545f6e128bf594c13bc687de6fa2836a3baa8b817c1571ed7101142257c91542c0e6c9e3feced0029c77b8d966c52f0fba8a0261bc8adddaebda53dac1a53173d6e6f10646f6c661150e41178d54257c55d75f517115cac5b1c73d6d3cf128319744b8343bca90a0c0f7759fb9b8b43d4cc02d9af1d4001a5a352d602b698c2d7822d8152d5e4704cbca995e3d210d7783b3898b404abac932b61e4b42f772b265284e2085ab1b5e20bccb8acc2b5e26182ff00705ad5354d732907c9ee50083b6e162d810c434511b6388a062381942f046eae1b350136507825d282dde1664a95d8834aea8dbb8a0cba95c40d80942f32e15d30b70c14e572c50bbbdf8973239db5b845ea566169a70ea299b65b80201b6ed834c8662afbd6e5225083bae2012374e0f10b542656b9a8bb7572c72d11c2f17abbb63f8555b74dfaca6177a12cb46d44e2ae398d5cc89abe8cf8965aa78b6098c577056dc81f4b864892ae0e03a0c7bc130623d95e36f980543be251797de07496cb76617920890dcf800adf74302c5c1d6024b94598c17fc4b3604e1d20e5e250b8d4ae8d8d6a00a9abd704b4176f52e1421a003afb6662a77a6e57d91a45d04325fc936c610b540eb53bb559a05ad4a8b4b34db5fb57ee2d0ec6a578df883000ad83a381bb23735acdd7fbe22d4285ff009c4c44401026cfa69afe2e38141a6aae5e16a94563ad47306ec5edeac1bed6da6d710ca9978b5e3512d205c1894ea10e2e330581e79883577c185736ef9c414cd709a312f2cf74c2fb8e73846349c2315cc6a55360314db152c70515cfbc010abb3d3f98f735551b8714d016eded01aa874f98c1d11e5fa6211550b82d4b2430e5620ba5453702bc4c9d083df10504b068ea5256c6db986ef11064d6fccede9e08eed5570c70f26fbe23582556e01238e26c80f309601afa752c10e168f110d0bf2946d814cbdc56e8c1c5ea741d338ff5c37b68f5c4b119a7707270e9e214b0dc416e17130543e7132ae0b8752e22752fc39fb250da1dc55a3bc2fb0517e61375c136e15d4b05835cc2a1f51778a854c3e9179cfc46c6df897ce4b187ac6b18ba2400d977b87034897857496ff1053085f211864f884a46be5892a58be4866200655e4fb1736900f6c2855fbc494a3755b978a073acfc44e81841577ecdfd4ae29b2b02be2e51424302cfcca0a1f6aff6e3905b052f87463d62c063853beb4094b896c629ed63ee648b0c2d2c5b10ad3ed734f56b2d9fd84b4834627be2e1b2e42dd9f350674206672434a7c058f5c4b609db3957acdb6e1b701f7286036c349dc0a8eaa8179aaa8f5499cb03d7531be282cad366a689ac2b3abd4b0341c023129599c2ea0ac2deef511658bdddc11912d5ce484b6a86e5080d1850a607b3d0a885a517566e201b037a99df2c351eb08b90727a7b45f051cd6dee5fc00f496a6065b81b295a351a59f312da2bd4cc2aa1cadcebc4cdd8e7cc381570bb0ee1682e4b54bc711b5d383962c105be7982568a7cc21e6af882c4d3cf3322f3bf12c208edd4c1836330daa87d62d5658de5e6a98b74ac64f10b987c4c4507ae214f2d9177abbc6e25bdde7ccc6c193170dbd59017580215e47fa3e255d78219c4d58bbafc0b071125cb351c83a398437a05681ef2d7503152eaa17d65352fab128487a10384a58657c4aea7b012fe60c187de1d3de0b77bed192dd8292a16eab3150b2e1b85beb153e0dd5f303a4060a349bf8c4a44c2d0ace0bc9f1028a815025979be54beaee5c1b2a853fdfd4b6c0fb189715f3281ed36b430294f8205d08602df454520cc1453075555386b56f254150bde7510eadc28721f8089bb830e4fab8530ce28bbf9a8135bdadd3984a9d158293ffb05282aec54d71759a8a020c670b1dddc40c74b5302ef152bda8b4b4abf350ad55d1b5e6c81771a5787ac059ea85dce7e34f72c52e92cc9a2b2c2bf659f10cfd39e30944cb44a338cbd6f9951706809f5b878318425fba412bcc2abfb962320bcf08325706204176bab12f3572e5e201752f12beaee6c11436083d804c06ad7ad6a6451e585821535a808fe512362e6c2b0bdaf1030eae55510d4c36e312d80e7888bc88c4aed6aa8a50f431a561434317dcc080d13a1677e23b537dc75638bee0ba37982b4cf98070c3e20256c6a01907bc752ab94ac2d5bb61d9cd4c4ca75985d00d4c587473292a81b0619d803ab20ed5bd089b0819e256568a2975e9fb960b69b18af0d5d3bcbfd9331a6758a8ba02dd4a2a0aed8a9354b45e55ee014195e78940669e23b21c9015b95de22d3c9bff7a43485c04eab0f7abf62230ceb9ee1c979f31786ad6218eede983c85c0e80bd5cbaad3ac134199a86ba8e6b44bc846b40d0b196fe1fa972a58f0a3e71462b889add470189febfa88d05e32295dff00ba8d005c056921b1c17a6a82c0bd9649ecbb956df52cfcc0893801c2752a602c55f1b8da0805e59fd42549c5517ff63b60811cb75eb05d81a643e3af88020869028ce73e9032852a15588c906e6edbd62fb2c8ab78c789613360a578ebb82822853b3d112f7b970f24b1c3fe78898ee732fea2e05466fbc4ac6594687b55cce5b79737eb37176b126423ff00d672ca48ece4aaf9ff009060b58e1a25a18dd89e2180fdb081d717e20dcdb675bfed8d82560a6fdd9b36b4dea34934c4d511f974e56ac2d153975ffd9a96d5bc1fc4160dd2db9bb82f7803a968f885204b6a7765060b436c2e225406188852aa83072dee6db3dee66ba69e656a155c472847a5d40e605d0425280839b3245ac98d79950c78a8c50bb25a9b5d4acab84f88bb0565c6264eeeb68403976e66500bac547497b4f10693e23fab9b1bb59112d076045a872a3d52c728b2c92c51ba2b656ff99bfc732edaea2dec5d57702fb85d789b4af5886a8836d6e6592f35dca2adb1e602d5471e1e2be7ea0db09f32b722ef2f78611e4329e952bdb3f12936d8730145702d836a0cd2294fbc6529768a409ed708daafc2112cda59754623b0cb40a85a7f36ca45406fd7ac2a46d958ca0df308800a2a2bb78865a0a4b41669ca8dfdcc983436ba4e2fd25a7146bcf4856d05ec3f4dccb182c55ff3515dc5cd9957afcfccbd5525927db398143ef6b6c7ea0d67af62c85ab3a2de98c4ede609588419d30fbca5ee1b38f1124d135aee1b8a336554a91bae961e7e6be216b276699f42ee1dcb2ec695a8ba36dd99643d47051a05c3a1469a8d6e576ae60176370aafb997c380832564ddd662e42c187b94d536e5384aec9634b131ff00662ecddf9cc51156755c419b1f980ef1cf8976764beef52c70e273757e929b1612ecee2e9347a86541ceb12dba3888387b4f055bf3012b39c6603b3c2f1105a3c9b82d32e8ea28500b2a9b2346a1c4191d5f300a6eafee1d688db59dcaab302f17abc710516ad2e8837478bc90a1f68296ac10d4b1355cd39cf50d0c6d9b0cfd4292a15cf4c5790b2b71428168e4a00629efff008f88b1a10a5f747df035754cb2a0f54c41bf6437983c254c2824bdc25c5fa11889079d6246a8e2ea13576977095564d6e5c967befd8f32980ee02357eb04236377076383a733715f4237428f4c60f9bd021ca45d721633b8d815c202a380db1b163c81a297c662e62e4a85f58f6f898fd5c1141b5dd75eaee00868c871bbabd7b532c30b6ab01ede6595961c0c27f1037ac015e1082de4514f0bad4661919da9f0b2e6e88f0fd54a613e3729707d1378e258def3b84448ded57bf99461179311034ac705150384a69713056a3842659aec641fb992c03dc98eb0dd080228532998a58ca954f1e665011d5cad6f8a2a0cb4b4373bcbeda8daf663a8d163359e88a64980a0e055fee1ce4ac4ae53dde6255179be220e13c748e4a0fa8d52c0692f11342b700d53e910084e1ba88a0585dd6238add7037303a886485eeb514c1be1988a3e60ec54e55d4732d7ab1a0e15027a950cd07da06425108952c1d98c46962083b883a7f33b83b57110176b8a1ce2f0f8963db708395265c2a65a13d66d4e0f339295e2e228a56aa159a2a5001438bcc18ad2c5ea5891843c591b616b9f246d40558f13071942ba1003577eb14551b0a160e08f7b19baa7bd40ae469ca015605af12e1b33279651ca54ec761e088737d440b7d41e7f5022ad4fb8d6588268e5a6586395db8efd2a395cc06f6bfec98610d68c25e5f531192216063e3c7cc62e264caf5ebdbee0029f25e861dc503606a631d1826ec9dd025bdf5dea0f2a94c0f32bcc03f172e67a94b2e9bfcf12d57a54c980bcd93f49f771b0bf6465f15e92ce1a8bb14ef0cc78f7b885a56dce7700d85d9f502b423decff0012a958e97b856eab12d8e2fe21a681692eac00a332e287dc156a2056ed2220f84ccd6d00a60b2109ce236806c6eb5ed06ad1e39956b6686f118362c1b430ce46a25410781b946c754f895100ceaa0b394ed2e7b5540b158a869470752edfb18cc6c028aeaa640159ee2645a15c4076863be0850c39d866280a4473e90e27e6029c899acf78a887141af3032cda3a8296a202a9169930bf10ceb29f445fd28798d71a88e5603b10e7e6df7867b05ca0ab80aae123429b84559019e0e5f7fd417878dcdcb2320eea5956790dc307eee60b28b606434ff1f102dc8ac6a552b96aa2220cf626e1277482102d371ebb8f98684693814c3eb94f882700557c6abd65c810b05b3a035cefbe225d5cc306fe0f6b97e9294627ba1fddc01d6d4189eb82b199a6b9ea0fd4b8421b967e2a57fe128250d23ee20877aaedef36b31586e5eb94e87d4352857332421d114050668f12db40c5a310de3114d99e222c7ca5c782d52e1ee2aa, 'andres', 'ocambo');
INSERT INTO `users` (`ID_utente`, `username`, `password`, `email`, `avatar`, `nome`, `cognome`) VALUES
(4, 'conso', '1313dc2c2a4ca110a4038ce3115c1509fd30ffbb', 'teoconso73@gmail.com', 0xffd8ffe000104a46494600010100000100010000ffdb00840009060710101010100f10150f0f100f100f150f15100f0f0f100f1512161615151516181d2822181a251d151521312125292b2e2e2e171f3338332d37282d2e2b010a0a0a0e0d0e1a1010172d251e222d2d2d2f2d2d2d2d2d2d2d2b2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2b2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2bffc000110800cc00cc03011100021101031101ffc4001c0000010501010100000000000000000000000102030405060708ffc40043100001030202060607050702070000000001000203041112210513314151610622718191a10723324252b1d133536292c114437282a2e1f0152434446473b2b3c2ffc4001a010100020301000000000000000000000000010402030506ffc4002f1101000202010301080104020300000000000102031104122131410513223251617181b1234291a11433155253ffda000c03010002110311003f00f7140201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040201008040206bde00b92001bc900289988f298899f10a12e9ca46e4ea8881e1ac69f92d76cf8e3cd9bebc5cd6f149427a4f443fe61bfd47f4587fcac3ff00b367fe3f93ff00ce4e6f48e88dbfdcc62fc5c1bf3d8a63918e7c598db859ebe692d082a63905d8f6bc716b9ae1e4b6c5a27c4abda96af984ab26210080402010080402010080402010080402010239c00b936037ee5133a2236e6f4a74ce9e2bb62bd43c7c2408efcdff004baa9979b4a768ef2e9f1fd979b2f79ed1f772f5bd2eac96f67085bc1833fcc7fb2a17e6e4b78ecec61f64e0a7cddff2c49e57486f239d21e2e717fcd55b5ad6f32e8531531c6ab5d1a0058b615035ed041045c1da0ec214c4ebc226226352cc9257523c389269dc40d65ceb29dc765ddb4b09dfbafc3659ac4648eddadfca95e670ceadde93fe9d3d0f48aae2b6098b9bf0bfd637cf3f34af2b2d3b6d193d9fc7cb1be9d7e1d368be9cb1d66d4b3567ef1b7747e1b479abb8b9f59ed78d391c8f63debdf1cee3fdbaba5aa8e5687c4f6c8c3b1cd21c3c95eada2d1b89722f4b527568d4a659310804020100804020100804020100832f4e69c86919790dde41c310231bfe839ad39b3571c7759e3716f9edaac76fabcc6afa692e93d6b700821825743ab6bdcf3238004b9e6c32cec05b8edddcfe665b4c447d61dbf6671694b5a67bcc4e9542a0ec8ba24b7440ba848ba905d4064ac6bdae6b8626b816969d85a768595666b3b8617ac5e26b2cad0b33a37c94921bba2eb46e3b5f4e7d93cc8f64f72b19ab16ac648f5f3f953e2de6969c36f4f1f86baacbc9f47d7cb4efc70bcb1dbc6d6bbf886f5b31e5b639dd65a33f1f1e6aeaf0f41e8e74b23a9b472da29cfbb7ea487f013f239f6aeb60e5572769ed2f35ccf675f07c55ef5748adb9c1008040201008040201008041cff4a7a4aca46e06d9f50e6ddacbe4d07639fcb96fb2adc8e44638d7aaf70f856cf6dcf6afd5e675152f964324ae2f91db5c7c80e0392e35ef369dcbd4e2c55c75e9ac76737a09fababad84e57904c0710e68b9f256b3c6f156ca1c4b7467c94fbedd15d5275362e86c5d0d8ba9362ea0174364ba946d8fd21f5661ab1b607e17f3824eabafd8482acf1e7aa271cfaa8f323a26b9a3d3f896bb5f71755e6352bb5b44c6e0b7509d9a478fea8898898d4bb9e88f4b6e5b4f54eeb64d8e63ef706bf9f3dfdaba9c6e56fe1bbcffb43d9dd3fd4c71dbd61dc2e838a100804020100804020106374a34e368e12fc9d2bbab1b0fbcee26db86d2b467cd18ebb5ae271a73dfa7d3d5e513d43e47ba491d89ef389ce3b49fd3b1716d69b4ee5eb31e3ae3ac56be20cbac59b9dd3b782b29aa47b120fd9a43b8677613e36ec0aee1f8f15a9eb1ddcbe57f4b914cbe93da5d1872a5a75224b750917405d0174097526c5d421155c2248df1bb30f639a7bc2ce93d36896196b17a4d6543a35505f4ec0e377c7785dc6f19c39f700b6f26babefebdd5f857de2d4fa76ff000d4bad0b9b174410841e83d07e92eb40a59ddeb5a3a8f3fbd681b09f887985d5e2723aa3a6de5e73da3c2f773ef291da7fd3b2579c9080402010080402064d2b58d73dc435ad05c5c4d80681724a899d46d358999d43c734fe977564ee98e4cf6236e7d5881cb2e2769fecb899f2ce4b6deb387c78c18e2bebeacf05695ad96e8967e9fa2d7d34918f6ed899ff0071b9b7e9deb760bf45e2557978bdee2988f26746b486be9d8e3ed0eab86f0e191ff39a9e463e9ba3859bde6289f56a5d575b17405d017526c5d0d8ba1b17418ba2ceaeaeae2d81ce64e3b1e2cefea1e6ad65f8b156dfa50c1f067bd3f7fe5b575557c97405d02c72b98e6bd870bd8439ae1b4386c2a6b3359dc30bd62f59acf897b074734b36ae9d928b077b2f6fc320da3b378ed5dcc39232536f25c9c138724d5a8b6ab84020100804020e2bd25e95c113299a7ad31c4fe5134efed361dc552e664d57a63d5d5f65e0eabfbc9f11fcbcec15cb7a0d96e891743650507354eefd92bdf1ec8aabd6b386b3df1db95fc15db7f570f57ac39549f71c99a7a5bbc3a5baa2eaec5d49b1744ec5d017500ba02ea462d5752be177dec12477e6d21e3e4acd3be198fa39f93e1e5567eb1a6d5d555f175212e8025074de8fb4aea6a752e3eaea05b9095bec9ef171e0ae70f274dba7eae5fb53075e3eb8f30f525d579d08040201008041e2bd27d23fb4d64d20376876a99c30332cbb4dcf7ae367bf5de65ea7858bdde1886682b42d96e80ba02e832ba4f4665831b3ed603ae671bb7323c0792b1c6bf4db53e254f9d8a6f8faabe63bace86af13c2c906f198e0778f15866c7d16986de3668cb8e2cbb75a5605d485ba805d017405d0db1b4ee52d1bf84e5bf9987e8ad71fbd6d1f651e676bd2df76c02ab2eec5d122e86c9744103cb48734e1735c1cd3c1c0dc1f15313a9dc22d1168989f57b8687ae1514f0cc3f791b5e470711d61dc6e3b977296eaac4bc865a745e6bf45c59b58402010082869eacd452d44bb0c70bdc3f8b0f57cecb0c96e9accb6e1a75e48afdde1910b003800170deb3692e89d8ba2765ba02e814141cd521fd92b1d0ec86a09963e01def37cbe5c55cbff571f57ac3978e7fe3e79a7a5bc3a5baa6ea6c5d017405d41b25d482e86d8fd27f6203f0d5427c4dbf55678de663eca3cef9627ef1fcb5c15597765ba2762e86c97446c85db3b429265e9be8beb71d23e23b6195c3f95c310f99f05d3e1db74d3cf7b4e9acbd5f5764adb9c100804020e5bd24ce5940f00db59246ced18813f255f933ac72bbc0aef347d9e4a0ae4bd19c0a05ba245d0d8ba1b17436cde90d019e1383eda23ac8cefc43777ecf05bf8f93a2da9f12abccc3ef31ee3cc7783b4169113c2d76c70eab87070da1639b1f4593c5cfef69bf568dd695917526c97405d017436c9e939f50394d0ffec0b7f1be7fd4a9f3bfebfdc7f2d569c82d33e56ebe0b750925d01740c7bb360e2ef2009f9d94c43199efa771e89e7b4f551fc714520fe47381ff00cc782bbc29ef30e57b563b567f2f4c5d0714201008041c57a5675a92217db50defeab8aa9cbf921d1f667fdb3f879782b9aeeecb74496e80ba02e86c5d01744b9d9ef47578c654f5273e0c9be87f5e4ae47f571ebd61ccb6f8f9f7fdb67441d71754f4e944ecb744ec97440ba05ba2591d273ea00e33423fac2dfc6f9ff52a7ceffaff0071fcb55a720b44f95aaf82dd124ba02e82206ef3c1adc3fcce373e41be2b2d6a186f76fc3b0f45ceff007efe74b279491ab3c4f99cff0069f7c70f595d270c20100811071fe94e206843be09e33e3707e6ab72a3745ef67db5975f579382b9aefeceba80b7448ba05ba04ba02e82b693a36cf13e276571769f85e3305678af34b6da73e28cb49ab3fa3b5ce735d0cb94d11c0e1c6db0f7adbc8a46faa3c4b471334cc745bcc366eabae96e812e80ba1b64f495deae21c6a611fd4ac71e3e29fc297367e088fbc7f2d5055795c82dd13b25d106be40d05cec800493c005311b44cea368e00436eec9ce38dc3813bbb858772cade58d3c7e5da7a2a6deba43b9b4afee2648edf22ac7123e2973fda53f0447ddeb2ba2e28402044020e7fa7b4facd1d5395cb1825fc8438f902b4e78de3959e25ba73565e26d76de46cb97a7a18938150c8b740b74362e80ba02e80c486d87a7a0313db5918cdb66cad1ef47b01eecbc95ac36ea8f773fa50e55271da3357f6d7a5a96c8c0f69b87006eabdab359d4ae63c917ac5a12dd62cf62e80ba0c9e909ca9c7fd4c7faab1c7f5fc29f327b57f2d605575c1740974104a71b833dd167bfb2fd56f79cfb1bcd6c88d46daad3d56e94a5cb06cdbd03d0fc177d64a46e822079f5dce1e6c577891e65c9f69dbe58fcbd2d5d728201022010455503648df1bc5db231cc238b5c083f35131b84d6753b7ceb590be07bd927b50b8c32f634901ffe6e3c972ba7bcd65e8e2fb88bc783c1584c36c496ea13b174362e86c5d0d8ba03121b21b104117041046e20a98ed3b44c44c6a58142f34939a777d8bc9744edd63996f6ff009bd5abc465a75479f573f15a7064f773e27c37f12a9a74765c486c0721b657481d6101e1531f982158e3fafe14f97e2bf96a8764abae4496e86d1cd3616ded73b0377b9c7600b2ad772c6d6e98360661199bbdc713cee2f3c390d83904b4ee7b2295d477f252e5097b27a32a1d568f8de475a773a73cc1366ff480ba5c7af4d1c2e6e4ebcb3f6756b7aa0405d025d0080ba0f1ef4a3a3b515a2768f5754cc57b65ad6755e0f68c07c782a1c8a6adb763839374e99f47118b556fb93b1df747e177e1e0776c5ab5d7f95adfbb9fb7f0b3896bd3744971283631203121b1890189017414f4ad109e32cd8f07131df0bc7d56dc57e89fb3472317bdaebd63c2be84d205ed2c93ab2c670b9bcc2cb363d4ee3c4b0e366ea8e9b79869e25a74b5b1890db3ba400981ce1998dcc907f2b813e575b707cfa55e5c6f1efe9a5f8250e68233045c1e4762d768d4e96296dd624f73c0cc9b002e4ee014446d94cea1043d622470b0b1d5b4e5607df2389f21dab3b768e986aaeed3d53fa4a5cb06cda6d1d42faa9a3a78f27cae0cbfc23de7770b9ee5952bd53a6bcb922959b4be86a685b1b191b061631ad6346e0d68b01e017562351a79db4ee772914a0201032e80ba02e896174d7427edb47244d035ccf5b11397ad683617dd7171deb5e5a75574ddc7cbeeef12f0863f68236dda5a477104792e6bbbbdc21c0e8b38ef245be2bde48ff82fed379782cf717f3da5ab56c7debde3f84d05435e3130e21e60f0237158dab31e5b2b922d1d926258b3d8c486cb89427631203120312236c8d354c5ae15510ebb6c2468f7d9c7b42b38ad131d1652e4639adbded3f6bf4756d9581ed37042d37a4d6752b38b245ebb84f8962d864a038169d8e05a7b0a98ed3b6368dc6999a1e72c0e81e6ce84e1b9decf75dd965bb2d77f147aaaf1efd3ba5bd17da759627ec81b81be53c7f83e7d9b75fcbf96f8f8fcf8fe53b9f75836ecd2f446de95e89b41118eba519b818a11c1b7ebbfbed87b8f15738d4fee97339d977f047ede91756dcd2dd122e80ba066250131204c4813120f26f4a1d1b30cbfb6c2d1a994812b40b6ae63b1d6f85df3ed5533e3efd50e9f133ee3a25c307aada5f8947340c79c573149f78cb027f8c6c70ed5945e63b4f78616c7169dc7694666963fb466b1bf7b18bfe666d1dd75974d6df2cb0ebbd3e68dfde12c154c78bb1c1df31da372c26931e5b2b92b6f129b12c59ecb893492624d1b2e24d1b207ff009c510c499a6925c4dff8694ecfbb79ddd8acc7f56baf5850989e3df7fdb2d864808046c55e634bd16898ec6cb306dafb4e40017738f0037a98accb1b5e2aa35d40f90894616ccdb5a33621cd06f85e779f20b753256bf0fa2b65c36bfc71e7e848f4b8f66606278c8870b0ee2a270cf9af7655e4c78b46a56195cd7e518329fc232ef71b01e2b1f7731e59fbe89f97bb7ba25a064aea96c57c2d68c72b9b9b618efc77bcec1bb69dca694ea9d47863972fbbaee7cbde6961644c6471b43238da18d60c835a32015e88d46a1c6b4cccee52dd4a0b740b89018948871a849b8d0219102191041571b2563e295a248e4696398730e69198513dd313313b8787f4b7a3b268f9b09bbe9e424c52edb8f81dc1e3cf6f652c98fa65d6c39bae3eec4122d7a6fd9cd948d86ca349893678a39337b0177c6dea49f982ca2d68f12c2d8e96f308c53c8dfb29b18f82506fdcf19f8acbaab3f3430e8bd7e5b6ff0024756967db46e8ff0018ebc5f986cef51eef7f2ca7df4d7e78d2cb25045c1b83bc1b8584c4c796d8b44f782e2509d8c49a3664c1ae6b9b200584660eced5956662770c6f15b5756f0c5a5a8740f11177aa713ab9882461e437f0e0acdab178eaf550a64b639e8f4f496bc785b9b737119c873791fa0e41579999ecbb5888ee5c6a34cb676bcefcfb40291dbc13a9f30b5a2a8a7ac95b4f00c4f767f0c6c6ef73c8d8d0b2ad26d2c2f92291b97b7f46743454303618bac7da925b59d2c96cdc79701b82bb4a45634e465c9392db96b89166d6707a05c688287205c482a97a24d2f502332a24c74a82374e829692862a889f0ccd0f8de2c5a771dce077386d042898898d4b2ada6b3b8792f49fa2d2d19323099a97749efc7ca41ffd0cbb155be3d3a38b3c5bb4f973c245af4dfb3b58a349d9dac4d1b39b311bf2e1b428d276ad2530be280ea9ff0007ee9fdaddc79ad917df6b34db1ebbd3b4ff00a14f5e1c0877ab7b72734902dd8778516c7af1e134cd16ed3da52899cef61b71f1bbaacfa9ee51d311e5975ccfcb0308dae3ac70cf316603c9bf5ba9dfd0e9faf736a98d95a592660ec3bda78851599acee0c958bc6a59d0d43e0708a6cdbee49b9c39f35bad58bc755556992d8a7a6ffe5a3ac0b4e96ba9a5a0742cf5b2608461603d799c0eae3fabbf08f259d6932d7933453cbd83a3da2e0a2884500ccd8be536d64aeb6d71fd36056ab58ac39d9324de772d76ceb26b4825442412290f1220787a0762414dcf50944e91042f91040f9912aef9d05792a505596a7220e60820839820ed046f0838cd39d198de4be98889df7247a927f0919b3cc725a6d8a27c2ce3e44c76971d5913e1761998e8ceecc16bbb0ef5aa6930b35c916f08b583e23f947d563a67bfb971fe3fe81f54d7d8dfdc621f138fe51fa27e20f3e655ab58dfb56652c7d60e24b8b80dc6eb652d3e25a72d23e68f30b1155e36b5dc402b5cd753a6ea64eaac4975aa349ea21994e91d418d331d508ccd7cf0017239f2ed59562627b30bdab31f13aae8cf43a36073aaaefc56c10eb0da31bc92dda77596f8aefca9cdfa7b565de50bd9131b1c4d11c6d160c6801a3fbf359c469aa6667caf4752a50b0ca84161932213b25413364412b5e883c3d48a8e7284a17b90577b912ad23905591c829caf414e6794142790a0cfaa76205ae01cd3b5a4020f71506f4e7eb74442736de23c8f57c0ac6690d95cb6861d4d3e0d92b1de2d3faac7ddb646753353651eee597bf84724e1d938e5f08dfda54c56618db245bcc9eda9dc320a3a2597be8885ba780bff007ac6f8b8f865f353eed8ce7fa3668b43c5b5c4cbdf85be03eab28c70d739ad2e86883631858d0c6f06803c78acb4d73333e5a70ca548bd0c882ec5220bb1c882d47220b11bd058639109dae412028844f08940f08207b512aef620af24682a4b120a92c2a12a152c0dda510c2ada93ee8ef4da74c1aa89eeda4a6cd33e4a13c11081da3cf053b3467fa7724468f6e8e29b4e933347951b4e97e9617b361b26cd3728aa4fbc3bd3669bb48d0e1708868450a917228d05b89882cb1882c302213b0209d88250815cc4113988217468227c68942e89042f81066d63837b546d310c3a98cb962c945f448207d07252227e8fe4884474772520ff004ee4a028d1dc903868fe4894ada0413328905ca78cb366f4825bb44ec56076d94c4b198693205284ec8504cd8d04ec8d1095ac412b5a81e1a824288308411b8224c735046e68414eb32192894c30e6172b166aee8c208cc41031d10521862081baa1c10236208883b5411204410384414091b1040ed58ba9844acc2db15096d511b8cd64c2575ad0a5091ad412342091a11091a103ec83ffd9, 'matteo', 'consonni');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti_piante`
--

CREATE TABLE IF NOT EXISTS `utenti_piante` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_utente` int(11) NOT NULL,
  `ID_piante` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dump dei dati per la tabella `utenti_piante`
--

INSERT INTO `utenti_piante` (`ID`, `ID_utente`, `ID_piante`) VALUES
(1, 3, 2),
(3, 3, 3),
(4, 3, 7),
(35, 4, 42),
(13, 3, 8),
(12, 1, 9),
(11, 3, 20),
(10, 3, 4),
(15, 3, 9),
(16, 0, 1),
(17, 0, 2),
(18, 0, 3),
(19, 0, 4),
(20, 1, 3),
(31, 4, 13),
(22, 2, 9),
(23, 2, 11),
(24, 2, 13),
(25, 1, 4),
(26, 2, 4),
(27, 2, 8),
(34, 4, 41),
(33, 4, 42),
(36, 4, 36),
(37, 1, 1),
(38, 3, 3),
(39, 3, 3),
(40, 3, 3),
(41, 3, 3),
(42, 3, 3),
(43, 3, 3),
(44, 3, 3),
(45, 3, 3),
(46, 3, 3),
(47, 3, 3),
(48, 3, 3),
(49, 3, 3),
(50, 3, 3),
(51, 3, 41),
(52, 3, 0),
(53, 3, 41),
(54, 3, 13),
(55, 3, 13),
(56, 3, 13),
(57, 3, 13),
(58, 3, 13),
(59, 3, 13),
(60, 3, 13),
(61, 3, 13),
(62, 3, 13),
(63, 3, 1),
(64, 3, 1),
(65, 3, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
