document.addEventListener('DOMContentLoaded', function () {
  if (Notification.permission !== "granted")
    Notification.requestPermission(); 
});

function notifyMe(lol) {
var tem=lol;
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://www.iconj.com/ico/a/d/adbwmdihrp.ico',
      body: "temperatura="+tem,   //    body: "Ciao! Benvenuto su myOrto", 
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}

function notifyIce() {
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://www.iconj.com/ico/f/n/fn5lqsqtj8.ico',
      body: "Attenzione! Rischio gelo per il tuo orto",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifyHot() {
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/IBbhhvx.png',
      body: "Attenzione! Rischio siccità,temperatura molto elevata!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifyThunder() {
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/n1Ea2f5.png',
      body: "Un temporale potrebbe danneggiare le tue piante!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifyRain() {
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/CKIex8V.png',
      body: "Oggi piove!Per non sprecare acqua saltano i piani di irrigazione del tuo orto",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifySnow() {
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/sDfUNyX.png',
      body: "Nevicata in arrivo,proteggi le tue piante!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifyHail() {  //grandine
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/ztfe6Fu.png',
      body: "Della grandine potrebbe danneggiare le tue piante!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}

function notifySand() {  //tempesta di sabbia
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/HFvXk9N.png',
      body: "Una tempesta di sabbia potrebbe danneggiare le tue piante!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}

function notifyWind() {  //vento
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/tD5vy7a.gif',
      body: "Forti venti potrebbero abbattersi sul tuo orto!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}
function notifyStorm() {  //tempeste, fortunali
var test=true;
  if (!Notification) {
    alert('Notifiche desktop non disponibili su questo browser,aggiornalo.'); 
    return;
  }

 if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notifica da myOrto', {
      icon: 'http://i.imgur.com/tD5vy7a.gif',
      body: "Tornadi,uragani o fortunali potrebbero danneggiare gravemente il tuo orto!",    
    });

    notification.onclick = function () {
      window.open("profiloUtente.php");      
    };

  }

 

}