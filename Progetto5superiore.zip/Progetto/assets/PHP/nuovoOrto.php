<?php
session_start();
include("DB_connect.php"); 

$utenteAttuale=$_SESSION['ID_utente'];

$nome=$_GET["nomeOrto"];
$tipo=$_GET["tipoOrto"];
$tipo1=$connessione_al_server->query("SELECT ID_tipo from tipo where Tipo='$tipo'");
if($tipo1->connect_errno){
printf("query non riuscita: %s\n",$utente->connect_error);
}

while ($row=$tipo1->fetch_array())
{
   $tipo2=$row['ID_tipo'];
}
echo $utenteAttuale;
echo $tipo2;
echo $nome;

$nomeuguale=$connessione_al_server->query("SELECT nome from orto WHERE nome='$nome'");
if($nomeuguale->connect_errno){
printf("query non riuscita: %s\n",$utente->connect_error);
}
 if($nomeuguale->num_rows==1)
{
header('location:  /paginaOrto.php?nomeuguale=1');
exit();
}
else
{
$connessione_al_server->query("INSERT INTO `my_project0101`.`orto` (`nome`,`ID_utente`,`ID_tipo`) VALUES ('$nome', '$utenteAttuale',$tipo2);");
$idOrto=$connessione_al_server->query("SELECT ID_orto from orto where ID_tipo=$tipo2 and nome='$nome'");
while ($row=$idOrto->fetch_array())
{
   $idOrto1=$row['ID_orto'];
}
echo $idOrto1;
header ("Location: /paginaOrto.php?id=$idOrto1");
}


?>