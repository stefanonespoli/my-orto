<?php

include("/assets/PHP/DB_connect.php");




//Recupero il valore del parametro 
$temperatura = $_GET['temperatura'];
$umidita = $_GET['umidita']; 
$umiditaS=$_GET['umiditaS'];
$luce=$_GET['luce'];
$pioggia=$_GET['pioggia'];

 

 

 

 $sql=$connessione_al_server->query("UPDATE dati
SET temperatura='$temperatura', umidita='$umidita', umiditaS='$umiditaS',luce=$luce,pioggia=$pioggia
WHERE id=1;");
//creo una stringa sql di inserimento con i valori
//recuperati dall'url
//gestione degli errori
if(!$sql){
printf("Connect failed: %s\n",$query->connect_error);
exit();
}
 

 
 
//chiudo la connessione al db
mysqli_close($connessione_al_server);

?>